<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-19 07:26:18 --> Config Class Initialized
INFO - 2024-06-19 07:26:18 --> Hooks Class Initialized
DEBUG - 2024-06-19 07:26:18 --> UTF-8 Support Enabled
INFO - 2024-06-19 07:26:18 --> Utf8 Class Initialized
INFO - 2024-06-19 07:26:18 --> URI Class Initialized
INFO - 2024-06-19 07:26:18 --> Router Class Initialized
INFO - 2024-06-19 07:26:18 --> Output Class Initialized
INFO - 2024-06-19 07:26:18 --> Security Class Initialized
DEBUG - 2024-06-19 07:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-19 07:26:18 --> Input Class Initialized
INFO - 2024-06-19 07:26:18 --> Language Class Initialized
ERROR - 2024-06-19 07:26:18 --> 404 Page Not Found: Blog/auth
INFO - 2024-06-19 07:28:42 --> Config Class Initialized
INFO - 2024-06-19 07:28:42 --> Hooks Class Initialized
DEBUG - 2024-06-19 07:28:42 --> UTF-8 Support Enabled
INFO - 2024-06-19 07:28:42 --> Utf8 Class Initialized
INFO - 2024-06-19 07:28:42 --> URI Class Initialized
DEBUG - 2024-06-19 07:28:42 --> No URI present. Default controller set.
INFO - 2024-06-19 07:28:42 --> Router Class Initialized
INFO - 2024-06-19 07:28:42 --> Output Class Initialized
INFO - 2024-06-19 07:28:42 --> Security Class Initialized
DEBUG - 2024-06-19 07:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-19 07:28:42 --> Input Class Initialized
INFO - 2024-06-19 07:28:42 --> Language Class Initialized
INFO - 2024-06-19 07:28:42 --> Loader Class Initialized
INFO - 2024-06-19 07:28:42 --> Helper loaded: url_helper
INFO - 2024-06-19 07:28:42 --> Controller Class Initialized
INFO - 2024-06-19 07:28:42 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-19 07:28:42 --> Final output sent to browser
DEBUG - 2024-06-19 07:28:42 --> Total execution time: 0.0235
INFO - 2024-06-19 07:30:23 --> Config Class Initialized
INFO - 2024-06-19 07:30:23 --> Hooks Class Initialized
DEBUG - 2024-06-19 07:30:23 --> UTF-8 Support Enabled
INFO - 2024-06-19 07:30:23 --> Utf8 Class Initialized
INFO - 2024-06-19 07:30:23 --> URI Class Initialized
DEBUG - 2024-06-19 07:30:23 --> No URI present. Default controller set.
INFO - 2024-06-19 07:30:23 --> Router Class Initialized
INFO - 2024-06-19 07:30:23 --> Output Class Initialized
INFO - 2024-06-19 07:30:23 --> Security Class Initialized
DEBUG - 2024-06-19 07:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-19 07:30:23 --> Input Class Initialized
INFO - 2024-06-19 07:30:23 --> Language Class Initialized
INFO - 2024-06-19 07:30:23 --> Loader Class Initialized
INFO - 2024-06-19 07:30:23 --> Helper loaded: url_helper
INFO - 2024-06-19 07:30:23 --> Controller Class Initialized
INFO - 2024-06-19 07:30:23 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-19 07:30:23 --> Final output sent to browser
DEBUG - 2024-06-19 07:30:23 --> Total execution time: 0.6352
INFO - 2024-06-19 07:30:25 --> Config Class Initialized
INFO - 2024-06-19 07:30:25 --> Hooks Class Initialized
DEBUG - 2024-06-19 07:30:25 --> UTF-8 Support Enabled
INFO - 2024-06-19 07:30:25 --> Utf8 Class Initialized
INFO - 2024-06-19 07:30:25 --> URI Class Initialized
INFO - 2024-06-19 07:30:25 --> Router Class Initialized
INFO - 2024-06-19 07:30:25 --> Output Class Initialized
INFO - 2024-06-19 07:30:25 --> Security Class Initialized
DEBUG - 2024-06-19 07:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-19 07:30:25 --> Input Class Initialized
INFO - 2024-06-19 07:30:25 --> Language Class Initialized
ERROR - 2024-06-19 07:30:25 --> 404 Page Not Found: Blog/auth
INFO - 2024-06-19 07:30:31 --> Config Class Initialized
INFO - 2024-06-19 07:30:31 --> Hooks Class Initialized
DEBUG - 2024-06-19 07:30:31 --> UTF-8 Support Enabled
INFO - 2024-06-19 07:30:31 --> Utf8 Class Initialized
INFO - 2024-06-19 07:30:31 --> URI Class Initialized
INFO - 2024-06-19 07:30:31 --> Router Class Initialized
INFO - 2024-06-19 07:30:31 --> Output Class Initialized
INFO - 2024-06-19 07:30:31 --> Security Class Initialized
DEBUG - 2024-06-19 07:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-19 07:30:31 --> Input Class Initialized
INFO - 2024-06-19 07:30:31 --> Language Class Initialized
ERROR - 2024-06-19 07:30:31 --> 404 Page Not Found: Blog/Auth
INFO - 2024-06-19 07:30:34 --> Config Class Initialized
INFO - 2024-06-19 07:30:34 --> Hooks Class Initialized
DEBUG - 2024-06-19 07:30:34 --> UTF-8 Support Enabled
INFO - 2024-06-19 07:30:34 --> Utf8 Class Initialized
INFO - 2024-06-19 07:30:34 --> URI Class Initialized
INFO - 2024-06-19 07:30:34 --> Router Class Initialized
INFO - 2024-06-19 07:30:34 --> Output Class Initialized
INFO - 2024-06-19 07:30:34 --> Security Class Initialized
DEBUG - 2024-06-19 07:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-19 07:30:34 --> Input Class Initialized
INFO - 2024-06-19 07:30:34 --> Language Class Initialized
ERROR - 2024-06-19 07:30:34 --> 404 Page Not Found: Blog/Auth
INFO - 2024-06-19 07:30:34 --> Config Class Initialized
INFO - 2024-06-19 07:30:34 --> Hooks Class Initialized
DEBUG - 2024-06-19 07:30:34 --> UTF-8 Support Enabled
INFO - 2024-06-19 07:30:34 --> Utf8 Class Initialized
INFO - 2024-06-19 07:30:34 --> URI Class Initialized
INFO - 2024-06-19 07:30:34 --> Router Class Initialized
INFO - 2024-06-19 07:30:34 --> Output Class Initialized
INFO - 2024-06-19 07:30:34 --> Security Class Initialized
DEBUG - 2024-06-19 07:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-19 07:30:34 --> Input Class Initialized
INFO - 2024-06-19 07:30:34 --> Language Class Initialized
ERROR - 2024-06-19 07:30:34 --> 404 Page Not Found: Blog/Auth
INFO - 2024-06-19 07:30:35 --> Config Class Initialized
INFO - 2024-06-19 07:30:35 --> Hooks Class Initialized
DEBUG - 2024-06-19 07:30:35 --> UTF-8 Support Enabled
INFO - 2024-06-19 07:30:35 --> Utf8 Class Initialized
INFO - 2024-06-19 07:30:35 --> URI Class Initialized
INFO - 2024-06-19 07:30:35 --> Router Class Initialized
INFO - 2024-06-19 07:30:35 --> Output Class Initialized
INFO - 2024-06-19 07:30:35 --> Security Class Initialized
DEBUG - 2024-06-19 07:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-19 07:30:35 --> Input Class Initialized
INFO - 2024-06-19 07:30:35 --> Language Class Initialized
ERROR - 2024-06-19 07:30:35 --> 404 Page Not Found: Blog/Auth
INFO - 2024-06-19 07:30:36 --> Config Class Initialized
INFO - 2024-06-19 07:30:36 --> Hooks Class Initialized
DEBUG - 2024-06-19 07:30:36 --> UTF-8 Support Enabled
INFO - 2024-06-19 07:30:36 --> Utf8 Class Initialized
INFO - 2024-06-19 07:30:36 --> URI Class Initialized
INFO - 2024-06-19 07:30:36 --> Router Class Initialized
INFO - 2024-06-19 07:30:36 --> Output Class Initialized
INFO - 2024-06-19 07:30:36 --> Security Class Initialized
DEBUG - 2024-06-19 07:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-19 07:30:36 --> Input Class Initialized
INFO - 2024-06-19 07:30:36 --> Language Class Initialized
ERROR - 2024-06-19 07:30:36 --> 404 Page Not Found: Blog/Auth
INFO - 2024-06-19 07:30:36 --> Config Class Initialized
INFO - 2024-06-19 07:30:36 --> Hooks Class Initialized
DEBUG - 2024-06-19 07:30:36 --> UTF-8 Support Enabled
INFO - 2024-06-19 07:30:36 --> Utf8 Class Initialized
INFO - 2024-06-19 07:30:36 --> URI Class Initialized
INFO - 2024-06-19 07:30:36 --> Router Class Initialized
INFO - 2024-06-19 07:30:36 --> Output Class Initialized
INFO - 2024-06-19 07:30:36 --> Security Class Initialized
DEBUG - 2024-06-19 07:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-19 07:30:36 --> Input Class Initialized
INFO - 2024-06-19 07:30:36 --> Language Class Initialized
ERROR - 2024-06-19 07:30:36 --> 404 Page Not Found: Blog/Auth
INFO - 2024-06-19 07:30:37 --> Config Class Initialized
INFO - 2024-06-19 07:30:37 --> Hooks Class Initialized
DEBUG - 2024-06-19 07:30:37 --> UTF-8 Support Enabled
INFO - 2024-06-19 07:30:37 --> Utf8 Class Initialized
INFO - 2024-06-19 07:30:37 --> URI Class Initialized
INFO - 2024-06-19 07:30:37 --> Router Class Initialized
INFO - 2024-06-19 07:30:37 --> Output Class Initialized
INFO - 2024-06-19 07:30:37 --> Security Class Initialized
DEBUG - 2024-06-19 07:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-19 07:30:37 --> Input Class Initialized
INFO - 2024-06-19 07:30:37 --> Language Class Initialized
ERROR - 2024-06-19 07:30:37 --> 404 Page Not Found: Blog/Auth
INFO - 2024-06-19 07:30:37 --> Config Class Initialized
INFO - 2024-06-19 07:30:37 --> Hooks Class Initialized
DEBUG - 2024-06-19 07:30:37 --> UTF-8 Support Enabled
INFO - 2024-06-19 07:30:37 --> Utf8 Class Initialized
INFO - 2024-06-19 07:30:37 --> URI Class Initialized
INFO - 2024-06-19 07:30:37 --> Router Class Initialized
INFO - 2024-06-19 07:30:37 --> Output Class Initialized
INFO - 2024-06-19 07:30:37 --> Security Class Initialized
DEBUG - 2024-06-19 07:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-19 07:30:37 --> Input Class Initialized
INFO - 2024-06-19 07:30:37 --> Language Class Initialized
ERROR - 2024-06-19 07:30:37 --> 404 Page Not Found: Blog/Auth
INFO - 2024-06-19 07:30:38 --> Config Class Initialized
INFO - 2024-06-19 07:30:38 --> Hooks Class Initialized
DEBUG - 2024-06-19 07:30:38 --> UTF-8 Support Enabled
INFO - 2024-06-19 07:30:38 --> Utf8 Class Initialized
INFO - 2024-06-19 07:30:38 --> URI Class Initialized
INFO - 2024-06-19 07:30:38 --> Router Class Initialized
INFO - 2024-06-19 07:30:38 --> Output Class Initialized
INFO - 2024-06-19 07:30:38 --> Security Class Initialized
DEBUG - 2024-06-19 07:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-19 07:30:38 --> Input Class Initialized
INFO - 2024-06-19 07:30:38 --> Language Class Initialized
ERROR - 2024-06-19 07:30:38 --> 404 Page Not Found: Blog/Auth
INFO - 2024-06-19 07:30:44 --> Config Class Initialized
INFO - 2024-06-19 07:30:44 --> Hooks Class Initialized
DEBUG - 2024-06-19 07:30:44 --> UTF-8 Support Enabled
INFO - 2024-06-19 07:30:44 --> Utf8 Class Initialized
INFO - 2024-06-19 07:30:44 --> URI Class Initialized
INFO - 2024-06-19 07:30:44 --> Router Class Initialized
INFO - 2024-06-19 07:30:44 --> Output Class Initialized
INFO - 2024-06-19 07:30:44 --> Security Class Initialized
DEBUG - 2024-06-19 07:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-19 07:30:44 --> Input Class Initialized
INFO - 2024-06-19 07:30:44 --> Language Class Initialized
ERROR - 2024-06-19 07:30:44 --> 404 Page Not Found: Blog/auth
INFO - 2024-06-19 07:30:48 --> Config Class Initialized
INFO - 2024-06-19 07:30:48 --> Hooks Class Initialized
DEBUG - 2024-06-19 07:30:48 --> UTF-8 Support Enabled
INFO - 2024-06-19 07:30:48 --> Utf8 Class Initialized
INFO - 2024-06-19 07:30:48 --> URI Class Initialized
INFO - 2024-06-19 07:30:48 --> Router Class Initialized
INFO - 2024-06-19 07:30:48 --> Output Class Initialized
INFO - 2024-06-19 07:30:48 --> Security Class Initialized
DEBUG - 2024-06-19 07:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-19 07:30:48 --> Input Class Initialized
INFO - 2024-06-19 07:30:48 --> Language Class Initialized
ERROR - 2024-06-19 07:30:48 --> 404 Page Not Found: Blog/home
INFO - 2024-06-19 07:30:52 --> Config Class Initialized
INFO - 2024-06-19 07:30:52 --> Hooks Class Initialized
DEBUG - 2024-06-19 07:30:52 --> UTF-8 Support Enabled
INFO - 2024-06-19 07:30:52 --> Utf8 Class Initialized
INFO - 2024-06-19 07:30:52 --> URI Class Initialized
INFO - 2024-06-19 07:30:52 --> Router Class Initialized
INFO - 2024-06-19 07:30:52 --> Output Class Initialized
INFO - 2024-06-19 07:30:52 --> Security Class Initialized
DEBUG - 2024-06-19 07:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-19 07:30:52 --> Input Class Initialized
INFO - 2024-06-19 07:30:52 --> Language Class Initialized
ERROR - 2024-06-19 07:30:52 --> 404 Page Not Found: Blog/Home
INFO - 2024-06-19 07:31:12 --> Config Class Initialized
INFO - 2024-06-19 07:31:12 --> Hooks Class Initialized
DEBUG - 2024-06-19 07:31:12 --> UTF-8 Support Enabled
INFO - 2024-06-19 07:31:12 --> Utf8 Class Initialized
INFO - 2024-06-19 07:31:12 --> URI Class Initialized
INFO - 2024-06-19 07:31:12 --> Router Class Initialized
INFO - 2024-06-19 07:31:12 --> Output Class Initialized
INFO - 2024-06-19 07:31:12 --> Security Class Initialized
DEBUG - 2024-06-19 07:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-19 07:31:12 --> Input Class Initialized
INFO - 2024-06-19 07:31:12 --> Language Class Initialized
ERROR - 2024-06-19 07:31:12 --> 404 Page Not Found: Blog/Home
INFO - 2024-06-19 07:31:13 --> Config Class Initialized
INFO - 2024-06-19 07:31:13 --> Hooks Class Initialized
DEBUG - 2024-06-19 07:31:13 --> UTF-8 Support Enabled
INFO - 2024-06-19 07:31:13 --> Utf8 Class Initialized
INFO - 2024-06-19 07:31:13 --> URI Class Initialized
INFO - 2024-06-19 07:31:13 --> Router Class Initialized
INFO - 2024-06-19 07:31:13 --> Output Class Initialized
INFO - 2024-06-19 07:31:13 --> Security Class Initialized
DEBUG - 2024-06-19 07:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-19 07:31:13 --> Input Class Initialized
INFO - 2024-06-19 07:31:13 --> Language Class Initialized
ERROR - 2024-06-19 07:31:13 --> 404 Page Not Found: Blog/Home
