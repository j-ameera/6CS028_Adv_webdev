<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-20 10:05:43 --> Config Class Initialized
INFO - 2024-06-20 10:05:43 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:05:43 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:05:43 --> Utf8 Class Initialized
INFO - 2024-06-20 10:05:43 --> URI Class Initialized
DEBUG - 2024-06-20 10:05:44 --> No URI present. Default controller set.
INFO - 2024-06-20 10:05:44 --> Router Class Initialized
INFO - 2024-06-20 10:05:44 --> Output Class Initialized
INFO - 2024-06-20 10:05:44 --> Security Class Initialized
DEBUG - 2024-06-20 10:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:05:44 --> Input Class Initialized
INFO - 2024-06-20 10:05:44 --> Language Class Initialized
INFO - 2024-06-20 10:05:44 --> Loader Class Initialized
INFO - 2024-06-20 10:05:44 --> Helper loaded: url_helper
INFO - 2024-06-20 10:05:44 --> Controller Class Initialized
INFO - 2024-06-20 10:05:45 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 10:05:45 --> Final output sent to browser
DEBUG - 2024-06-20 10:05:45 --> Total execution time: 1.9412
INFO - 2024-06-20 10:05:49 --> Config Class Initialized
INFO - 2024-06-20 10:05:49 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:05:49 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:05:49 --> Utf8 Class Initialized
INFO - 2024-06-20 10:05:49 --> URI Class Initialized
INFO - 2024-06-20 10:05:49 --> Router Class Initialized
INFO - 2024-06-20 10:05:49 --> Output Class Initialized
INFO - 2024-06-20 10:05:49 --> Security Class Initialized
DEBUG - 2024-06-20 10:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:05:49 --> Input Class Initialized
INFO - 2024-06-20 10:05:49 --> Language Class Initialized
ERROR - 2024-06-20 10:05:49 --> 404 Page Not Found: Blog/auth
INFO - 2024-06-20 10:38:10 --> Config Class Initialized
INFO - 2024-06-20 10:38:10 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:38:10 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:38:10 --> Utf8 Class Initialized
INFO - 2024-06-20 10:38:10 --> URI Class Initialized
INFO - 2024-06-20 10:38:10 --> Router Class Initialized
INFO - 2024-06-20 10:38:10 --> Output Class Initialized
INFO - 2024-06-20 10:38:10 --> Security Class Initialized
DEBUG - 2024-06-20 10:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:38:10 --> Input Class Initialized
INFO - 2024-06-20 10:38:10 --> Language Class Initialized
ERROR - 2024-06-20 10:38:10 --> 404 Page Not Found: Blog/auth
INFO - 2024-06-20 10:38:13 --> Config Class Initialized
INFO - 2024-06-20 10:38:13 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:38:13 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:38:13 --> Utf8 Class Initialized
INFO - 2024-06-20 10:38:13 --> URI Class Initialized
INFO - 2024-06-20 10:38:13 --> Router Class Initialized
INFO - 2024-06-20 10:38:13 --> Output Class Initialized
INFO - 2024-06-20 10:38:13 --> Security Class Initialized
DEBUG - 2024-06-20 10:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:38:13 --> Input Class Initialized
INFO - 2024-06-20 10:38:13 --> Language Class Initialized
ERROR - 2024-06-20 10:38:13 --> 404 Page Not Found: Blog/auth
INFO - 2024-06-20 10:38:33 --> Config Class Initialized
INFO - 2024-06-20 10:38:33 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:38:33 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:38:33 --> Utf8 Class Initialized
INFO - 2024-06-20 10:38:33 --> URI Class Initialized
DEBUG - 2024-06-20 10:38:33 --> No URI present. Default controller set.
INFO - 2024-06-20 10:38:33 --> Router Class Initialized
INFO - 2024-06-20 10:38:33 --> Output Class Initialized
INFO - 2024-06-20 10:38:33 --> Security Class Initialized
DEBUG - 2024-06-20 10:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:38:33 --> Input Class Initialized
INFO - 2024-06-20 10:38:33 --> Language Class Initialized
INFO - 2024-06-20 10:38:33 --> Loader Class Initialized
INFO - 2024-06-20 10:38:33 --> Helper loaded: url_helper
INFO - 2024-06-20 10:38:33 --> Controller Class Initialized
INFO - 2024-06-20 10:38:33 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 10:38:33 --> Final output sent to browser
DEBUG - 2024-06-20 10:38:33 --> Total execution time: 0.0345
INFO - 2024-06-20 10:38:37 --> Config Class Initialized
INFO - 2024-06-20 10:38:37 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:38:37 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:38:37 --> Utf8 Class Initialized
INFO - 2024-06-20 10:38:37 --> URI Class Initialized
INFO - 2024-06-20 10:38:37 --> Router Class Initialized
INFO - 2024-06-20 10:38:37 --> Output Class Initialized
INFO - 2024-06-20 10:38:37 --> Security Class Initialized
DEBUG - 2024-06-20 10:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:38:37 --> Input Class Initialized
INFO - 2024-06-20 10:38:37 --> Language Class Initialized
ERROR - 2024-06-20 10:38:37 --> 404 Page Not Found: Blog/auth
INFO - 2024-06-20 10:39:05 --> Config Class Initialized
INFO - 2024-06-20 10:39:05 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:39:05 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:39:05 --> Utf8 Class Initialized
INFO - 2024-06-20 10:39:05 --> URI Class Initialized
INFO - 2024-06-20 10:39:05 --> Router Class Initialized
INFO - 2024-06-20 10:39:05 --> Output Class Initialized
INFO - 2024-06-20 10:39:05 --> Security Class Initialized
DEBUG - 2024-06-20 10:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:39:05 --> Input Class Initialized
INFO - 2024-06-20 10:39:05 --> Language Class Initialized
ERROR - 2024-06-20 10:39:05 --> 404 Page Not Found: Blog/auth
INFO - 2024-06-20 10:39:06 --> Config Class Initialized
INFO - 2024-06-20 10:39:06 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:39:06 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:39:06 --> Utf8 Class Initialized
INFO - 2024-06-20 10:39:06 --> URI Class Initialized
INFO - 2024-06-20 10:39:06 --> Router Class Initialized
INFO - 2024-06-20 10:39:06 --> Output Class Initialized
INFO - 2024-06-20 10:39:06 --> Security Class Initialized
DEBUG - 2024-06-20 10:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:39:06 --> Input Class Initialized
INFO - 2024-06-20 10:39:06 --> Language Class Initialized
ERROR - 2024-06-20 10:39:06 --> 404 Page Not Found: Blog/auth
INFO - 2024-06-20 10:39:07 --> Config Class Initialized
INFO - 2024-06-20 10:39:07 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:39:07 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:39:07 --> Utf8 Class Initialized
INFO - 2024-06-20 10:39:07 --> URI Class Initialized
INFO - 2024-06-20 10:39:07 --> Router Class Initialized
INFO - 2024-06-20 10:39:07 --> Output Class Initialized
INFO - 2024-06-20 10:39:07 --> Security Class Initialized
DEBUG - 2024-06-20 10:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:39:07 --> Input Class Initialized
INFO - 2024-06-20 10:39:07 --> Language Class Initialized
ERROR - 2024-06-20 10:39:07 --> 404 Page Not Found: Blog/auth
INFO - 2024-06-20 10:39:21 --> Config Class Initialized
INFO - 2024-06-20 10:39:21 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:39:21 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:39:21 --> Utf8 Class Initialized
INFO - 2024-06-20 10:39:21 --> URI Class Initialized
INFO - 2024-06-20 10:39:21 --> Router Class Initialized
INFO - 2024-06-20 10:39:21 --> Output Class Initialized
INFO - 2024-06-20 10:39:21 --> Security Class Initialized
DEBUG - 2024-06-20 10:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:39:21 --> Input Class Initialized
INFO - 2024-06-20 10:39:21 --> Language Class Initialized
ERROR - 2024-06-20 10:39:21 --> 404 Page Not Found: Blog/auth
INFO - 2024-06-20 10:39:22 --> Config Class Initialized
INFO - 2024-06-20 10:39:22 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:39:22 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:39:22 --> Utf8 Class Initialized
INFO - 2024-06-20 10:39:22 --> URI Class Initialized
INFO - 2024-06-20 10:39:22 --> Router Class Initialized
INFO - 2024-06-20 10:39:22 --> Output Class Initialized
INFO - 2024-06-20 10:39:22 --> Security Class Initialized
DEBUG - 2024-06-20 10:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:39:22 --> Input Class Initialized
INFO - 2024-06-20 10:39:22 --> Language Class Initialized
ERROR - 2024-06-20 10:39:22 --> 404 Page Not Found: Blog/auth
INFO - 2024-06-20 10:39:23 --> Config Class Initialized
INFO - 2024-06-20 10:39:23 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:39:23 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:39:23 --> Utf8 Class Initialized
INFO - 2024-06-20 10:39:23 --> URI Class Initialized
INFO - 2024-06-20 10:39:23 --> Router Class Initialized
INFO - 2024-06-20 10:39:23 --> Output Class Initialized
INFO - 2024-06-20 10:39:23 --> Security Class Initialized
DEBUG - 2024-06-20 10:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:39:23 --> Input Class Initialized
INFO - 2024-06-20 10:39:23 --> Language Class Initialized
ERROR - 2024-06-20 10:39:23 --> 404 Page Not Found: Blog/auth
INFO - 2024-06-20 10:39:24 --> Config Class Initialized
INFO - 2024-06-20 10:39:24 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:39:24 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:39:24 --> Utf8 Class Initialized
INFO - 2024-06-20 10:39:24 --> URI Class Initialized
INFO - 2024-06-20 10:39:24 --> Router Class Initialized
INFO - 2024-06-20 10:39:24 --> Output Class Initialized
INFO - 2024-06-20 10:39:24 --> Security Class Initialized
DEBUG - 2024-06-20 10:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:39:24 --> Input Class Initialized
INFO - 2024-06-20 10:39:24 --> Language Class Initialized
ERROR - 2024-06-20 10:39:24 --> 404 Page Not Found: Blog/auth
INFO - 2024-06-20 10:39:30 --> Config Class Initialized
INFO - 2024-06-20 10:39:30 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:39:30 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:39:30 --> Utf8 Class Initialized
INFO - 2024-06-20 10:39:30 --> URI Class Initialized
INFO - 2024-06-20 10:39:30 --> Router Class Initialized
INFO - 2024-06-20 10:39:30 --> Output Class Initialized
INFO - 2024-06-20 10:39:30 --> Security Class Initialized
DEBUG - 2024-06-20 10:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:39:30 --> Input Class Initialized
INFO - 2024-06-20 10:39:30 --> Language Class Initialized
ERROR - 2024-06-20 10:39:30 --> 404 Page Not Found: Blog/welcome
INFO - 2024-06-20 10:39:32 --> Config Class Initialized
INFO - 2024-06-20 10:39:32 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:39:32 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:39:32 --> Utf8 Class Initialized
INFO - 2024-06-20 10:39:32 --> URI Class Initialized
INFO - 2024-06-20 10:39:32 --> Router Class Initialized
INFO - 2024-06-20 10:39:32 --> Output Class Initialized
INFO - 2024-06-20 10:39:32 --> Security Class Initialized
DEBUG - 2024-06-20 10:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:39:32 --> Input Class Initialized
INFO - 2024-06-20 10:39:32 --> Language Class Initialized
ERROR - 2024-06-20 10:39:32 --> 404 Page Not Found: Blog/welcome
INFO - 2024-06-20 10:39:41 --> Config Class Initialized
INFO - 2024-06-20 10:39:41 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:39:41 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:39:41 --> Utf8 Class Initialized
INFO - 2024-06-20 10:39:41 --> URI Class Initialized
INFO - 2024-06-20 10:39:41 --> Router Class Initialized
INFO - 2024-06-20 10:39:41 --> Output Class Initialized
INFO - 2024-06-20 10:39:41 --> Security Class Initialized
DEBUG - 2024-06-20 10:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:39:41 --> Input Class Initialized
INFO - 2024-06-20 10:39:41 --> Language Class Initialized
ERROR - 2024-06-20 10:39:41 --> 404 Page Not Found: Blog/Welcome
INFO - 2024-06-20 10:40:05 --> Config Class Initialized
INFO - 2024-06-20 10:40:05 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:40:05 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:40:05 --> Utf8 Class Initialized
INFO - 2024-06-20 10:40:05 --> URI Class Initialized
INFO - 2024-06-20 10:40:05 --> Router Class Initialized
INFO - 2024-06-20 10:40:05 --> Output Class Initialized
INFO - 2024-06-20 10:40:05 --> Security Class Initialized
DEBUG - 2024-06-20 10:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:40:05 --> Input Class Initialized
INFO - 2024-06-20 10:40:05 --> Language Class Initialized
ERROR - 2024-06-20 10:40:05 --> 404 Page Not Found: Welcome/index
INFO - 2024-06-20 10:40:28 --> Config Class Initialized
INFO - 2024-06-20 10:40:28 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:40:28 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:40:28 --> Utf8 Class Initialized
INFO - 2024-06-20 10:40:28 --> URI Class Initialized
INFO - 2024-06-20 10:40:28 --> Router Class Initialized
INFO - 2024-06-20 10:40:28 --> Output Class Initialized
INFO - 2024-06-20 10:40:28 --> Security Class Initialized
DEBUG - 2024-06-20 10:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:40:28 --> Input Class Initialized
INFO - 2024-06-20 10:40:28 --> Language Class Initialized
INFO - 2024-06-20 10:40:28 --> Loader Class Initialized
INFO - 2024-06-20 10:40:29 --> Helper loaded: url_helper
INFO - 2024-06-20 10:40:29 --> Controller Class Initialized
INFO - 2024-06-20 10:40:30 --> Config Class Initialized
INFO - 2024-06-20 10:40:30 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:40:30 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:40:30 --> Utf8 Class Initialized
INFO - 2024-06-20 10:40:30 --> URI Class Initialized
INFO - 2024-06-20 10:40:30 --> Router Class Initialized
INFO - 2024-06-20 10:40:30 --> Output Class Initialized
INFO - 2024-06-20 10:40:30 --> Security Class Initialized
DEBUG - 2024-06-20 10:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:40:30 --> Input Class Initialized
INFO - 2024-06-20 10:40:30 --> Language Class Initialized
INFO - 2024-06-20 10:40:30 --> Loader Class Initialized
INFO - 2024-06-20 10:40:30 --> Helper loaded: url_helper
INFO - 2024-06-20 10:40:30 --> Controller Class Initialized
INFO - 2024-06-20 10:40:42 --> Config Class Initialized
INFO - 2024-06-20 10:40:42 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:40:42 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:40:42 --> Utf8 Class Initialized
INFO - 2024-06-20 10:40:42 --> URI Class Initialized
INFO - 2024-06-20 10:40:42 --> Router Class Initialized
INFO - 2024-06-20 10:40:42 --> Output Class Initialized
INFO - 2024-06-20 10:40:42 --> Security Class Initialized
DEBUG - 2024-06-20 10:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:40:42 --> Input Class Initialized
INFO - 2024-06-20 10:40:42 --> Language Class Initialized
INFO - 2024-06-20 10:40:42 --> Loader Class Initialized
INFO - 2024-06-20 10:40:42 --> Helper loaded: url_helper
INFO - 2024-06-20 10:40:42 --> Controller Class Initialized
INFO - 2024-06-20 10:40:42 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 10:40:42 --> Final output sent to browser
DEBUG - 2024-06-20 10:40:42 --> Total execution time: 0.0220
INFO - 2024-06-20 10:40:44 --> Config Class Initialized
INFO - 2024-06-20 10:40:44 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:40:44 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:40:44 --> Utf8 Class Initialized
INFO - 2024-06-20 10:40:44 --> URI Class Initialized
INFO - 2024-06-20 10:40:44 --> Router Class Initialized
INFO - 2024-06-20 10:40:44 --> Output Class Initialized
INFO - 2024-06-20 10:40:44 --> Security Class Initialized
DEBUG - 2024-06-20 10:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:40:44 --> Input Class Initialized
INFO - 2024-06-20 10:40:44 --> Language Class Initialized
ERROR - 2024-06-20 10:40:44 --> 404 Page Not Found: Blog/auth
INFO - 2024-06-20 10:40:54 --> Config Class Initialized
INFO - 2024-06-20 10:40:54 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:40:54 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:40:54 --> Utf8 Class Initialized
INFO - 2024-06-20 10:40:54 --> URI Class Initialized
INFO - 2024-06-20 10:40:54 --> Router Class Initialized
INFO - 2024-06-20 10:40:54 --> Output Class Initialized
INFO - 2024-06-20 10:40:54 --> Security Class Initialized
DEBUG - 2024-06-20 10:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:40:54 --> Input Class Initialized
INFO - 2024-06-20 10:40:54 --> Language Class Initialized
ERROR - 2024-06-20 10:40:54 --> 404 Page Not Found: Blog/auth
INFO - 2024-06-20 10:41:03 --> Config Class Initialized
INFO - 2024-06-20 10:41:03 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:41:03 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:41:03 --> Utf8 Class Initialized
INFO - 2024-06-20 10:41:03 --> URI Class Initialized
INFO - 2024-06-20 10:41:03 --> Router Class Initialized
INFO - 2024-06-20 10:41:03 --> Output Class Initialized
INFO - 2024-06-20 10:41:03 --> Security Class Initialized
DEBUG - 2024-06-20 10:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:41:03 --> Input Class Initialized
INFO - 2024-06-20 10:41:03 --> Language Class Initialized
INFO - 2024-06-20 10:41:03 --> Loader Class Initialized
INFO - 2024-06-20 10:41:03 --> Helper loaded: url_helper
INFO - 2024-06-20 10:41:03 --> Controller Class Initialized
INFO - 2024-06-20 10:41:03 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 10:41:03 --> Final output sent to browser
DEBUG - 2024-06-20 10:41:03 --> Total execution time: 0.0253
INFO - 2024-06-20 10:41:15 --> Config Class Initialized
INFO - 2024-06-20 10:41:15 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:41:15 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:41:15 --> Utf8 Class Initialized
INFO - 2024-06-20 10:41:15 --> URI Class Initialized
INFO - 2024-06-20 10:41:15 --> Router Class Initialized
INFO - 2024-06-20 10:41:15 --> Output Class Initialized
INFO - 2024-06-20 10:41:15 --> Security Class Initialized
DEBUG - 2024-06-20 10:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:41:15 --> Input Class Initialized
INFO - 2024-06-20 10:41:15 --> Language Class Initialized
INFO - 2024-06-20 10:41:15 --> Loader Class Initialized
INFO - 2024-06-20 10:41:15 --> Helper loaded: url_helper
INFO - 2024-06-20 10:41:15 --> Controller Class Initialized
INFO - 2024-06-20 10:41:15 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 10:41:15 --> Final output sent to browser
DEBUG - 2024-06-20 10:41:15 --> Total execution time: 0.0693
INFO - 2024-06-20 10:41:15 --> Config Class Initialized
INFO - 2024-06-20 10:41:15 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:41:15 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:41:15 --> Utf8 Class Initialized
INFO - 2024-06-20 10:41:15 --> URI Class Initialized
INFO - 2024-06-20 10:41:15 --> Router Class Initialized
INFO - 2024-06-20 10:41:15 --> Output Class Initialized
INFO - 2024-06-20 10:41:15 --> Security Class Initialized
DEBUG - 2024-06-20 10:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:41:15 --> Input Class Initialized
INFO - 2024-06-20 10:41:15 --> Language Class Initialized
ERROR - 2024-06-20 10:41:15 --> 404 Page Not Found: Auth/loginstyle.css
INFO - 2024-06-20 10:41:17 --> Config Class Initialized
INFO - 2024-06-20 10:41:17 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:41:17 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:41:17 --> Utf8 Class Initialized
INFO - 2024-06-20 10:41:17 --> URI Class Initialized
INFO - 2024-06-20 10:41:17 --> Router Class Initialized
INFO - 2024-06-20 10:41:17 --> Output Class Initialized
INFO - 2024-06-20 10:41:17 --> Security Class Initialized
DEBUG - 2024-06-20 10:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:41:17 --> Input Class Initialized
INFO - 2024-06-20 10:41:17 --> Language Class Initialized
INFO - 2024-06-20 10:41:17 --> Loader Class Initialized
INFO - 2024-06-20 10:41:17 --> Helper loaded: url_helper
INFO - 2024-06-20 10:41:17 --> Controller Class Initialized
INFO - 2024-06-20 10:41:17 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 10:41:17 --> Final output sent to browser
DEBUG - 2024-06-20 10:41:17 --> Total execution time: 0.0242
INFO - 2024-06-20 10:41:18 --> Config Class Initialized
INFO - 2024-06-20 10:41:18 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:41:18 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:41:18 --> Utf8 Class Initialized
INFO - 2024-06-20 10:41:18 --> URI Class Initialized
INFO - 2024-06-20 10:41:18 --> Router Class Initialized
INFO - 2024-06-20 10:41:18 --> Output Class Initialized
INFO - 2024-06-20 10:41:18 --> Security Class Initialized
DEBUG - 2024-06-20 10:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:41:18 --> Input Class Initialized
INFO - 2024-06-20 10:41:18 --> Language Class Initialized
ERROR - 2024-06-20 10:41:18 --> 404 Page Not Found: Auth/loginstyle.css
INFO - 2024-06-20 10:42:20 --> Config Class Initialized
INFO - 2024-06-20 10:42:20 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:42:20 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:42:20 --> Utf8 Class Initialized
INFO - 2024-06-20 10:42:20 --> URI Class Initialized
INFO - 2024-06-20 10:42:20 --> Router Class Initialized
INFO - 2024-06-20 10:42:20 --> Output Class Initialized
INFO - 2024-06-20 10:42:20 --> Security Class Initialized
DEBUG - 2024-06-20 10:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:42:20 --> Input Class Initialized
INFO - 2024-06-20 10:42:20 --> Language Class Initialized
INFO - 2024-06-20 10:42:20 --> Loader Class Initialized
INFO - 2024-06-20 10:42:20 --> Helper loaded: url_helper
INFO - 2024-06-20 10:42:20 --> Controller Class Initialized
INFO - 2024-06-20 10:42:20 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 10:42:20 --> Final output sent to browser
DEBUG - 2024-06-20 10:42:20 --> Total execution time: 0.0296
INFO - 2024-06-20 10:42:20 --> Config Class Initialized
INFO - 2024-06-20 10:42:20 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:42:20 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:42:20 --> Utf8 Class Initialized
INFO - 2024-06-20 10:42:20 --> URI Class Initialized
INFO - 2024-06-20 10:42:20 --> Router Class Initialized
INFO - 2024-06-20 10:42:20 --> Output Class Initialized
INFO - 2024-06-20 10:42:20 --> Security Class Initialized
DEBUG - 2024-06-20 10:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:42:20 --> Input Class Initialized
INFO - 2024-06-20 10:42:20 --> Language Class Initialized
ERROR - 2024-06-20 10:42:20 --> 404 Page Not Found: Auth/loginstyle.css
INFO - 2024-06-20 10:42:21 --> Config Class Initialized
INFO - 2024-06-20 10:42:21 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:42:21 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:42:21 --> Utf8 Class Initialized
INFO - 2024-06-20 10:42:21 --> URI Class Initialized
INFO - 2024-06-20 10:42:21 --> Router Class Initialized
INFO - 2024-06-20 10:42:21 --> Output Class Initialized
INFO - 2024-06-20 10:42:21 --> Security Class Initialized
DEBUG - 2024-06-20 10:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:42:21 --> Input Class Initialized
INFO - 2024-06-20 10:42:21 --> Language Class Initialized
INFO - 2024-06-20 10:42:21 --> Loader Class Initialized
INFO - 2024-06-20 10:42:21 --> Helper loaded: url_helper
INFO - 2024-06-20 10:42:21 --> Controller Class Initialized
INFO - 2024-06-20 10:42:21 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 10:42:21 --> Final output sent to browser
DEBUG - 2024-06-20 10:42:21 --> Total execution time: 0.0293
INFO - 2024-06-20 10:42:21 --> Config Class Initialized
INFO - 2024-06-20 10:42:21 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:42:21 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:42:21 --> Utf8 Class Initialized
INFO - 2024-06-20 10:42:21 --> URI Class Initialized
INFO - 2024-06-20 10:42:21 --> Router Class Initialized
INFO - 2024-06-20 10:42:21 --> Output Class Initialized
INFO - 2024-06-20 10:42:21 --> Security Class Initialized
DEBUG - 2024-06-20 10:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:42:21 --> Input Class Initialized
INFO - 2024-06-20 10:42:21 --> Language Class Initialized
ERROR - 2024-06-20 10:42:21 --> 404 Page Not Found: Auth/loginstyle.css
INFO - 2024-06-20 10:42:25 --> Config Class Initialized
INFO - 2024-06-20 10:42:25 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:42:25 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:42:25 --> Utf8 Class Initialized
INFO - 2024-06-20 10:42:25 --> URI Class Initialized
INFO - 2024-06-20 10:42:25 --> Router Class Initialized
INFO - 2024-06-20 10:42:25 --> Output Class Initialized
INFO - 2024-06-20 10:42:25 --> Security Class Initialized
DEBUG - 2024-06-20 10:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:42:25 --> Input Class Initialized
INFO - 2024-06-20 10:42:25 --> Language Class Initialized
INFO - 2024-06-20 10:42:25 --> Loader Class Initialized
INFO - 2024-06-20 10:42:25 --> Helper loaded: url_helper
INFO - 2024-06-20 10:42:25 --> Controller Class Initialized
INFO - 2024-06-20 10:42:25 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 10:42:25 --> Final output sent to browser
DEBUG - 2024-06-20 10:42:25 --> Total execution time: 0.0288
INFO - 2024-06-20 10:42:25 --> Config Class Initialized
INFO - 2024-06-20 10:42:25 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:42:25 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:42:25 --> Utf8 Class Initialized
INFO - 2024-06-20 10:42:25 --> URI Class Initialized
INFO - 2024-06-20 10:42:25 --> Router Class Initialized
INFO - 2024-06-20 10:42:25 --> Output Class Initialized
INFO - 2024-06-20 10:42:25 --> Security Class Initialized
DEBUG - 2024-06-20 10:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:42:25 --> Input Class Initialized
INFO - 2024-06-20 10:42:25 --> Language Class Initialized
ERROR - 2024-06-20 10:42:25 --> 404 Page Not Found: Auth/loginstyle.css
INFO - 2024-06-20 10:42:27 --> Config Class Initialized
INFO - 2024-06-20 10:42:27 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:42:27 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:42:27 --> Utf8 Class Initialized
INFO - 2024-06-20 10:42:27 --> URI Class Initialized
INFO - 2024-06-20 10:42:27 --> Router Class Initialized
INFO - 2024-06-20 10:42:27 --> Output Class Initialized
INFO - 2024-06-20 10:42:27 --> Security Class Initialized
DEBUG - 2024-06-20 10:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:42:27 --> Input Class Initialized
INFO - 2024-06-20 10:42:27 --> Language Class Initialized
INFO - 2024-06-20 10:42:27 --> Loader Class Initialized
INFO - 2024-06-20 10:42:27 --> Helper loaded: url_helper
INFO - 2024-06-20 10:42:27 --> Controller Class Initialized
INFO - 2024-06-20 10:42:27 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 10:42:27 --> Final output sent to browser
DEBUG - 2024-06-20 10:42:27 --> Total execution time: 0.0286
INFO - 2024-06-20 10:42:27 --> Config Class Initialized
INFO - 2024-06-20 10:42:27 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:42:27 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:42:27 --> Utf8 Class Initialized
INFO - 2024-06-20 10:42:27 --> URI Class Initialized
INFO - 2024-06-20 10:42:27 --> Router Class Initialized
INFO - 2024-06-20 10:42:27 --> Output Class Initialized
INFO - 2024-06-20 10:42:27 --> Security Class Initialized
DEBUG - 2024-06-20 10:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:42:27 --> Input Class Initialized
INFO - 2024-06-20 10:42:27 --> Language Class Initialized
ERROR - 2024-06-20 10:42:27 --> 404 Page Not Found: Auth/loginstyle.css
INFO - 2024-06-20 10:42:36 --> Config Class Initialized
INFO - 2024-06-20 10:42:36 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:42:36 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:42:36 --> Utf8 Class Initialized
INFO - 2024-06-20 10:42:36 --> URI Class Initialized
INFO - 2024-06-20 10:42:36 --> Router Class Initialized
INFO - 2024-06-20 10:42:36 --> Output Class Initialized
INFO - 2024-06-20 10:42:36 --> Security Class Initialized
DEBUG - 2024-06-20 10:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:42:36 --> Input Class Initialized
INFO - 2024-06-20 10:42:36 --> Language Class Initialized
INFO - 2024-06-20 10:42:36 --> Loader Class Initialized
INFO - 2024-06-20 10:42:36 --> Helper loaded: url_helper
INFO - 2024-06-20 10:42:36 --> Controller Class Initialized
INFO - 2024-06-20 10:42:36 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 10:42:36 --> Final output sent to browser
DEBUG - 2024-06-20 10:42:36 --> Total execution time: 0.0313
INFO - 2024-06-20 10:42:36 --> Config Class Initialized
INFO - 2024-06-20 10:42:36 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:42:36 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:42:36 --> Utf8 Class Initialized
INFO - 2024-06-20 10:42:36 --> URI Class Initialized
INFO - 2024-06-20 10:42:36 --> Router Class Initialized
INFO - 2024-06-20 10:42:36 --> Output Class Initialized
INFO - 2024-06-20 10:42:36 --> Security Class Initialized
DEBUG - 2024-06-20 10:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:42:36 --> Input Class Initialized
INFO - 2024-06-20 10:42:36 --> Language Class Initialized
ERROR - 2024-06-20 10:42:36 --> 404 Page Not Found: Auth/loginstyle.css
INFO - 2024-06-20 10:42:57 --> Config Class Initialized
INFO - 2024-06-20 10:42:57 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:42:57 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:42:57 --> Utf8 Class Initialized
INFO - 2024-06-20 10:42:57 --> URI Class Initialized
INFO - 2024-06-20 10:42:57 --> Router Class Initialized
INFO - 2024-06-20 10:42:57 --> Output Class Initialized
INFO - 2024-06-20 10:42:57 --> Security Class Initialized
DEBUG - 2024-06-20 10:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:42:57 --> Input Class Initialized
INFO - 2024-06-20 10:42:57 --> Language Class Initialized
ERROR - 2024-06-20 10:42:57 --> 404 Page Not Found: Auth/index.php
INFO - 2024-06-20 10:43:04 --> Config Class Initialized
INFO - 2024-06-20 10:43:04 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:43:04 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:43:04 --> Utf8 Class Initialized
INFO - 2024-06-20 10:43:04 --> URI Class Initialized
INFO - 2024-06-20 10:43:04 --> Router Class Initialized
INFO - 2024-06-20 10:43:04 --> Output Class Initialized
INFO - 2024-06-20 10:43:04 --> Security Class Initialized
DEBUG - 2024-06-20 10:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:43:04 --> Input Class Initialized
INFO - 2024-06-20 10:43:04 --> Language Class Initialized
ERROR - 2024-06-20 10:43:04 --> 404 Page Not Found: Auth/index.php
INFO - 2024-06-20 10:43:21 --> Config Class Initialized
INFO - 2024-06-20 10:43:21 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:43:21 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:43:21 --> Utf8 Class Initialized
INFO - 2024-06-20 10:43:21 --> URI Class Initialized
INFO - 2024-06-20 10:43:21 --> Router Class Initialized
INFO - 2024-06-20 10:43:21 --> Output Class Initialized
INFO - 2024-06-20 10:43:21 --> Security Class Initialized
DEBUG - 2024-06-20 10:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:43:21 --> Input Class Initialized
INFO - 2024-06-20 10:43:21 --> Language Class Initialized
INFO - 2024-06-20 10:43:21 --> Loader Class Initialized
INFO - 2024-06-20 10:43:21 --> Helper loaded: url_helper
INFO - 2024-06-20 10:43:21 --> Controller Class Initialized
INFO - 2024-06-20 10:43:21 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 10:43:21 --> Final output sent to browser
DEBUG - 2024-06-20 10:43:21 --> Total execution time: 0.0250
INFO - 2024-06-20 10:43:21 --> Config Class Initialized
INFO - 2024-06-20 10:43:21 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:43:21 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:43:21 --> Utf8 Class Initialized
INFO - 2024-06-20 10:43:21 --> URI Class Initialized
INFO - 2024-06-20 10:43:21 --> Router Class Initialized
INFO - 2024-06-20 10:43:21 --> Output Class Initialized
INFO - 2024-06-20 10:43:21 --> Security Class Initialized
DEBUG - 2024-06-20 10:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:43:21 --> Input Class Initialized
INFO - 2024-06-20 10:43:21 --> Language Class Initialized
ERROR - 2024-06-20 10:43:21 --> 404 Page Not Found: Auth/loginstyle.css
INFO - 2024-06-20 10:43:22 --> Config Class Initialized
INFO - 2024-06-20 10:43:22 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:43:22 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:43:22 --> Utf8 Class Initialized
INFO - 2024-06-20 10:43:22 --> URI Class Initialized
INFO - 2024-06-20 10:43:22 --> Router Class Initialized
INFO - 2024-06-20 10:43:22 --> Output Class Initialized
INFO - 2024-06-20 10:43:22 --> Security Class Initialized
DEBUG - 2024-06-20 10:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:43:22 --> Input Class Initialized
INFO - 2024-06-20 10:43:22 --> Language Class Initialized
INFO - 2024-06-20 10:43:22 --> Loader Class Initialized
INFO - 2024-06-20 10:43:22 --> Helper loaded: url_helper
INFO - 2024-06-20 10:43:22 --> Controller Class Initialized
INFO - 2024-06-20 10:43:22 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 10:43:22 --> Final output sent to browser
DEBUG - 2024-06-20 10:43:22 --> Total execution time: 0.0300
INFO - 2024-06-20 10:43:22 --> Config Class Initialized
INFO - 2024-06-20 10:43:22 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:43:22 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:43:22 --> Utf8 Class Initialized
INFO - 2024-06-20 10:43:22 --> URI Class Initialized
INFO - 2024-06-20 10:43:22 --> Router Class Initialized
INFO - 2024-06-20 10:43:22 --> Output Class Initialized
INFO - 2024-06-20 10:43:22 --> Security Class Initialized
DEBUG - 2024-06-20 10:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:43:22 --> Input Class Initialized
INFO - 2024-06-20 10:43:22 --> Language Class Initialized
ERROR - 2024-06-20 10:43:22 --> 404 Page Not Found: Auth/loginstyle.css
INFO - 2024-06-20 10:43:23 --> Config Class Initialized
INFO - 2024-06-20 10:43:23 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:43:23 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:43:23 --> Utf8 Class Initialized
INFO - 2024-06-20 10:43:23 --> URI Class Initialized
INFO - 2024-06-20 10:43:23 --> Router Class Initialized
INFO - 2024-06-20 10:43:23 --> Output Class Initialized
INFO - 2024-06-20 10:43:23 --> Security Class Initialized
DEBUG - 2024-06-20 10:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:43:23 --> Input Class Initialized
INFO - 2024-06-20 10:43:23 --> Language Class Initialized
INFO - 2024-06-20 10:43:23 --> Loader Class Initialized
INFO - 2024-06-20 10:43:23 --> Helper loaded: url_helper
INFO - 2024-06-20 10:43:23 --> Controller Class Initialized
INFO - 2024-06-20 10:43:23 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 10:43:23 --> Final output sent to browser
DEBUG - 2024-06-20 10:43:23 --> Total execution time: 0.0288
INFO - 2024-06-20 10:43:23 --> Config Class Initialized
INFO - 2024-06-20 10:43:23 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:43:23 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:43:23 --> Utf8 Class Initialized
INFO - 2024-06-20 10:43:23 --> URI Class Initialized
INFO - 2024-06-20 10:43:23 --> Router Class Initialized
INFO - 2024-06-20 10:43:23 --> Output Class Initialized
INFO - 2024-06-20 10:43:23 --> Security Class Initialized
DEBUG - 2024-06-20 10:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:43:23 --> Input Class Initialized
INFO - 2024-06-20 10:43:23 --> Language Class Initialized
ERROR - 2024-06-20 10:43:23 --> 404 Page Not Found: Auth/loginstyle.css
INFO - 2024-06-20 10:43:39 --> Config Class Initialized
INFO - 2024-06-20 10:43:39 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:43:39 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:43:39 --> Utf8 Class Initialized
INFO - 2024-06-20 10:43:39 --> URI Class Initialized
INFO - 2024-06-20 10:43:39 --> Router Class Initialized
INFO - 2024-06-20 10:43:39 --> Output Class Initialized
INFO - 2024-06-20 10:43:39 --> Security Class Initialized
DEBUG - 2024-06-20 10:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:43:39 --> Input Class Initialized
INFO - 2024-06-20 10:43:39 --> Language Class Initialized
INFO - 2024-06-20 10:43:39 --> Loader Class Initialized
INFO - 2024-06-20 10:43:39 --> Helper loaded: url_helper
INFO - 2024-06-20 10:43:39 --> Controller Class Initialized
INFO - 2024-06-20 10:43:39 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 10:43:39 --> Final output sent to browser
DEBUG - 2024-06-20 10:43:39 --> Total execution time: 0.0286
INFO - 2024-06-20 10:43:39 --> Config Class Initialized
INFO - 2024-06-20 10:43:39 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:43:39 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:43:39 --> Utf8 Class Initialized
INFO - 2024-06-20 10:43:39 --> URI Class Initialized
INFO - 2024-06-20 10:43:39 --> Router Class Initialized
INFO - 2024-06-20 10:43:39 --> Output Class Initialized
INFO - 2024-06-20 10:43:39 --> Security Class Initialized
DEBUG - 2024-06-20 10:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:43:39 --> Input Class Initialized
INFO - 2024-06-20 10:43:39 --> Language Class Initialized
ERROR - 2024-06-20 10:43:39 --> 404 Page Not Found: Auth/loginstyle.css
INFO - 2024-06-20 10:43:40 --> Config Class Initialized
INFO - 2024-06-20 10:43:40 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:43:40 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:43:40 --> Utf8 Class Initialized
INFO - 2024-06-20 10:43:40 --> URI Class Initialized
INFO - 2024-06-20 10:43:40 --> Router Class Initialized
INFO - 2024-06-20 10:43:40 --> Output Class Initialized
INFO - 2024-06-20 10:43:40 --> Security Class Initialized
DEBUG - 2024-06-20 10:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:43:40 --> Input Class Initialized
INFO - 2024-06-20 10:43:40 --> Language Class Initialized
INFO - 2024-06-20 10:43:40 --> Loader Class Initialized
INFO - 2024-06-20 10:43:40 --> Helper loaded: url_helper
INFO - 2024-06-20 10:43:40 --> Controller Class Initialized
INFO - 2024-06-20 10:43:40 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 10:43:40 --> Final output sent to browser
DEBUG - 2024-06-20 10:43:40 --> Total execution time: 0.0316
INFO - 2024-06-20 10:43:42 --> Config Class Initialized
INFO - 2024-06-20 10:43:42 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:43:42 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:43:42 --> Utf8 Class Initialized
INFO - 2024-06-20 10:43:42 --> URI Class Initialized
INFO - 2024-06-20 10:43:42 --> Router Class Initialized
INFO - 2024-06-20 10:43:42 --> Output Class Initialized
INFO - 2024-06-20 10:43:42 --> Security Class Initialized
DEBUG - 2024-06-20 10:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:43:42 --> Input Class Initialized
INFO - 2024-06-20 10:43:42 --> Language Class Initialized
INFO - 2024-06-20 10:43:42 --> Loader Class Initialized
INFO - 2024-06-20 10:43:42 --> Helper loaded: url_helper
INFO - 2024-06-20 10:43:42 --> Controller Class Initialized
INFO - 2024-06-20 10:43:42 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 10:43:42 --> Final output sent to browser
DEBUG - 2024-06-20 10:43:42 --> Total execution time: 0.0322
INFO - 2024-06-20 10:43:42 --> Config Class Initialized
INFO - 2024-06-20 10:43:42 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:43:42 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:43:42 --> Utf8 Class Initialized
INFO - 2024-06-20 10:43:42 --> URI Class Initialized
INFO - 2024-06-20 10:43:42 --> Router Class Initialized
INFO - 2024-06-20 10:43:42 --> Output Class Initialized
INFO - 2024-06-20 10:43:42 --> Security Class Initialized
DEBUG - 2024-06-20 10:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:43:42 --> Input Class Initialized
INFO - 2024-06-20 10:43:42 --> Language Class Initialized
ERROR - 2024-06-20 10:43:42 --> 404 Page Not Found: Auth/loginstyle.css
INFO - 2024-06-20 10:44:24 --> Config Class Initialized
INFO - 2024-06-20 10:44:24 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:44:24 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:44:24 --> Utf8 Class Initialized
INFO - 2024-06-20 10:44:24 --> URI Class Initialized
INFO - 2024-06-20 10:44:24 --> Router Class Initialized
INFO - 2024-06-20 10:44:24 --> Output Class Initialized
INFO - 2024-06-20 10:44:24 --> Security Class Initialized
DEBUG - 2024-06-20 10:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:44:24 --> Input Class Initialized
INFO - 2024-06-20 10:44:24 --> Language Class Initialized
INFO - 2024-06-20 10:44:24 --> Loader Class Initialized
INFO - 2024-06-20 10:44:24 --> Helper loaded: url_helper
INFO - 2024-06-20 10:44:24 --> Controller Class Initialized
INFO - 2024-06-20 10:44:24 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 10:44:24 --> Final output sent to browser
DEBUG - 2024-06-20 10:44:24 --> Total execution time: 0.0349
INFO - 2024-06-20 10:53:20 --> Config Class Initialized
INFO - 2024-06-20 10:53:20 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:53:20 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:53:20 --> Utf8 Class Initialized
INFO - 2024-06-20 10:53:20 --> URI Class Initialized
INFO - 2024-06-20 10:53:20 --> Router Class Initialized
INFO - 2024-06-20 10:53:20 --> Output Class Initialized
INFO - 2024-06-20 10:53:20 --> Security Class Initialized
DEBUG - 2024-06-20 10:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:53:20 --> Input Class Initialized
INFO - 2024-06-20 10:53:20 --> Language Class Initialized
INFO - 2024-06-20 10:53:20 --> Loader Class Initialized
INFO - 2024-06-20 10:53:20 --> Helper loaded: url_helper
INFO - 2024-06-20 10:53:20 --> Controller Class Initialized
ERROR - 2024-06-20 10:53:20 --> Severity: error --> Exception: Call to undefined function set_value() D:\xampp\htdocs\Blog\application\views\auth\registration.php 21
INFO - 2024-06-20 10:54:38 --> Config Class Initialized
INFO - 2024-06-20 10:54:38 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:54:38 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:54:38 --> Utf8 Class Initialized
INFO - 2024-06-20 10:54:38 --> URI Class Initialized
INFO - 2024-06-20 10:54:38 --> Router Class Initialized
INFO - 2024-06-20 10:54:38 --> Output Class Initialized
INFO - 2024-06-20 10:54:38 --> Security Class Initialized
DEBUG - 2024-06-20 10:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:54:38 --> Input Class Initialized
INFO - 2024-06-20 10:54:38 --> Language Class Initialized
INFO - 2024-06-20 10:54:38 --> Loader Class Initialized
INFO - 2024-06-20 10:54:38 --> Helper loaded: url_helper
INFO - 2024-06-20 10:54:38 --> Controller Class Initialized
ERROR - 2024-06-20 10:54:38 --> Severity: error --> Exception: Call to undefined function set_value() D:\xampp\htdocs\Blog\application\views\auth\registration.php 21
INFO - 2024-06-20 10:55:29 --> Config Class Initialized
INFO - 2024-06-20 10:55:29 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:55:29 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:55:29 --> Utf8 Class Initialized
INFO - 2024-06-20 10:55:29 --> URI Class Initialized
INFO - 2024-06-20 10:55:29 --> Router Class Initialized
INFO - 2024-06-20 10:55:29 --> Output Class Initialized
INFO - 2024-06-20 10:55:29 --> Security Class Initialized
DEBUG - 2024-06-20 10:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:55:29 --> Input Class Initialized
INFO - 2024-06-20 10:55:29 --> Language Class Initialized
INFO - 2024-06-20 10:55:29 --> Loader Class Initialized
INFO - 2024-06-20 10:55:29 --> Helper loaded: url_helper
INFO - 2024-06-20 10:55:30 --> Helper loaded: form_helper
INFO - 2024-06-20 10:55:30 --> Controller Class Initialized
INFO - 2024-06-20 10:55:30 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 10:55:30 --> Final output sent to browser
DEBUG - 2024-06-20 10:55:30 --> Total execution time: 0.0962
INFO - 2024-06-20 10:55:42 --> Config Class Initialized
INFO - 2024-06-20 10:55:42 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:55:42 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:55:42 --> Utf8 Class Initialized
INFO - 2024-06-20 10:55:42 --> URI Class Initialized
INFO - 2024-06-20 10:55:42 --> Router Class Initialized
INFO - 2024-06-20 10:55:42 --> Output Class Initialized
INFO - 2024-06-20 10:55:42 --> Security Class Initialized
DEBUG - 2024-06-20 10:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:55:42 --> Input Class Initialized
INFO - 2024-06-20 10:55:42 --> Language Class Initialized
INFO - 2024-06-20 10:55:42 --> Loader Class Initialized
INFO - 2024-06-20 10:55:42 --> Helper loaded: url_helper
INFO - 2024-06-20 10:55:42 --> Helper loaded: form_helper
INFO - 2024-06-20 10:55:42 --> Controller Class Initialized
INFO - 2024-06-20 10:55:42 --> Form Validation Class Initialized
INFO - 2024-06-20 10:55:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-20 10:55:42 --> Model "Auth_model" initialized
ERROR - 2024-06-20 10:55:42 --> Severity: Warning --> Undefined property: Auth::$db D:\xampp\htdocs\Blog\system\core\Model.php 74
ERROR - 2024-06-20 10:55:42 --> Severity: error --> Exception: Call to a member function get_where() on null D:\xampp\htdocs\Blog\application\models\Auth_model.php 7
INFO - 2024-06-20 10:56:11 --> Config Class Initialized
INFO - 2024-06-20 10:56:11 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:56:11 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:56:11 --> Utf8 Class Initialized
INFO - 2024-06-20 10:56:11 --> URI Class Initialized
INFO - 2024-06-20 10:56:11 --> Router Class Initialized
INFO - 2024-06-20 10:56:11 --> Output Class Initialized
INFO - 2024-06-20 10:56:11 --> Security Class Initialized
DEBUG - 2024-06-20 10:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:56:11 --> Input Class Initialized
INFO - 2024-06-20 10:56:11 --> Language Class Initialized
INFO - 2024-06-20 10:56:11 --> Loader Class Initialized
INFO - 2024-06-20 10:56:11 --> Helper loaded: url_helper
INFO - 2024-06-20 10:56:11 --> Helper loaded: form_helper
INFO - 2024-06-20 10:56:11 --> Controller Class Initialized
INFO - 2024-06-20 10:56:11 --> Form Validation Class Initialized
INFO - 2024-06-20 10:56:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-20 10:56:11 --> Model "Auth_model" initialized
ERROR - 2024-06-20 10:56:11 --> Severity: Warning --> Undefined property: Auth::$db D:\xampp\htdocs\Blog\system\core\Model.php 74
ERROR - 2024-06-20 10:56:11 --> Severity: error --> Exception: Call to a member function get_where() on null D:\xampp\htdocs\Blog\application\models\Auth_model.php 8
INFO - 2024-06-20 10:57:29 --> Config Class Initialized
INFO - 2024-06-20 10:57:29 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:57:29 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:57:29 --> Utf8 Class Initialized
INFO - 2024-06-20 10:57:29 --> URI Class Initialized
INFO - 2024-06-20 10:57:29 --> Router Class Initialized
INFO - 2024-06-20 10:57:29 --> Output Class Initialized
INFO - 2024-06-20 10:57:29 --> Security Class Initialized
DEBUG - 2024-06-20 10:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:57:29 --> Input Class Initialized
INFO - 2024-06-20 10:57:29 --> Language Class Initialized
INFO - 2024-06-20 10:57:29 --> Loader Class Initialized
INFO - 2024-06-20 10:57:29 --> Helper loaded: url_helper
INFO - 2024-06-20 10:57:29 --> Helper loaded: form_helper
INFO - 2024-06-20 10:57:29 --> Controller Class Initialized
INFO - 2024-06-20 10:57:29 --> Database Driver Class Initialized
INFO - 2024-06-20 10:57:29 --> Model "Auth_model" initialized
INFO - 2024-06-20 10:57:29 --> Form Validation Class Initialized
INFO - 2024-06-20 10:57:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-20 10:57:29 --> Config Class Initialized
INFO - 2024-06-20 10:57:29 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:57:29 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:57:29 --> Utf8 Class Initialized
INFO - 2024-06-20 10:57:29 --> URI Class Initialized
INFO - 2024-06-20 10:57:29 --> Router Class Initialized
INFO - 2024-06-20 10:57:29 --> Output Class Initialized
INFO - 2024-06-20 10:57:29 --> Security Class Initialized
DEBUG - 2024-06-20 10:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:57:29 --> Input Class Initialized
INFO - 2024-06-20 10:57:29 --> Language Class Initialized
INFO - 2024-06-20 10:57:29 --> Loader Class Initialized
INFO - 2024-06-20 10:57:29 --> Helper loaded: url_helper
INFO - 2024-06-20 10:57:29 --> Helper loaded: form_helper
INFO - 2024-06-20 10:57:29 --> Controller Class Initialized
INFO - 2024-06-20 10:57:29 --> Database Driver Class Initialized
INFO - 2024-06-20 10:57:29 --> Model "Auth_model" initialized
INFO - 2024-06-20 10:57:29 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 10:57:29 --> Final output sent to browser
DEBUG - 2024-06-20 10:57:29 --> Total execution time: 0.0345
INFO - 2024-06-20 10:59:56 --> Config Class Initialized
INFO - 2024-06-20 10:59:56 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:59:56 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:59:56 --> Utf8 Class Initialized
INFO - 2024-06-20 10:59:56 --> URI Class Initialized
INFO - 2024-06-20 10:59:56 --> Router Class Initialized
INFO - 2024-06-20 10:59:56 --> Output Class Initialized
INFO - 2024-06-20 10:59:56 --> Security Class Initialized
DEBUG - 2024-06-20 10:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:59:56 --> Input Class Initialized
INFO - 2024-06-20 10:59:56 --> Language Class Initialized
INFO - 2024-06-20 10:59:56 --> Loader Class Initialized
INFO - 2024-06-20 10:59:56 --> Helper loaded: url_helper
INFO - 2024-06-20 10:59:56 --> Helper loaded: form_helper
INFO - 2024-06-20 10:59:56 --> Controller Class Initialized
INFO - 2024-06-20 10:59:56 --> Database Driver Class Initialized
INFO - 2024-06-20 10:59:56 --> Model "Auth_model" initialized
INFO - 2024-06-20 10:59:56 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 10:59:56 --> Final output sent to browser
DEBUG - 2024-06-20 10:59:56 --> Total execution time: 0.0435
INFO - 2024-06-20 11:00:00 --> Config Class Initialized
INFO - 2024-06-20 11:00:00 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:00:00 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:00:00 --> Utf8 Class Initialized
INFO - 2024-06-20 11:00:00 --> URI Class Initialized
INFO - 2024-06-20 11:00:00 --> Router Class Initialized
INFO - 2024-06-20 11:00:00 --> Output Class Initialized
INFO - 2024-06-20 11:00:00 --> Security Class Initialized
DEBUG - 2024-06-20 11:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:00:00 --> Input Class Initialized
INFO - 2024-06-20 11:00:00 --> Language Class Initialized
INFO - 2024-06-20 11:00:00 --> Loader Class Initialized
INFO - 2024-06-20 11:00:00 --> Helper loaded: url_helper
INFO - 2024-06-20 11:00:00 --> Helper loaded: form_helper
INFO - 2024-06-20 11:00:00 --> Controller Class Initialized
INFO - 2024-06-20 11:00:00 --> Database Driver Class Initialized
INFO - 2024-06-20 11:00:00 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:00:00 --> Form Validation Class Initialized
INFO - 2024-06-20 11:00:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-20 11:00:06 --> Config Class Initialized
INFO - 2024-06-20 11:00:06 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:00:06 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:00:06 --> Utf8 Class Initialized
INFO - 2024-06-20 11:00:06 --> URI Class Initialized
INFO - 2024-06-20 11:00:06 --> Router Class Initialized
INFO - 2024-06-20 11:00:06 --> Output Class Initialized
INFO - 2024-06-20 11:00:06 --> Security Class Initialized
DEBUG - 2024-06-20 11:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:00:06 --> Input Class Initialized
INFO - 2024-06-20 11:00:06 --> Language Class Initialized
INFO - 2024-06-20 11:00:06 --> Loader Class Initialized
INFO - 2024-06-20 11:00:06 --> Helper loaded: url_helper
INFO - 2024-06-20 11:00:06 --> Helper loaded: form_helper
INFO - 2024-06-20 11:00:06 --> Controller Class Initialized
INFO - 2024-06-20 11:00:06 --> Database Driver Class Initialized
INFO - 2024-06-20 11:00:06 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:00:06 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 11:00:06 --> Final output sent to browser
DEBUG - 2024-06-20 11:00:06 --> Total execution time: 0.0381
INFO - 2024-06-20 11:00:15 --> Config Class Initialized
INFO - 2024-06-20 11:00:15 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:00:15 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:00:15 --> Utf8 Class Initialized
INFO - 2024-06-20 11:00:15 --> URI Class Initialized
INFO - 2024-06-20 11:00:15 --> Router Class Initialized
INFO - 2024-06-20 11:00:15 --> Output Class Initialized
INFO - 2024-06-20 11:00:15 --> Security Class Initialized
DEBUG - 2024-06-20 11:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:00:15 --> Input Class Initialized
INFO - 2024-06-20 11:00:15 --> Language Class Initialized
INFO - 2024-06-20 11:00:15 --> Loader Class Initialized
INFO - 2024-06-20 11:00:15 --> Helper loaded: url_helper
INFO - 2024-06-20 11:00:15 --> Helper loaded: form_helper
INFO - 2024-06-20 11:00:15 --> Controller Class Initialized
INFO - 2024-06-20 11:00:15 --> Database Driver Class Initialized
INFO - 2024-06-20 11:00:15 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:00:15 --> Form Validation Class Initialized
INFO - 2024-06-20 11:00:15 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-06-20 11:00:16 --> Severity: Warning --> Undefined property: Auth::$session D:\xampp\htdocs\Blog\application\controllers\Auth.php 40
ERROR - 2024-06-20 11:00:16 --> Severity: error --> Exception: Call to a member function set_flashdata() on null D:\xampp\htdocs\Blog\application\controllers\Auth.php 40
INFO - 2024-06-20 11:00:23 --> Config Class Initialized
INFO - 2024-06-20 11:00:23 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:00:23 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:00:23 --> Utf8 Class Initialized
INFO - 2024-06-20 11:00:23 --> URI Class Initialized
INFO - 2024-06-20 11:00:23 --> Router Class Initialized
INFO - 2024-06-20 11:00:23 --> Output Class Initialized
INFO - 2024-06-20 11:00:23 --> Security Class Initialized
DEBUG - 2024-06-20 11:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:00:23 --> Input Class Initialized
INFO - 2024-06-20 11:00:23 --> Language Class Initialized
INFO - 2024-06-20 11:00:23 --> Loader Class Initialized
INFO - 2024-06-20 11:00:23 --> Helper loaded: url_helper
INFO - 2024-06-20 11:00:23 --> Helper loaded: form_helper
INFO - 2024-06-20 11:00:23 --> Controller Class Initialized
INFO - 2024-06-20 11:00:23 --> Database Driver Class Initialized
INFO - 2024-06-20 11:00:23 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:00:23 --> Form Validation Class Initialized
INFO - 2024-06-20 11:00:23 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-06-20 11:00:23 --> Severity: Warning --> Undefined property: Auth::$session D:\xampp\htdocs\Blog\application\controllers\Auth.php 42
ERROR - 2024-06-20 11:00:23 --> Severity: error --> Exception: Call to a member function set_flashdata() on null D:\xampp\htdocs\Blog\application\controllers\Auth.php 42
INFO - 2024-06-20 11:00:38 --> Config Class Initialized
INFO - 2024-06-20 11:00:38 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:00:38 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:00:38 --> Utf8 Class Initialized
INFO - 2024-06-20 11:00:38 --> URI Class Initialized
INFO - 2024-06-20 11:00:38 --> Router Class Initialized
INFO - 2024-06-20 11:00:38 --> Output Class Initialized
INFO - 2024-06-20 11:00:38 --> Security Class Initialized
DEBUG - 2024-06-20 11:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:00:38 --> Input Class Initialized
INFO - 2024-06-20 11:00:38 --> Language Class Initialized
INFO - 2024-06-20 11:00:38 --> Loader Class Initialized
INFO - 2024-06-20 11:00:38 --> Helper loaded: url_helper
INFO - 2024-06-20 11:00:38 --> Helper loaded: form_helper
INFO - 2024-06-20 11:01:07 --> Config Class Initialized
INFO - 2024-06-20 11:01:07 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:01:07 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:01:07 --> Utf8 Class Initialized
INFO - 2024-06-20 11:01:07 --> URI Class Initialized
INFO - 2024-06-20 11:01:07 --> Router Class Initialized
INFO - 2024-06-20 11:01:07 --> Output Class Initialized
INFO - 2024-06-20 11:01:07 --> Security Class Initialized
DEBUG - 2024-06-20 11:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:01:07 --> Input Class Initialized
INFO - 2024-06-20 11:01:07 --> Language Class Initialized
INFO - 2024-06-20 11:01:07 --> Loader Class Initialized
INFO - 2024-06-20 11:01:07 --> Helper loaded: url_helper
INFO - 2024-06-20 11:01:07 --> Helper loaded: form_helper
INFO - 2024-06-20 11:01:10 --> Config Class Initialized
INFO - 2024-06-20 11:01:10 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:01:10 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:01:10 --> Utf8 Class Initialized
INFO - 2024-06-20 11:01:10 --> URI Class Initialized
INFO - 2024-06-20 11:01:10 --> Router Class Initialized
INFO - 2024-06-20 11:01:10 --> Output Class Initialized
INFO - 2024-06-20 11:01:10 --> Security Class Initialized
DEBUG - 2024-06-20 11:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:01:10 --> Input Class Initialized
INFO - 2024-06-20 11:01:10 --> Language Class Initialized
INFO - 2024-06-20 11:01:10 --> Loader Class Initialized
INFO - 2024-06-20 11:01:10 --> Helper loaded: url_helper
INFO - 2024-06-20 11:01:10 --> Helper loaded: form_helper
INFO - 2024-06-20 11:01:13 --> Config Class Initialized
INFO - 2024-06-20 11:01:13 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:01:13 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:01:13 --> Utf8 Class Initialized
INFO - 2024-06-20 11:01:13 --> URI Class Initialized
INFO - 2024-06-20 11:01:13 --> Router Class Initialized
INFO - 2024-06-20 11:01:13 --> Output Class Initialized
INFO - 2024-06-20 11:01:13 --> Security Class Initialized
DEBUG - 2024-06-20 11:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:01:13 --> Input Class Initialized
INFO - 2024-06-20 11:01:13 --> Language Class Initialized
INFO - 2024-06-20 11:01:13 --> Loader Class Initialized
INFO - 2024-06-20 11:01:13 --> Helper loaded: url_helper
INFO - 2024-06-20 11:01:13 --> Helper loaded: form_helper
INFO - 2024-06-20 11:02:08 --> Config Class Initialized
INFO - 2024-06-20 11:02:08 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:02:08 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:02:08 --> Utf8 Class Initialized
INFO - 2024-06-20 11:02:08 --> URI Class Initialized
INFO - 2024-06-20 11:02:08 --> Router Class Initialized
INFO - 2024-06-20 11:02:08 --> Output Class Initialized
INFO - 2024-06-20 11:02:08 --> Security Class Initialized
DEBUG - 2024-06-20 11:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:02:08 --> Input Class Initialized
INFO - 2024-06-20 11:02:08 --> Language Class Initialized
INFO - 2024-06-20 11:02:08 --> Loader Class Initialized
INFO - 2024-06-20 11:02:08 --> Helper loaded: url_helper
INFO - 2024-06-20 11:02:08 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:02:09 --> Controller Class Initialized
INFO - 2024-06-20 11:02:09 --> Database Driver Class Initialized
INFO - 2024-06-20 11:02:09 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:02:09 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 11:02:09 --> Final output sent to browser
DEBUG - 2024-06-20 11:02:09 --> Total execution time: 0.8661
INFO - 2024-06-20 11:02:16 --> Config Class Initialized
INFO - 2024-06-20 11:02:16 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:02:16 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:02:16 --> Utf8 Class Initialized
INFO - 2024-06-20 11:02:16 --> URI Class Initialized
INFO - 2024-06-20 11:02:16 --> Router Class Initialized
INFO - 2024-06-20 11:02:16 --> Output Class Initialized
INFO - 2024-06-20 11:02:16 --> Security Class Initialized
DEBUG - 2024-06-20 11:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:02:16 --> Input Class Initialized
INFO - 2024-06-20 11:02:16 --> Language Class Initialized
INFO - 2024-06-20 11:02:16 --> Loader Class Initialized
INFO - 2024-06-20 11:02:16 --> Helper loaded: url_helper
INFO - 2024-06-20 11:02:16 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:02:16 --> Controller Class Initialized
INFO - 2024-06-20 11:02:16 --> Database Driver Class Initialized
INFO - 2024-06-20 11:02:16 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:02:16 --> Form Validation Class Initialized
INFO - 2024-06-20 11:02:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-20 11:02:18 --> Config Class Initialized
INFO - 2024-06-20 11:02:18 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:02:18 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:02:18 --> Utf8 Class Initialized
INFO - 2024-06-20 11:02:18 --> URI Class Initialized
INFO - 2024-06-20 11:02:18 --> Router Class Initialized
INFO - 2024-06-20 11:02:18 --> Output Class Initialized
INFO - 2024-06-20 11:02:18 --> Security Class Initialized
DEBUG - 2024-06-20 11:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:02:18 --> Input Class Initialized
INFO - 2024-06-20 11:02:18 --> Language Class Initialized
INFO - 2024-06-20 11:02:18 --> Loader Class Initialized
INFO - 2024-06-20 11:02:18 --> Helper loaded: url_helper
INFO - 2024-06-20 11:02:18 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:02:18 --> Controller Class Initialized
INFO - 2024-06-20 11:02:18 --> Database Driver Class Initialized
INFO - 2024-06-20 11:02:18 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:02:18 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 11:02:18 --> Final output sent to browser
DEBUG - 2024-06-20 11:02:18 --> Total execution time: 0.0523
INFO - 2024-06-20 11:02:25 --> Config Class Initialized
INFO - 2024-06-20 11:02:25 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:02:25 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:02:25 --> Utf8 Class Initialized
INFO - 2024-06-20 11:02:25 --> URI Class Initialized
INFO - 2024-06-20 11:02:25 --> Router Class Initialized
INFO - 2024-06-20 11:02:25 --> Output Class Initialized
INFO - 2024-06-20 11:02:25 --> Security Class Initialized
DEBUG - 2024-06-20 11:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:02:25 --> Input Class Initialized
INFO - 2024-06-20 11:02:25 --> Language Class Initialized
INFO - 2024-06-20 11:02:25 --> Loader Class Initialized
INFO - 2024-06-20 11:02:25 --> Helper loaded: url_helper
INFO - 2024-06-20 11:02:25 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:02:25 --> Controller Class Initialized
INFO - 2024-06-20 11:02:25 --> Database Driver Class Initialized
INFO - 2024-06-20 11:02:25 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:02:25 --> Form Validation Class Initialized
INFO - 2024-06-20 11:02:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-20 11:02:51 --> Config Class Initialized
INFO - 2024-06-20 11:02:51 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:02:51 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:02:51 --> Utf8 Class Initialized
INFO - 2024-06-20 11:02:51 --> URI Class Initialized
INFO - 2024-06-20 11:02:51 --> Router Class Initialized
INFO - 2024-06-20 11:02:51 --> Output Class Initialized
INFO - 2024-06-20 11:02:51 --> Security Class Initialized
DEBUG - 2024-06-20 11:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:02:51 --> Input Class Initialized
INFO - 2024-06-20 11:02:51 --> Language Class Initialized
INFO - 2024-06-20 11:02:51 --> Loader Class Initialized
INFO - 2024-06-20 11:02:51 --> Helper loaded: url_helper
INFO - 2024-06-20 11:02:51 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:02:51 --> Controller Class Initialized
INFO - 2024-06-20 11:02:51 --> Database Driver Class Initialized
INFO - 2024-06-20 11:02:51 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:02:51 --> Form Validation Class Initialized
INFO - 2024-06-20 11:02:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-20 11:02:51 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 11:02:51 --> Final output sent to browser
DEBUG - 2024-06-20 11:02:51 --> Total execution time: 0.0597
INFO - 2024-06-20 11:03:14 --> Config Class Initialized
INFO - 2024-06-20 11:03:14 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:03:14 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:03:14 --> Utf8 Class Initialized
INFO - 2024-06-20 11:03:14 --> URI Class Initialized
INFO - 2024-06-20 11:03:14 --> Router Class Initialized
INFO - 2024-06-20 11:03:14 --> Output Class Initialized
INFO - 2024-06-20 11:03:14 --> Security Class Initialized
DEBUG - 2024-06-20 11:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:03:14 --> Input Class Initialized
INFO - 2024-06-20 11:03:14 --> Language Class Initialized
INFO - 2024-06-20 11:03:14 --> Loader Class Initialized
INFO - 2024-06-20 11:03:14 --> Helper loaded: url_helper
INFO - 2024-06-20 11:03:14 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:03:14 --> Controller Class Initialized
INFO - 2024-06-20 11:03:14 --> Database Driver Class Initialized
INFO - 2024-06-20 11:03:14 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:03:14 --> Form Validation Class Initialized
INFO - 2024-06-20 11:03:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-20 11:03:14 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 11:03:14 --> Final output sent to browser
DEBUG - 2024-06-20 11:03:14 --> Total execution time: 0.0484
INFO - 2024-06-20 11:03:26 --> Config Class Initialized
INFO - 2024-06-20 11:03:26 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:03:26 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:03:26 --> Utf8 Class Initialized
INFO - 2024-06-20 11:03:26 --> URI Class Initialized
INFO - 2024-06-20 11:03:26 --> Router Class Initialized
INFO - 2024-06-20 11:03:26 --> Output Class Initialized
INFO - 2024-06-20 11:03:26 --> Security Class Initialized
DEBUG - 2024-06-20 11:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:03:26 --> Input Class Initialized
INFO - 2024-06-20 11:03:26 --> Language Class Initialized
INFO - 2024-06-20 11:03:26 --> Loader Class Initialized
INFO - 2024-06-20 11:03:26 --> Helper loaded: url_helper
INFO - 2024-06-20 11:03:26 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:03:26 --> Controller Class Initialized
INFO - 2024-06-20 11:03:26 --> Database Driver Class Initialized
INFO - 2024-06-20 11:03:26 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:03:26 --> Form Validation Class Initialized
INFO - 2024-06-20 11:03:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-20 11:03:26 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 11:03:26 --> Final output sent to browser
DEBUG - 2024-06-20 11:03:26 --> Total execution time: 0.0674
INFO - 2024-06-20 11:03:28 --> Config Class Initialized
INFO - 2024-06-20 11:03:28 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:03:28 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:03:28 --> Utf8 Class Initialized
INFO - 2024-06-20 11:03:28 --> URI Class Initialized
INFO - 2024-06-20 11:03:28 --> Router Class Initialized
INFO - 2024-06-20 11:03:28 --> Output Class Initialized
INFO - 2024-06-20 11:03:28 --> Security Class Initialized
DEBUG - 2024-06-20 11:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:03:28 --> Input Class Initialized
INFO - 2024-06-20 11:03:28 --> Language Class Initialized
INFO - 2024-06-20 11:03:28 --> Loader Class Initialized
INFO - 2024-06-20 11:03:28 --> Helper loaded: url_helper
INFO - 2024-06-20 11:03:28 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:03:28 --> Controller Class Initialized
INFO - 2024-06-20 11:03:28 --> Database Driver Class Initialized
INFO - 2024-06-20 11:03:28 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:03:28 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:03:28 --> Final output sent to browser
DEBUG - 2024-06-20 11:03:28 --> Total execution time: 0.0841
INFO - 2024-06-20 11:03:33 --> Config Class Initialized
INFO - 2024-06-20 11:03:33 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:03:33 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:03:33 --> Utf8 Class Initialized
INFO - 2024-06-20 11:03:33 --> URI Class Initialized
INFO - 2024-06-20 11:03:33 --> Router Class Initialized
INFO - 2024-06-20 11:03:33 --> Output Class Initialized
INFO - 2024-06-20 11:03:33 --> Security Class Initialized
DEBUG - 2024-06-20 11:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:03:33 --> Input Class Initialized
INFO - 2024-06-20 11:03:33 --> Language Class Initialized
INFO - 2024-06-20 11:03:33 --> Loader Class Initialized
INFO - 2024-06-20 11:03:33 --> Helper loaded: url_helper
INFO - 2024-06-20 11:03:33 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:03:33 --> Controller Class Initialized
INFO - 2024-06-20 11:03:33 --> Database Driver Class Initialized
INFO - 2024-06-20 11:03:33 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:03:33 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 11:03:33 --> Final output sent to browser
DEBUG - 2024-06-20 11:03:33 --> Total execution time: 0.0423
INFO - 2024-06-20 11:03:41 --> Config Class Initialized
INFO - 2024-06-20 11:03:41 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:03:41 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:03:41 --> Utf8 Class Initialized
INFO - 2024-06-20 11:03:41 --> URI Class Initialized
INFO - 2024-06-20 11:03:41 --> Router Class Initialized
INFO - 2024-06-20 11:03:41 --> Output Class Initialized
INFO - 2024-06-20 11:03:41 --> Security Class Initialized
DEBUG - 2024-06-20 11:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:03:41 --> Input Class Initialized
INFO - 2024-06-20 11:03:41 --> Language Class Initialized
INFO - 2024-06-20 11:03:41 --> Loader Class Initialized
INFO - 2024-06-20 11:03:41 --> Helper loaded: url_helper
INFO - 2024-06-20 11:03:41 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:03:41 --> Controller Class Initialized
INFO - 2024-06-20 11:03:41 --> Database Driver Class Initialized
INFO - 2024-06-20 11:03:41 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:03:41 --> Form Validation Class Initialized
INFO - 2024-06-20 11:03:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-20 11:03:41 --> Config Class Initialized
INFO - 2024-06-20 11:03:41 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:03:41 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:03:41 --> Utf8 Class Initialized
INFO - 2024-06-20 11:03:41 --> URI Class Initialized
INFO - 2024-06-20 11:03:41 --> Router Class Initialized
INFO - 2024-06-20 11:03:41 --> Output Class Initialized
INFO - 2024-06-20 11:03:41 --> Security Class Initialized
DEBUG - 2024-06-20 11:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:03:41 --> Input Class Initialized
INFO - 2024-06-20 11:03:41 --> Language Class Initialized
INFO - 2024-06-20 11:03:41 --> Loader Class Initialized
INFO - 2024-06-20 11:03:41 --> Helper loaded: url_helper
INFO - 2024-06-20 11:03:41 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:03:41 --> Controller Class Initialized
INFO - 2024-06-20 11:03:41 --> Database Driver Class Initialized
INFO - 2024-06-20 11:03:41 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:03:41 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:03:41 --> Final output sent to browser
DEBUG - 2024-06-20 11:03:41 --> Total execution time: 0.0582
INFO - 2024-06-20 11:03:53 --> Config Class Initialized
INFO - 2024-06-20 11:03:53 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:03:53 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:03:53 --> Utf8 Class Initialized
INFO - 2024-06-20 11:03:53 --> URI Class Initialized
INFO - 2024-06-20 11:03:53 --> Router Class Initialized
INFO - 2024-06-20 11:03:53 --> Output Class Initialized
INFO - 2024-06-20 11:03:53 --> Security Class Initialized
DEBUG - 2024-06-20 11:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:03:53 --> Input Class Initialized
INFO - 2024-06-20 11:03:53 --> Language Class Initialized
INFO - 2024-06-20 11:03:53 --> Loader Class Initialized
INFO - 2024-06-20 11:03:53 --> Helper loaded: url_helper
INFO - 2024-06-20 11:03:53 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:03:53 --> Controller Class Initialized
INFO - 2024-06-20 11:03:53 --> Database Driver Class Initialized
INFO - 2024-06-20 11:03:53 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:03:53 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 11:03:53 --> Final output sent to browser
DEBUG - 2024-06-20 11:03:53 --> Total execution time: 0.0492
INFO - 2024-06-20 11:04:26 --> Config Class Initialized
INFO - 2024-06-20 11:04:26 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:04:26 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:04:26 --> Utf8 Class Initialized
INFO - 2024-06-20 11:04:26 --> URI Class Initialized
INFO - 2024-06-20 11:04:26 --> Router Class Initialized
INFO - 2024-06-20 11:04:26 --> Output Class Initialized
INFO - 2024-06-20 11:04:26 --> Security Class Initialized
DEBUG - 2024-06-20 11:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:04:26 --> Input Class Initialized
INFO - 2024-06-20 11:04:26 --> Language Class Initialized
INFO - 2024-06-20 11:04:26 --> Loader Class Initialized
INFO - 2024-06-20 11:04:26 --> Helper loaded: url_helper
INFO - 2024-06-20 11:04:26 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:04:26 --> Controller Class Initialized
INFO - 2024-06-20 11:04:26 --> Database Driver Class Initialized
INFO - 2024-06-20 11:04:26 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:04:26 --> Form Validation Class Initialized
INFO - 2024-06-20 11:04:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-20 11:04:26 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 11:04:26 --> Final output sent to browser
DEBUG - 2024-06-20 11:04:26 --> Total execution time: 0.0616
INFO - 2024-06-20 11:04:35 --> Config Class Initialized
INFO - 2024-06-20 11:04:35 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:04:35 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:04:35 --> Utf8 Class Initialized
INFO - 2024-06-20 11:04:35 --> URI Class Initialized
INFO - 2024-06-20 11:04:35 --> Router Class Initialized
INFO - 2024-06-20 11:04:35 --> Output Class Initialized
INFO - 2024-06-20 11:04:35 --> Security Class Initialized
DEBUG - 2024-06-20 11:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:04:35 --> Input Class Initialized
INFO - 2024-06-20 11:04:35 --> Language Class Initialized
INFO - 2024-06-20 11:04:35 --> Loader Class Initialized
INFO - 2024-06-20 11:04:35 --> Helper loaded: url_helper
INFO - 2024-06-20 11:04:35 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:04:35 --> Controller Class Initialized
INFO - 2024-06-20 11:04:35 --> Database Driver Class Initialized
INFO - 2024-06-20 11:04:35 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:04:35 --> Form Validation Class Initialized
INFO - 2024-06-20 11:04:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-20 11:04:35 --> Config Class Initialized
INFO - 2024-06-20 11:04:35 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:04:35 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:04:35 --> Utf8 Class Initialized
INFO - 2024-06-20 11:04:35 --> URI Class Initialized
INFO - 2024-06-20 11:04:35 --> Router Class Initialized
INFO - 2024-06-20 11:04:35 --> Output Class Initialized
INFO - 2024-06-20 11:04:35 --> Security Class Initialized
DEBUG - 2024-06-20 11:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:04:35 --> Input Class Initialized
INFO - 2024-06-20 11:04:35 --> Language Class Initialized
INFO - 2024-06-20 11:04:35 --> Loader Class Initialized
INFO - 2024-06-20 11:04:35 --> Helper loaded: url_helper
INFO - 2024-06-20 11:04:35 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:04:35 --> Controller Class Initialized
INFO - 2024-06-20 11:04:35 --> Database Driver Class Initialized
INFO - 2024-06-20 11:04:35 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:04:35 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:04:35 --> Final output sent to browser
DEBUG - 2024-06-20 11:04:35 --> Total execution time: 0.0607
INFO - 2024-06-20 11:06:08 --> Config Class Initialized
INFO - 2024-06-20 11:06:08 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:06:08 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:06:08 --> Utf8 Class Initialized
INFO - 2024-06-20 11:06:08 --> URI Class Initialized
INFO - 2024-06-20 11:06:08 --> Router Class Initialized
INFO - 2024-06-20 11:06:08 --> Output Class Initialized
INFO - 2024-06-20 11:06:08 --> Security Class Initialized
DEBUG - 2024-06-20 11:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:06:08 --> Input Class Initialized
INFO - 2024-06-20 11:06:08 --> Language Class Initialized
ERROR - 2024-06-20 11:06:08 --> Severity: error --> Exception: syntax error, unexpected identifier "tbl", expecting ")" D:\xampp\htdocs\Blog\application\controllers\Auth.php 25
INFO - 2024-06-20 11:07:11 --> Config Class Initialized
INFO - 2024-06-20 11:07:11 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:07:11 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:07:11 --> Utf8 Class Initialized
INFO - 2024-06-20 11:07:11 --> URI Class Initialized
INFO - 2024-06-20 11:07:11 --> Router Class Initialized
INFO - 2024-06-20 11:07:11 --> Output Class Initialized
INFO - 2024-06-20 11:07:11 --> Security Class Initialized
DEBUG - 2024-06-20 11:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:07:11 --> Input Class Initialized
INFO - 2024-06-20 11:07:11 --> Language Class Initialized
INFO - 2024-06-20 11:07:11 --> Loader Class Initialized
INFO - 2024-06-20 11:07:11 --> Helper loaded: url_helper
INFO - 2024-06-20 11:07:11 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:07:11 --> Controller Class Initialized
INFO - 2024-06-20 11:07:11 --> Database Driver Class Initialized
INFO - 2024-06-20 11:07:11 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:07:11 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 11:07:11 --> Final output sent to browser
DEBUG - 2024-06-20 11:07:11 --> Total execution time: 0.0675
INFO - 2024-06-20 11:07:16 --> Config Class Initialized
INFO - 2024-06-20 11:07:16 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:07:16 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:07:16 --> Utf8 Class Initialized
INFO - 2024-06-20 11:07:16 --> URI Class Initialized
INFO - 2024-06-20 11:07:16 --> Router Class Initialized
INFO - 2024-06-20 11:07:16 --> Output Class Initialized
INFO - 2024-06-20 11:07:16 --> Security Class Initialized
DEBUG - 2024-06-20 11:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:07:16 --> Input Class Initialized
INFO - 2024-06-20 11:07:16 --> Language Class Initialized
INFO - 2024-06-20 11:07:16 --> Loader Class Initialized
INFO - 2024-06-20 11:07:16 --> Helper loaded: url_helper
INFO - 2024-06-20 11:07:16 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:07:16 --> Controller Class Initialized
INFO - 2024-06-20 11:07:16 --> Database Driver Class Initialized
INFO - 2024-06-20 11:07:16 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:07:16 --> Form Validation Class Initialized
INFO - 2024-06-20 11:07:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2024-06-20 11:07:16 --> Unable to find validation rule: xss_cleanis_unique
ERROR - 2024-06-20 11:07:16 --> Could not find the language line "form_validation_xss_cleanis_unique"
INFO - 2024-06-20 11:07:16 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 11:07:16 --> Final output sent to browser
DEBUG - 2024-06-20 11:07:16 --> Total execution time: 0.0485
INFO - 2024-06-20 11:07:29 --> Config Class Initialized
INFO - 2024-06-20 11:07:29 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:07:29 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:07:29 --> Utf8 Class Initialized
INFO - 2024-06-20 11:07:29 --> URI Class Initialized
INFO - 2024-06-20 11:07:29 --> Router Class Initialized
INFO - 2024-06-20 11:07:29 --> Output Class Initialized
INFO - 2024-06-20 11:07:29 --> Security Class Initialized
DEBUG - 2024-06-20 11:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:07:29 --> Input Class Initialized
INFO - 2024-06-20 11:07:29 --> Language Class Initialized
INFO - 2024-06-20 11:07:29 --> Loader Class Initialized
INFO - 2024-06-20 11:07:29 --> Helper loaded: url_helper
INFO - 2024-06-20 11:07:29 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:07:29 --> Controller Class Initialized
INFO - 2024-06-20 11:07:29 --> Database Driver Class Initialized
INFO - 2024-06-20 11:07:29 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:07:29 --> Form Validation Class Initialized
INFO - 2024-06-20 11:07:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-20 11:07:29 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 11:07:29 --> Final output sent to browser
DEBUG - 2024-06-20 11:07:29 --> Total execution time: 0.0913
INFO - 2024-06-20 11:08:26 --> Config Class Initialized
INFO - 2024-06-20 11:08:26 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:08:26 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:08:26 --> Utf8 Class Initialized
INFO - 2024-06-20 11:08:26 --> URI Class Initialized
INFO - 2024-06-20 11:08:26 --> Router Class Initialized
INFO - 2024-06-20 11:08:26 --> Output Class Initialized
INFO - 2024-06-20 11:08:26 --> Security Class Initialized
DEBUG - 2024-06-20 11:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:08:26 --> Input Class Initialized
INFO - 2024-06-20 11:08:26 --> Language Class Initialized
INFO - 2024-06-20 11:08:26 --> Loader Class Initialized
INFO - 2024-06-20 11:08:26 --> Helper loaded: url_helper
INFO - 2024-06-20 11:08:26 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:08:26 --> Controller Class Initialized
INFO - 2024-06-20 11:08:26 --> Database Driver Class Initialized
INFO - 2024-06-20 11:08:26 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:08:26 --> Form Validation Class Initialized
INFO - 2024-06-20 11:08:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-20 11:08:26 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 11:08:26 --> Final output sent to browser
DEBUG - 2024-06-20 11:08:26 --> Total execution time: 0.0586
INFO - 2024-06-20 11:08:56 --> Config Class Initialized
INFO - 2024-06-20 11:08:56 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:08:56 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:08:56 --> Utf8 Class Initialized
INFO - 2024-06-20 11:08:56 --> URI Class Initialized
INFO - 2024-06-20 11:08:56 --> Router Class Initialized
INFO - 2024-06-20 11:08:56 --> Output Class Initialized
INFO - 2024-06-20 11:08:56 --> Security Class Initialized
DEBUG - 2024-06-20 11:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:08:56 --> Input Class Initialized
INFO - 2024-06-20 11:08:56 --> Language Class Initialized
INFO - 2024-06-20 11:08:56 --> Loader Class Initialized
INFO - 2024-06-20 11:08:56 --> Helper loaded: url_helper
INFO - 2024-06-20 11:08:56 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:08:56 --> Controller Class Initialized
INFO - 2024-06-20 11:08:56 --> Database Driver Class Initialized
INFO - 2024-06-20 11:08:56 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:08:56 --> Form Validation Class Initialized
INFO - 2024-06-20 11:08:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-20 11:08:56 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 11:08:56 --> Final output sent to browser
DEBUG - 2024-06-20 11:08:56 --> Total execution time: 0.0563
INFO - 2024-06-20 11:09:01 --> Config Class Initialized
INFO - 2024-06-20 11:09:01 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:09:01 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:09:01 --> Utf8 Class Initialized
INFO - 2024-06-20 11:09:01 --> URI Class Initialized
INFO - 2024-06-20 11:09:01 --> Router Class Initialized
INFO - 2024-06-20 11:09:01 --> Output Class Initialized
INFO - 2024-06-20 11:09:01 --> Security Class Initialized
DEBUG - 2024-06-20 11:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:09:01 --> Input Class Initialized
INFO - 2024-06-20 11:09:01 --> Language Class Initialized
INFO - 2024-06-20 11:09:01 --> Loader Class Initialized
INFO - 2024-06-20 11:09:01 --> Helper loaded: url_helper
INFO - 2024-06-20 11:09:01 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:09:01 --> Controller Class Initialized
INFO - 2024-06-20 11:09:01 --> Database Driver Class Initialized
INFO - 2024-06-20 11:09:01 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:09:01 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:09:01 --> Final output sent to browser
DEBUG - 2024-06-20 11:09:01 --> Total execution time: 0.0531
INFO - 2024-06-20 11:15:08 --> Config Class Initialized
INFO - 2024-06-20 11:15:08 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:15:08 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:15:08 --> Utf8 Class Initialized
INFO - 2024-06-20 11:15:08 --> URI Class Initialized
INFO - 2024-06-20 11:15:08 --> Router Class Initialized
INFO - 2024-06-20 11:15:08 --> Output Class Initialized
INFO - 2024-06-20 11:15:08 --> Security Class Initialized
DEBUG - 2024-06-20 11:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:15:08 --> Input Class Initialized
INFO - 2024-06-20 11:15:08 --> Language Class Initialized
INFO - 2024-06-20 11:15:08 --> Loader Class Initialized
INFO - 2024-06-20 11:15:08 --> Helper loaded: url_helper
INFO - 2024-06-20 11:15:08 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:15:08 --> Controller Class Initialized
INFO - 2024-06-20 11:15:08 --> Database Driver Class Initialized
INFO - 2024-06-20 11:15:08 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:15:08 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 11:15:08 --> Final output sent to browser
DEBUG - 2024-06-20 11:15:08 --> Total execution time: 0.0803
INFO - 2024-06-20 11:15:16 --> Config Class Initialized
INFO - 2024-06-20 11:15:16 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:15:16 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:15:16 --> Utf8 Class Initialized
INFO - 2024-06-20 11:15:16 --> URI Class Initialized
INFO - 2024-06-20 11:15:16 --> Router Class Initialized
INFO - 2024-06-20 11:15:16 --> Output Class Initialized
INFO - 2024-06-20 11:15:16 --> Security Class Initialized
DEBUG - 2024-06-20 11:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:15:16 --> Input Class Initialized
INFO - 2024-06-20 11:15:16 --> Language Class Initialized
INFO - 2024-06-20 11:15:16 --> Loader Class Initialized
INFO - 2024-06-20 11:15:16 --> Helper loaded: url_helper
INFO - 2024-06-20 11:15:16 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:15:16 --> Controller Class Initialized
INFO - 2024-06-20 11:15:16 --> Database Driver Class Initialized
INFO - 2024-06-20 11:15:16 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:15:16 --> Form Validation Class Initialized
INFO - 2024-06-20 11:15:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-20 11:15:16 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 11:15:16 --> Final output sent to browser
DEBUG - 2024-06-20 11:15:16 --> Total execution time: 0.0549
INFO - 2024-06-20 11:15:23 --> Config Class Initialized
INFO - 2024-06-20 11:15:23 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:15:23 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:15:23 --> Utf8 Class Initialized
INFO - 2024-06-20 11:15:23 --> URI Class Initialized
INFO - 2024-06-20 11:15:23 --> Router Class Initialized
INFO - 2024-06-20 11:15:23 --> Output Class Initialized
INFO - 2024-06-20 11:15:23 --> Security Class Initialized
DEBUG - 2024-06-20 11:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:15:23 --> Input Class Initialized
INFO - 2024-06-20 11:15:23 --> Language Class Initialized
INFO - 2024-06-20 11:15:23 --> Loader Class Initialized
INFO - 2024-06-20 11:15:23 --> Helper loaded: url_helper
INFO - 2024-06-20 11:15:23 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:15:23 --> Controller Class Initialized
INFO - 2024-06-20 11:15:23 --> Database Driver Class Initialized
INFO - 2024-06-20 11:15:23 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:15:23 --> Form Validation Class Initialized
INFO - 2024-06-20 11:15:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-20 11:15:23 --> Config Class Initialized
INFO - 2024-06-20 11:15:23 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:15:23 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:15:23 --> Utf8 Class Initialized
INFO - 2024-06-20 11:15:23 --> URI Class Initialized
INFO - 2024-06-20 11:15:23 --> Router Class Initialized
INFO - 2024-06-20 11:15:23 --> Output Class Initialized
INFO - 2024-06-20 11:15:23 --> Security Class Initialized
DEBUG - 2024-06-20 11:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:15:23 --> Input Class Initialized
INFO - 2024-06-20 11:15:23 --> Language Class Initialized
INFO - 2024-06-20 11:15:23 --> Loader Class Initialized
INFO - 2024-06-20 11:15:23 --> Helper loaded: url_helper
INFO - 2024-06-20 11:15:23 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:15:23 --> Controller Class Initialized
INFO - 2024-06-20 11:15:23 --> Database Driver Class Initialized
INFO - 2024-06-20 11:15:23 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:15:23 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:15:23 --> Final output sent to browser
DEBUG - 2024-06-20 11:15:23 --> Total execution time: 0.0382
INFO - 2024-06-20 11:15:27 --> Config Class Initialized
INFO - 2024-06-20 11:15:27 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:15:27 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:15:27 --> Utf8 Class Initialized
INFO - 2024-06-20 11:15:27 --> URI Class Initialized
INFO - 2024-06-20 11:15:27 --> Router Class Initialized
INFO - 2024-06-20 11:15:27 --> Output Class Initialized
INFO - 2024-06-20 11:15:27 --> Security Class Initialized
DEBUG - 2024-06-20 11:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:15:27 --> Input Class Initialized
INFO - 2024-06-20 11:15:27 --> Language Class Initialized
INFO - 2024-06-20 11:15:27 --> Loader Class Initialized
INFO - 2024-06-20 11:15:27 --> Helper loaded: url_helper
INFO - 2024-06-20 11:15:27 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:15:27 --> Controller Class Initialized
INFO - 2024-06-20 11:15:27 --> Database Driver Class Initialized
INFO - 2024-06-20 11:15:27 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:15:27 --> Config Class Initialized
INFO - 2024-06-20 11:15:27 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:15:27 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:15:27 --> Utf8 Class Initialized
INFO - 2024-06-20 11:15:27 --> URI Class Initialized
INFO - 2024-06-20 11:15:27 --> Router Class Initialized
INFO - 2024-06-20 11:15:27 --> Output Class Initialized
INFO - 2024-06-20 11:15:27 --> Security Class Initialized
DEBUG - 2024-06-20 11:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:15:27 --> Input Class Initialized
INFO - 2024-06-20 11:15:27 --> Language Class Initialized
ERROR - 2024-06-20 11:15:27 --> 404 Page Not Found: Login/index
INFO - 2024-06-20 11:15:47 --> Config Class Initialized
INFO - 2024-06-20 11:15:47 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:15:47 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:15:47 --> Utf8 Class Initialized
INFO - 2024-06-20 11:15:47 --> URI Class Initialized
INFO - 2024-06-20 11:15:47 --> Router Class Initialized
INFO - 2024-06-20 11:15:47 --> Output Class Initialized
INFO - 2024-06-20 11:15:47 --> Security Class Initialized
DEBUG - 2024-06-20 11:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:15:47 --> Input Class Initialized
INFO - 2024-06-20 11:15:47 --> Language Class Initialized
ERROR - 2024-06-20 11:15:47 --> 404 Page Not Found: Login/index
INFO - 2024-06-20 11:15:48 --> Config Class Initialized
INFO - 2024-06-20 11:15:48 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:15:48 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:15:48 --> Utf8 Class Initialized
INFO - 2024-06-20 11:15:48 --> URI Class Initialized
INFO - 2024-06-20 11:15:48 --> Router Class Initialized
INFO - 2024-06-20 11:15:48 --> Output Class Initialized
INFO - 2024-06-20 11:15:48 --> Security Class Initialized
DEBUG - 2024-06-20 11:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:15:48 --> Input Class Initialized
INFO - 2024-06-20 11:15:48 --> Language Class Initialized
INFO - 2024-06-20 11:15:48 --> Loader Class Initialized
INFO - 2024-06-20 11:15:48 --> Helper loaded: url_helper
INFO - 2024-06-20 11:15:48 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:15:48 --> Controller Class Initialized
INFO - 2024-06-20 11:15:48 --> Database Driver Class Initialized
INFO - 2024-06-20 11:15:48 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:15:48 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:15:48 --> Final output sent to browser
DEBUG - 2024-06-20 11:15:48 --> Total execution time: 0.0509
INFO - 2024-06-20 11:15:50 --> Config Class Initialized
INFO - 2024-06-20 11:15:50 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:15:50 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:15:50 --> Utf8 Class Initialized
INFO - 2024-06-20 11:15:50 --> URI Class Initialized
INFO - 2024-06-20 11:15:50 --> Router Class Initialized
INFO - 2024-06-20 11:15:50 --> Output Class Initialized
INFO - 2024-06-20 11:15:50 --> Security Class Initialized
DEBUG - 2024-06-20 11:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:15:50 --> Input Class Initialized
INFO - 2024-06-20 11:15:50 --> Language Class Initialized
INFO - 2024-06-20 11:15:50 --> Loader Class Initialized
INFO - 2024-06-20 11:15:50 --> Helper loaded: url_helper
INFO - 2024-06-20 11:15:50 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:15:50 --> Controller Class Initialized
INFO - 2024-06-20 11:15:50 --> Database Driver Class Initialized
INFO - 2024-06-20 11:15:50 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:15:50 --> Config Class Initialized
INFO - 2024-06-20 11:15:50 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:15:50 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:15:50 --> Utf8 Class Initialized
INFO - 2024-06-20 11:15:50 --> URI Class Initialized
INFO - 2024-06-20 11:15:50 --> Router Class Initialized
INFO - 2024-06-20 11:15:50 --> Output Class Initialized
INFO - 2024-06-20 11:15:50 --> Security Class Initialized
DEBUG - 2024-06-20 11:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:15:50 --> Input Class Initialized
INFO - 2024-06-20 11:15:50 --> Language Class Initialized
ERROR - 2024-06-20 11:15:50 --> 404 Page Not Found: Login/index
INFO - 2024-06-20 11:15:52 --> Config Class Initialized
INFO - 2024-06-20 11:15:52 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:15:52 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:15:52 --> Utf8 Class Initialized
INFO - 2024-06-20 11:15:52 --> URI Class Initialized
INFO - 2024-06-20 11:15:52 --> Router Class Initialized
INFO - 2024-06-20 11:15:52 --> Output Class Initialized
INFO - 2024-06-20 11:15:52 --> Security Class Initialized
DEBUG - 2024-06-20 11:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:15:52 --> Input Class Initialized
INFO - 2024-06-20 11:15:52 --> Language Class Initialized
INFO - 2024-06-20 11:15:52 --> Loader Class Initialized
INFO - 2024-06-20 11:15:52 --> Helper loaded: url_helper
INFO - 2024-06-20 11:15:52 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:15:52 --> Controller Class Initialized
INFO - 2024-06-20 11:15:52 --> Database Driver Class Initialized
INFO - 2024-06-20 11:15:52 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:15:52 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:15:52 --> Final output sent to browser
DEBUG - 2024-06-20 11:15:52 --> Total execution time: 0.0585
INFO - 2024-06-20 11:15:53 --> Config Class Initialized
INFO - 2024-06-20 11:15:53 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:15:53 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:15:53 --> Utf8 Class Initialized
INFO - 2024-06-20 11:15:53 --> URI Class Initialized
INFO - 2024-06-20 11:15:53 --> Router Class Initialized
INFO - 2024-06-20 11:15:53 --> Output Class Initialized
INFO - 2024-06-20 11:15:53 --> Security Class Initialized
DEBUG - 2024-06-20 11:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:15:53 --> Input Class Initialized
INFO - 2024-06-20 11:15:53 --> Language Class Initialized
INFO - 2024-06-20 11:15:53 --> Loader Class Initialized
INFO - 2024-06-20 11:15:53 --> Helper loaded: url_helper
INFO - 2024-06-20 11:15:53 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:15:53 --> Controller Class Initialized
INFO - 2024-06-20 11:15:53 --> Database Driver Class Initialized
INFO - 2024-06-20 11:15:53 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:15:53 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:15:53 --> Final output sent to browser
DEBUG - 2024-06-20 11:15:53 --> Total execution time: 0.0408
INFO - 2024-06-20 11:15:54 --> Config Class Initialized
INFO - 2024-06-20 11:15:54 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:15:54 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:15:54 --> Utf8 Class Initialized
INFO - 2024-06-20 11:15:54 --> URI Class Initialized
INFO - 2024-06-20 11:15:54 --> Router Class Initialized
INFO - 2024-06-20 11:15:54 --> Output Class Initialized
INFO - 2024-06-20 11:15:54 --> Security Class Initialized
DEBUG - 2024-06-20 11:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:15:54 --> Input Class Initialized
INFO - 2024-06-20 11:15:54 --> Language Class Initialized
INFO - 2024-06-20 11:15:54 --> Loader Class Initialized
INFO - 2024-06-20 11:15:54 --> Helper loaded: url_helper
INFO - 2024-06-20 11:15:54 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:15:54 --> Controller Class Initialized
INFO - 2024-06-20 11:15:54 --> Database Driver Class Initialized
INFO - 2024-06-20 11:15:54 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:15:54 --> Config Class Initialized
INFO - 2024-06-20 11:15:54 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:15:54 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:15:54 --> Utf8 Class Initialized
INFO - 2024-06-20 11:15:54 --> URI Class Initialized
INFO - 2024-06-20 11:15:54 --> Router Class Initialized
INFO - 2024-06-20 11:15:54 --> Output Class Initialized
INFO - 2024-06-20 11:15:54 --> Security Class Initialized
DEBUG - 2024-06-20 11:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:15:54 --> Input Class Initialized
INFO - 2024-06-20 11:15:54 --> Language Class Initialized
ERROR - 2024-06-20 11:15:54 --> 404 Page Not Found: Login/index
INFO - 2024-06-20 11:16:05 --> Config Class Initialized
INFO - 2024-06-20 11:16:05 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:16:05 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:16:05 --> Utf8 Class Initialized
INFO - 2024-06-20 11:16:05 --> URI Class Initialized
INFO - 2024-06-20 11:16:05 --> Router Class Initialized
INFO - 2024-06-20 11:16:05 --> Output Class Initialized
INFO - 2024-06-20 11:16:05 --> Security Class Initialized
DEBUG - 2024-06-20 11:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:16:05 --> Input Class Initialized
INFO - 2024-06-20 11:16:05 --> Language Class Initialized
INFO - 2024-06-20 11:16:05 --> Loader Class Initialized
INFO - 2024-06-20 11:16:05 --> Helper loaded: url_helper
INFO - 2024-06-20 11:16:05 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:16:05 --> Controller Class Initialized
INFO - 2024-06-20 11:16:05 --> Database Driver Class Initialized
INFO - 2024-06-20 11:16:05 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:16:05 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:16:05 --> Final output sent to browser
DEBUG - 2024-06-20 11:16:05 --> Total execution time: 0.0500
INFO - 2024-06-20 11:16:07 --> Config Class Initialized
INFO - 2024-06-20 11:16:07 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:16:07 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:16:07 --> Utf8 Class Initialized
INFO - 2024-06-20 11:16:07 --> URI Class Initialized
INFO - 2024-06-20 11:16:07 --> Router Class Initialized
INFO - 2024-06-20 11:16:07 --> Output Class Initialized
INFO - 2024-06-20 11:16:07 --> Security Class Initialized
DEBUG - 2024-06-20 11:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:16:07 --> Input Class Initialized
INFO - 2024-06-20 11:16:07 --> Language Class Initialized
INFO - 2024-06-20 11:16:07 --> Loader Class Initialized
INFO - 2024-06-20 11:16:07 --> Helper loaded: url_helper
INFO - 2024-06-20 11:16:07 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:16:07 --> Controller Class Initialized
INFO - 2024-06-20 11:16:07 --> Database Driver Class Initialized
INFO - 2024-06-20 11:16:07 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:16:07 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:16:07 --> Final output sent to browser
DEBUG - 2024-06-20 11:16:07 --> Total execution time: 0.0522
INFO - 2024-06-20 11:16:08 --> Config Class Initialized
INFO - 2024-06-20 11:16:08 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:16:08 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:16:08 --> Utf8 Class Initialized
INFO - 2024-06-20 11:16:08 --> URI Class Initialized
INFO - 2024-06-20 11:16:08 --> Router Class Initialized
INFO - 2024-06-20 11:16:08 --> Output Class Initialized
INFO - 2024-06-20 11:16:08 --> Security Class Initialized
DEBUG - 2024-06-20 11:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:16:08 --> Input Class Initialized
INFO - 2024-06-20 11:16:08 --> Language Class Initialized
INFO - 2024-06-20 11:16:08 --> Loader Class Initialized
INFO - 2024-06-20 11:16:08 --> Helper loaded: url_helper
INFO - 2024-06-20 11:16:08 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:16:08 --> Controller Class Initialized
INFO - 2024-06-20 11:16:08 --> Database Driver Class Initialized
INFO - 2024-06-20 11:16:08 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:16:08 --> Config Class Initialized
INFO - 2024-06-20 11:16:08 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:16:08 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:16:08 --> Utf8 Class Initialized
INFO - 2024-06-20 11:16:08 --> URI Class Initialized
INFO - 2024-06-20 11:16:08 --> Router Class Initialized
INFO - 2024-06-20 11:16:08 --> Output Class Initialized
INFO - 2024-06-20 11:16:08 --> Security Class Initialized
DEBUG - 2024-06-20 11:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:16:08 --> Input Class Initialized
INFO - 2024-06-20 11:16:08 --> Language Class Initialized
INFO - 2024-06-20 11:16:08 --> Loader Class Initialized
INFO - 2024-06-20 11:16:08 --> Helper loaded: url_helper
INFO - 2024-06-20 11:16:08 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:16:08 --> Controller Class Initialized
INFO - 2024-06-20 11:16:08 --> Database Driver Class Initialized
INFO - 2024-06-20 11:16:08 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:16:08 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:16:08 --> Final output sent to browser
DEBUG - 2024-06-20 11:16:08 --> Total execution time: 0.0542
INFO - 2024-06-20 11:16:44 --> Config Class Initialized
INFO - 2024-06-20 11:16:44 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:16:44 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:16:44 --> Utf8 Class Initialized
INFO - 2024-06-20 11:16:44 --> URI Class Initialized
INFO - 2024-06-20 11:16:44 --> Router Class Initialized
INFO - 2024-06-20 11:16:44 --> Output Class Initialized
INFO - 2024-06-20 11:16:44 --> Security Class Initialized
DEBUG - 2024-06-20 11:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:16:44 --> Input Class Initialized
INFO - 2024-06-20 11:16:44 --> Language Class Initialized
INFO - 2024-06-20 11:16:44 --> Loader Class Initialized
INFO - 2024-06-20 11:16:44 --> Helper loaded: url_helper
INFO - 2024-06-20 11:16:44 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:16:44 --> Controller Class Initialized
INFO - 2024-06-20 11:16:44 --> Database Driver Class Initialized
INFO - 2024-06-20 11:16:44 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:16:44 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:16:44 --> Final output sent to browser
DEBUG - 2024-06-20 11:16:44 --> Total execution time: 0.0540
INFO - 2024-06-20 11:16:45 --> Config Class Initialized
INFO - 2024-06-20 11:16:45 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:16:45 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:16:45 --> Utf8 Class Initialized
INFO - 2024-06-20 11:16:45 --> URI Class Initialized
INFO - 2024-06-20 11:16:45 --> Router Class Initialized
INFO - 2024-06-20 11:16:45 --> Output Class Initialized
INFO - 2024-06-20 11:16:45 --> Security Class Initialized
DEBUG - 2024-06-20 11:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:16:45 --> Input Class Initialized
INFO - 2024-06-20 11:16:45 --> Language Class Initialized
INFO - 2024-06-20 11:16:45 --> Loader Class Initialized
INFO - 2024-06-20 11:16:45 --> Helper loaded: url_helper
INFO - 2024-06-20 11:16:45 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:16:45 --> Controller Class Initialized
INFO - 2024-06-20 11:16:45 --> Database Driver Class Initialized
INFO - 2024-06-20 11:16:45 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:16:45 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:16:45 --> Final output sent to browser
DEBUG - 2024-06-20 11:16:45 --> Total execution time: 0.0466
INFO - 2024-06-20 11:16:46 --> Config Class Initialized
INFO - 2024-06-20 11:16:46 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:16:46 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:16:46 --> Utf8 Class Initialized
INFO - 2024-06-20 11:16:46 --> URI Class Initialized
INFO - 2024-06-20 11:16:46 --> Router Class Initialized
INFO - 2024-06-20 11:16:46 --> Output Class Initialized
INFO - 2024-06-20 11:16:46 --> Security Class Initialized
DEBUG - 2024-06-20 11:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:16:46 --> Input Class Initialized
INFO - 2024-06-20 11:16:46 --> Language Class Initialized
INFO - 2024-06-20 11:16:46 --> Loader Class Initialized
INFO - 2024-06-20 11:16:46 --> Helper loaded: url_helper
INFO - 2024-06-20 11:16:46 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:16:46 --> Controller Class Initialized
INFO - 2024-06-20 11:16:46 --> Database Driver Class Initialized
INFO - 2024-06-20 11:16:46 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:16:46 --> Config Class Initialized
INFO - 2024-06-20 11:16:46 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:16:46 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:16:46 --> Utf8 Class Initialized
INFO - 2024-06-20 11:16:46 --> URI Class Initialized
INFO - 2024-06-20 11:16:46 --> Router Class Initialized
INFO - 2024-06-20 11:16:46 --> Output Class Initialized
INFO - 2024-06-20 11:16:47 --> Security Class Initialized
DEBUG - 2024-06-20 11:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:16:47 --> Input Class Initialized
INFO - 2024-06-20 11:16:47 --> Language Class Initialized
INFO - 2024-06-20 11:16:47 --> Loader Class Initialized
INFO - 2024-06-20 11:16:47 --> Helper loaded: url_helper
INFO - 2024-06-20 11:16:47 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:16:47 --> Controller Class Initialized
INFO - 2024-06-20 11:16:47 --> Database Driver Class Initialized
INFO - 2024-06-20 11:16:47 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:16:47 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:16:47 --> Final output sent to browser
DEBUG - 2024-06-20 11:16:47 --> Total execution time: 0.0539
INFO - 2024-06-20 11:17:38 --> Config Class Initialized
INFO - 2024-06-20 11:17:38 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:17:38 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:17:38 --> Utf8 Class Initialized
INFO - 2024-06-20 11:17:38 --> URI Class Initialized
INFO - 2024-06-20 11:17:38 --> Router Class Initialized
INFO - 2024-06-20 11:17:38 --> Output Class Initialized
INFO - 2024-06-20 11:17:38 --> Security Class Initialized
DEBUG - 2024-06-20 11:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:17:38 --> Input Class Initialized
INFO - 2024-06-20 11:17:38 --> Language Class Initialized
ERROR - 2024-06-20 11:17:38 --> Severity: error --> Exception: syntax error, unexpected token ";", expecting ")" D:\xampp\htdocs\Blog\application\controllers\Auth.php 68
INFO - 2024-06-20 11:17:48 --> Config Class Initialized
INFO - 2024-06-20 11:17:48 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:17:48 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:17:48 --> Utf8 Class Initialized
INFO - 2024-06-20 11:17:48 --> URI Class Initialized
INFO - 2024-06-20 11:17:48 --> Router Class Initialized
INFO - 2024-06-20 11:17:48 --> Output Class Initialized
INFO - 2024-06-20 11:17:48 --> Security Class Initialized
DEBUG - 2024-06-20 11:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:17:48 --> Input Class Initialized
INFO - 2024-06-20 11:17:48 --> Language Class Initialized
ERROR - 2024-06-20 11:17:48 --> Severity: error --> Exception: syntax error, unexpected token ";", expecting ")" D:\xampp\htdocs\Blog\application\controllers\Auth.php 68
INFO - 2024-06-20 11:17:48 --> Config Class Initialized
INFO - 2024-06-20 11:17:48 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:17:48 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:17:48 --> Utf8 Class Initialized
INFO - 2024-06-20 11:17:48 --> URI Class Initialized
INFO - 2024-06-20 11:17:48 --> Router Class Initialized
INFO - 2024-06-20 11:17:48 --> Output Class Initialized
INFO - 2024-06-20 11:17:48 --> Security Class Initialized
DEBUG - 2024-06-20 11:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:17:48 --> Input Class Initialized
INFO - 2024-06-20 11:17:48 --> Language Class Initialized
ERROR - 2024-06-20 11:17:48 --> Severity: error --> Exception: syntax error, unexpected token ";", expecting ")" D:\xampp\htdocs\Blog\application\controllers\Auth.php 68
INFO - 2024-06-20 11:18:03 --> Config Class Initialized
INFO - 2024-06-20 11:18:03 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:18:03 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:18:03 --> Utf8 Class Initialized
INFO - 2024-06-20 11:18:03 --> URI Class Initialized
INFO - 2024-06-20 11:18:03 --> Router Class Initialized
INFO - 2024-06-20 11:18:03 --> Output Class Initialized
INFO - 2024-06-20 11:18:03 --> Security Class Initialized
DEBUG - 2024-06-20 11:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:18:03 --> Input Class Initialized
INFO - 2024-06-20 11:18:03 --> Language Class Initialized
ERROR - 2024-06-20 11:18:03 --> Severity: error --> Exception: syntax error, unexpected token ";", expecting ")" D:\xampp\htdocs\Blog\application\controllers\Auth.php 68
INFO - 2024-06-20 11:18:09 --> Config Class Initialized
INFO - 2024-06-20 11:18:09 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:18:09 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:18:09 --> Utf8 Class Initialized
INFO - 2024-06-20 11:18:09 --> URI Class Initialized
INFO - 2024-06-20 11:18:09 --> Router Class Initialized
INFO - 2024-06-20 11:18:09 --> Output Class Initialized
INFO - 2024-06-20 11:18:09 --> Security Class Initialized
DEBUG - 2024-06-20 11:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:18:09 --> Input Class Initialized
INFO - 2024-06-20 11:18:09 --> Language Class Initialized
INFO - 2024-06-20 11:18:09 --> Loader Class Initialized
INFO - 2024-06-20 11:18:09 --> Helper loaded: url_helper
INFO - 2024-06-20 11:18:09 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:18:09 --> Controller Class Initialized
INFO - 2024-06-20 11:18:09 --> Database Driver Class Initialized
INFO - 2024-06-20 11:18:09 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:18:09 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 11:18:09 --> Final output sent to browser
DEBUG - 2024-06-20 11:18:09 --> Total execution time: 0.0502
INFO - 2024-06-20 11:18:13 --> Config Class Initialized
INFO - 2024-06-20 11:18:13 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:18:13 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:18:13 --> Utf8 Class Initialized
INFO - 2024-06-20 11:18:13 --> URI Class Initialized
INFO - 2024-06-20 11:18:13 --> Router Class Initialized
INFO - 2024-06-20 11:18:13 --> Output Class Initialized
INFO - 2024-06-20 11:18:13 --> Security Class Initialized
DEBUG - 2024-06-20 11:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:18:13 --> Input Class Initialized
INFO - 2024-06-20 11:18:13 --> Language Class Initialized
INFO - 2024-06-20 11:18:13 --> Loader Class Initialized
INFO - 2024-06-20 11:18:13 --> Helper loaded: url_helper
INFO - 2024-06-20 11:18:13 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:18:13 --> Controller Class Initialized
INFO - 2024-06-20 11:18:13 --> Database Driver Class Initialized
INFO - 2024-06-20 11:18:13 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:18:13 --> Form Validation Class Initialized
INFO - 2024-06-20 11:18:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-20 11:18:13 --> Config Class Initialized
INFO - 2024-06-20 11:18:13 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:18:13 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:18:13 --> Utf8 Class Initialized
INFO - 2024-06-20 11:18:13 --> URI Class Initialized
INFO - 2024-06-20 11:18:13 --> Router Class Initialized
INFO - 2024-06-20 11:18:13 --> Output Class Initialized
INFO - 2024-06-20 11:18:13 --> Security Class Initialized
DEBUG - 2024-06-20 11:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:18:13 --> Input Class Initialized
INFO - 2024-06-20 11:18:13 --> Language Class Initialized
INFO - 2024-06-20 11:18:13 --> Loader Class Initialized
INFO - 2024-06-20 11:18:13 --> Helper loaded: url_helper
INFO - 2024-06-20 11:18:13 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:18:13 --> Controller Class Initialized
INFO - 2024-06-20 11:18:13 --> Database Driver Class Initialized
INFO - 2024-06-20 11:18:13 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:18:13 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:18:13 --> Final output sent to browser
DEBUG - 2024-06-20 11:18:13 --> Total execution time: 0.0539
INFO - 2024-06-20 11:18:15 --> Config Class Initialized
INFO - 2024-06-20 11:18:15 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:18:15 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:18:15 --> Utf8 Class Initialized
INFO - 2024-06-20 11:18:15 --> URI Class Initialized
INFO - 2024-06-20 11:18:15 --> Router Class Initialized
INFO - 2024-06-20 11:18:15 --> Output Class Initialized
INFO - 2024-06-20 11:18:15 --> Security Class Initialized
DEBUG - 2024-06-20 11:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:18:15 --> Input Class Initialized
INFO - 2024-06-20 11:18:15 --> Language Class Initialized
INFO - 2024-06-20 11:18:15 --> Loader Class Initialized
INFO - 2024-06-20 11:18:15 --> Helper loaded: url_helper
INFO - 2024-06-20 11:18:15 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:18:15 --> Controller Class Initialized
INFO - 2024-06-20 11:18:15 --> Database Driver Class Initialized
INFO - 2024-06-20 11:18:15 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:18:15 --> Config Class Initialized
INFO - 2024-06-20 11:18:15 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:18:15 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:18:15 --> Utf8 Class Initialized
INFO - 2024-06-20 11:18:15 --> URI Class Initialized
INFO - 2024-06-20 11:18:15 --> Router Class Initialized
INFO - 2024-06-20 11:18:15 --> Output Class Initialized
INFO - 2024-06-20 11:18:15 --> Security Class Initialized
DEBUG - 2024-06-20 11:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:18:15 --> Input Class Initialized
INFO - 2024-06-20 11:18:15 --> Language Class Initialized
INFO - 2024-06-20 11:18:15 --> Loader Class Initialized
INFO - 2024-06-20 11:18:15 --> Helper loaded: url_helper
INFO - 2024-06-20 11:18:15 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:18:15 --> Controller Class Initialized
INFO - 2024-06-20 11:18:15 --> Database Driver Class Initialized
INFO - 2024-06-20 11:18:15 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:18:15 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:18:15 --> Final output sent to browser
DEBUG - 2024-06-20 11:18:15 --> Total execution time: 0.0594
INFO - 2024-06-20 11:18:40 --> Config Class Initialized
INFO - 2024-06-20 11:18:40 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:18:40 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:18:40 --> Utf8 Class Initialized
INFO - 2024-06-20 11:18:40 --> URI Class Initialized
INFO - 2024-06-20 11:18:40 --> Router Class Initialized
INFO - 2024-06-20 11:18:40 --> Output Class Initialized
INFO - 2024-06-20 11:18:40 --> Security Class Initialized
DEBUG - 2024-06-20 11:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:18:40 --> Input Class Initialized
INFO - 2024-06-20 11:18:40 --> Language Class Initialized
INFO - 2024-06-20 11:18:40 --> Loader Class Initialized
INFO - 2024-06-20 11:18:40 --> Helper loaded: url_helper
INFO - 2024-06-20 11:18:40 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:18:40 --> Controller Class Initialized
INFO - 2024-06-20 11:18:40 --> Database Driver Class Initialized
INFO - 2024-06-20 11:18:40 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:18:40 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 11:18:40 --> Final output sent to browser
DEBUG - 2024-06-20 11:18:40 --> Total execution time: 0.0608
INFO - 2024-06-20 11:18:43 --> Config Class Initialized
INFO - 2024-06-20 11:18:43 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:18:43 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:18:43 --> Utf8 Class Initialized
INFO - 2024-06-20 11:18:43 --> URI Class Initialized
INFO - 2024-06-20 11:18:43 --> Router Class Initialized
INFO - 2024-06-20 11:18:43 --> Output Class Initialized
INFO - 2024-06-20 11:18:43 --> Security Class Initialized
DEBUG - 2024-06-20 11:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:18:43 --> Input Class Initialized
INFO - 2024-06-20 11:18:43 --> Language Class Initialized
INFO - 2024-06-20 11:18:43 --> Loader Class Initialized
INFO - 2024-06-20 11:18:43 --> Helper loaded: url_helper
INFO - 2024-06-20 11:18:43 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:18:43 --> Controller Class Initialized
INFO - 2024-06-20 11:18:43 --> Database Driver Class Initialized
INFO - 2024-06-20 11:18:43 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:18:43 --> Form Validation Class Initialized
INFO - 2024-06-20 11:18:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-20 11:18:43 --> Config Class Initialized
INFO - 2024-06-20 11:18:43 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:18:43 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:18:43 --> Utf8 Class Initialized
INFO - 2024-06-20 11:18:43 --> URI Class Initialized
INFO - 2024-06-20 11:18:43 --> Router Class Initialized
INFO - 2024-06-20 11:18:43 --> Output Class Initialized
INFO - 2024-06-20 11:18:43 --> Security Class Initialized
DEBUG - 2024-06-20 11:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:18:43 --> Input Class Initialized
INFO - 2024-06-20 11:18:43 --> Language Class Initialized
INFO - 2024-06-20 11:18:43 --> Loader Class Initialized
INFO - 2024-06-20 11:18:43 --> Helper loaded: url_helper
INFO - 2024-06-20 11:18:43 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:18:43 --> Controller Class Initialized
INFO - 2024-06-20 11:18:43 --> Database Driver Class Initialized
INFO - 2024-06-20 11:18:43 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:18:43 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:18:43 --> Final output sent to browser
DEBUG - 2024-06-20 11:18:43 --> Total execution time: 0.0431
INFO - 2024-06-20 11:18:44 --> Config Class Initialized
INFO - 2024-06-20 11:18:44 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:18:44 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:18:44 --> Utf8 Class Initialized
INFO - 2024-06-20 11:18:44 --> URI Class Initialized
INFO - 2024-06-20 11:18:44 --> Router Class Initialized
INFO - 2024-06-20 11:18:44 --> Output Class Initialized
INFO - 2024-06-20 11:18:44 --> Security Class Initialized
DEBUG - 2024-06-20 11:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:18:44 --> Input Class Initialized
INFO - 2024-06-20 11:18:44 --> Language Class Initialized
INFO - 2024-06-20 11:18:44 --> Loader Class Initialized
INFO - 2024-06-20 11:18:44 --> Helper loaded: url_helper
INFO - 2024-06-20 11:18:44 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:18:44 --> Controller Class Initialized
INFO - 2024-06-20 11:18:44 --> Database Driver Class Initialized
INFO - 2024-06-20 11:18:44 --> Model "Auth_model" initialized
ERROR - 2024-06-20 11:18:44 --> Severity: Warning --> Undefined array key "usernames" D:\xampp\htdocs\Blog\application\controllers\Auth.php 73
ERROR - 2024-06-20 11:18:44 --> Severity: Warning --> Undefined array key "passwords" D:\xampp\htdocs\Blog\application\controllers\Auth.php 74
INFO - 2024-06-20 11:18:44 --> Config Class Initialized
INFO - 2024-06-20 11:18:44 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:18:44 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:18:44 --> Utf8 Class Initialized
INFO - 2024-06-20 11:18:44 --> URI Class Initialized
INFO - 2024-06-20 11:18:44 --> Router Class Initialized
INFO - 2024-06-20 11:18:44 --> Output Class Initialized
INFO - 2024-06-20 11:18:44 --> Security Class Initialized
DEBUG - 2024-06-20 11:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:18:44 --> Input Class Initialized
INFO - 2024-06-20 11:18:44 --> Language Class Initialized
INFO - 2024-06-20 11:18:44 --> Loader Class Initialized
INFO - 2024-06-20 11:18:44 --> Helper loaded: url_helper
INFO - 2024-06-20 11:18:44 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:18:44 --> Controller Class Initialized
INFO - 2024-06-20 11:18:45 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/home.php
INFO - 2024-06-20 11:18:45 --> Final output sent to browser
DEBUG - 2024-06-20 11:18:45 --> Total execution time: 0.1724
INFO - 2024-06-20 11:21:15 --> Config Class Initialized
INFO - 2024-06-20 11:21:15 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:21:15 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:21:15 --> Utf8 Class Initialized
INFO - 2024-06-20 11:21:15 --> URI Class Initialized
INFO - 2024-06-20 11:21:15 --> Router Class Initialized
INFO - 2024-06-20 11:21:15 --> Output Class Initialized
INFO - 2024-06-20 11:21:15 --> Security Class Initialized
DEBUG - 2024-06-20 11:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:21:15 --> Input Class Initialized
INFO - 2024-06-20 11:21:15 --> Language Class Initialized
INFO - 2024-06-20 11:21:15 --> Loader Class Initialized
INFO - 2024-06-20 11:21:15 --> Helper loaded: url_helper
INFO - 2024-06-20 11:21:15 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:21:15 --> Controller Class Initialized
INFO - 2024-06-20 11:21:15 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/home.php
INFO - 2024-06-20 11:21:15 --> Final output sent to browser
DEBUG - 2024-06-20 11:21:15 --> Total execution time: 0.0397
INFO - 2024-06-20 11:21:16 --> Config Class Initialized
INFO - 2024-06-20 11:21:16 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:21:16 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:21:16 --> Utf8 Class Initialized
INFO - 2024-06-20 11:21:16 --> URI Class Initialized
INFO - 2024-06-20 11:21:16 --> Router Class Initialized
INFO - 2024-06-20 11:21:16 --> Output Class Initialized
INFO - 2024-06-20 11:21:16 --> Security Class Initialized
DEBUG - 2024-06-20 11:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:21:16 --> Input Class Initialized
INFO - 2024-06-20 11:21:16 --> Language Class Initialized
INFO - 2024-06-20 11:21:16 --> Loader Class Initialized
INFO - 2024-06-20 11:21:16 --> Helper loaded: url_helper
INFO - 2024-06-20 11:21:16 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:21:16 --> Controller Class Initialized
INFO - 2024-06-20 11:21:16 --> Database Driver Class Initialized
INFO - 2024-06-20 11:21:16 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:21:16 --> Config Class Initialized
INFO - 2024-06-20 11:21:16 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:21:16 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:21:16 --> Utf8 Class Initialized
INFO - 2024-06-20 11:21:16 --> URI Class Initialized
INFO - 2024-06-20 11:21:16 --> Router Class Initialized
INFO - 2024-06-20 11:21:16 --> Output Class Initialized
INFO - 2024-06-20 11:21:16 --> Security Class Initialized
DEBUG - 2024-06-20 11:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:21:16 --> Input Class Initialized
INFO - 2024-06-20 11:21:16 --> Language Class Initialized
INFO - 2024-06-20 11:21:16 --> Loader Class Initialized
INFO - 2024-06-20 11:21:16 --> Helper loaded: url_helper
INFO - 2024-06-20 11:21:16 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:21:16 --> Controller Class Initialized
INFO - 2024-06-20 11:21:17 --> Database Driver Class Initialized
INFO - 2024-06-20 11:21:17 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:21:17 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:21:17 --> Final output sent to browser
DEBUG - 2024-06-20 11:21:17 --> Total execution time: 0.0636
INFO - 2024-06-20 11:21:19 --> Config Class Initialized
INFO - 2024-06-20 11:21:19 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:21:19 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:21:19 --> Utf8 Class Initialized
INFO - 2024-06-20 11:21:19 --> URI Class Initialized
INFO - 2024-06-20 11:21:19 --> Router Class Initialized
INFO - 2024-06-20 11:21:19 --> Output Class Initialized
INFO - 2024-06-20 11:21:19 --> Security Class Initialized
DEBUG - 2024-06-20 11:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:21:19 --> Input Class Initialized
INFO - 2024-06-20 11:21:19 --> Language Class Initialized
INFO - 2024-06-20 11:21:19 --> Loader Class Initialized
INFO - 2024-06-20 11:21:19 --> Helper loaded: url_helper
INFO - 2024-06-20 11:21:19 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:21:19 --> Controller Class Initialized
INFO - 2024-06-20 11:21:19 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/home.php
INFO - 2024-06-20 11:21:19 --> Final output sent to browser
DEBUG - 2024-06-20 11:21:19 --> Total execution time: 0.0418
INFO - 2024-06-20 11:22:31 --> Config Class Initialized
INFO - 2024-06-20 11:22:31 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:22:31 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:22:31 --> Utf8 Class Initialized
INFO - 2024-06-20 11:22:31 --> URI Class Initialized
INFO - 2024-06-20 11:22:31 --> Router Class Initialized
INFO - 2024-06-20 11:22:31 --> Output Class Initialized
INFO - 2024-06-20 11:22:31 --> Security Class Initialized
DEBUG - 2024-06-20 11:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:22:31 --> Input Class Initialized
INFO - 2024-06-20 11:22:31 --> Language Class Initialized
INFO - 2024-06-20 11:22:31 --> Loader Class Initialized
INFO - 2024-06-20 11:22:31 --> Helper loaded: url_helper
INFO - 2024-06-20 11:22:31 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:22:31 --> Controller Class Initialized
INFO - 2024-06-20 11:22:31 --> Config Class Initialized
INFO - 2024-06-20 11:22:31 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:22:31 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:22:31 --> Utf8 Class Initialized
INFO - 2024-06-20 11:22:31 --> URI Class Initialized
INFO - 2024-06-20 11:22:31 --> Router Class Initialized
INFO - 2024-06-20 11:22:31 --> Output Class Initialized
INFO - 2024-06-20 11:22:31 --> Security Class Initialized
DEBUG - 2024-06-20 11:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:22:31 --> Input Class Initialized
INFO - 2024-06-20 11:22:31 --> Language Class Initialized
INFO - 2024-06-20 11:22:31 --> Loader Class Initialized
INFO - 2024-06-20 11:22:31 --> Helper loaded: url_helper
INFO - 2024-06-20 11:22:31 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:22:31 --> Controller Class Initialized
INFO - 2024-06-20 11:22:31 --> Database Driver Class Initialized
INFO - 2024-06-20 11:22:31 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:22:31 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:22:31 --> Final output sent to browser
DEBUG - 2024-06-20 11:22:31 --> Total execution time: 0.0342
INFO - 2024-06-20 11:22:33 --> Config Class Initialized
INFO - 2024-06-20 11:22:33 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:22:33 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:22:33 --> Utf8 Class Initialized
INFO - 2024-06-20 11:22:33 --> URI Class Initialized
INFO - 2024-06-20 11:22:33 --> Router Class Initialized
INFO - 2024-06-20 11:22:33 --> Output Class Initialized
INFO - 2024-06-20 11:22:33 --> Security Class Initialized
DEBUG - 2024-06-20 11:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:22:33 --> Input Class Initialized
INFO - 2024-06-20 11:22:33 --> Language Class Initialized
INFO - 2024-06-20 11:22:33 --> Loader Class Initialized
INFO - 2024-06-20 11:22:33 --> Helper loaded: url_helper
INFO - 2024-06-20 11:22:33 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:22:33 --> Controller Class Initialized
INFO - 2024-06-20 11:22:33 --> Database Driver Class Initialized
INFO - 2024-06-20 11:22:33 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:22:33 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:22:33 --> Final output sent to browser
DEBUG - 2024-06-20 11:22:33 --> Total execution time: 0.0682
INFO - 2024-06-20 11:22:34 --> Config Class Initialized
INFO - 2024-06-20 11:22:34 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:22:34 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:22:34 --> Utf8 Class Initialized
INFO - 2024-06-20 11:22:34 --> URI Class Initialized
INFO - 2024-06-20 11:22:34 --> Router Class Initialized
INFO - 2024-06-20 11:22:34 --> Output Class Initialized
INFO - 2024-06-20 11:22:34 --> Security Class Initialized
DEBUG - 2024-06-20 11:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:22:34 --> Input Class Initialized
INFO - 2024-06-20 11:22:34 --> Language Class Initialized
INFO - 2024-06-20 11:22:34 --> Loader Class Initialized
INFO - 2024-06-20 11:22:34 --> Helper loaded: url_helper
INFO - 2024-06-20 11:22:34 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:22:34 --> Controller Class Initialized
INFO - 2024-06-20 11:22:34 --> Database Driver Class Initialized
INFO - 2024-06-20 11:22:34 --> Model "Auth_model" initialized
ERROR - 2024-06-20 11:22:34 --> Severity: Warning --> Undefined array key "usernames" D:\xampp\htdocs\Blog\application\controllers\Auth.php 73
ERROR - 2024-06-20 11:22:34 --> Severity: Warning --> Undefined array key "passwords" D:\xampp\htdocs\Blog\application\controllers\Auth.php 74
INFO - 2024-06-20 11:22:34 --> Config Class Initialized
INFO - 2024-06-20 11:22:34 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:22:34 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:22:34 --> Utf8 Class Initialized
INFO - 2024-06-20 11:22:34 --> URI Class Initialized
INFO - 2024-06-20 11:22:34 --> Router Class Initialized
INFO - 2024-06-20 11:22:34 --> Output Class Initialized
INFO - 2024-06-20 11:22:34 --> Security Class Initialized
DEBUG - 2024-06-20 11:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:22:34 --> Input Class Initialized
INFO - 2024-06-20 11:22:34 --> Language Class Initialized
INFO - 2024-06-20 11:22:34 --> Loader Class Initialized
INFO - 2024-06-20 11:22:34 --> Helper loaded: url_helper
INFO - 2024-06-20 11:22:34 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:22:34 --> Controller Class Initialized
INFO - 2024-06-20 11:22:35 --> Config Class Initialized
INFO - 2024-06-20 11:22:35 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:22:35 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:22:35 --> Utf8 Class Initialized
INFO - 2024-06-20 11:22:35 --> URI Class Initialized
INFO - 2024-06-20 11:22:35 --> Router Class Initialized
INFO - 2024-06-20 11:22:35 --> Output Class Initialized
INFO - 2024-06-20 11:22:35 --> Security Class Initialized
DEBUG - 2024-06-20 11:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:22:35 --> Input Class Initialized
INFO - 2024-06-20 11:22:35 --> Language Class Initialized
INFO - 2024-06-20 11:22:35 --> Loader Class Initialized
INFO - 2024-06-20 11:22:35 --> Helper loaded: url_helper
INFO - 2024-06-20 11:22:35 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:22:35 --> Controller Class Initialized
INFO - 2024-06-20 11:22:35 --> Database Driver Class Initialized
INFO - 2024-06-20 11:22:35 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:22:35 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:22:35 --> Final output sent to browser
DEBUG - 2024-06-20 11:22:35 --> Total execution time: 0.0606
INFO - 2024-06-20 11:22:36 --> Config Class Initialized
INFO - 2024-06-20 11:22:36 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:22:36 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:22:36 --> Utf8 Class Initialized
INFO - 2024-06-20 11:22:36 --> URI Class Initialized
INFO - 2024-06-20 11:22:36 --> Router Class Initialized
INFO - 2024-06-20 11:22:36 --> Output Class Initialized
INFO - 2024-06-20 11:22:36 --> Security Class Initialized
DEBUG - 2024-06-20 11:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:22:36 --> Input Class Initialized
INFO - 2024-06-20 11:22:36 --> Language Class Initialized
INFO - 2024-06-20 11:22:36 --> Loader Class Initialized
INFO - 2024-06-20 11:22:36 --> Helper loaded: url_helper
INFO - 2024-06-20 11:22:36 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:22:36 --> Controller Class Initialized
INFO - 2024-06-20 11:22:36 --> Database Driver Class Initialized
INFO - 2024-06-20 11:22:36 --> Model "Auth_model" initialized
ERROR - 2024-06-20 11:22:36 --> Severity: Warning --> Undefined array key "usernames" D:\xampp\htdocs\Blog\application\controllers\Auth.php 73
ERROR - 2024-06-20 11:22:36 --> Severity: Warning --> Undefined array key "passwords" D:\xampp\htdocs\Blog\application\controllers\Auth.php 74
INFO - 2024-06-20 11:22:36 --> Config Class Initialized
INFO - 2024-06-20 11:22:36 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:22:36 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:22:36 --> Utf8 Class Initialized
INFO - 2024-06-20 11:22:36 --> URI Class Initialized
INFO - 2024-06-20 11:22:36 --> Router Class Initialized
INFO - 2024-06-20 11:22:36 --> Output Class Initialized
INFO - 2024-06-20 11:22:36 --> Security Class Initialized
DEBUG - 2024-06-20 11:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:22:36 --> Input Class Initialized
INFO - 2024-06-20 11:22:36 --> Language Class Initialized
INFO - 2024-06-20 11:22:36 --> Loader Class Initialized
INFO - 2024-06-20 11:22:36 --> Helper loaded: url_helper
INFO - 2024-06-20 11:22:36 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:22:36 --> Controller Class Initialized
INFO - 2024-06-20 11:22:36 --> Config Class Initialized
INFO - 2024-06-20 11:22:36 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:22:36 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:22:36 --> Utf8 Class Initialized
INFO - 2024-06-20 11:22:36 --> URI Class Initialized
INFO - 2024-06-20 11:22:36 --> Router Class Initialized
INFO - 2024-06-20 11:22:36 --> Output Class Initialized
INFO - 2024-06-20 11:22:36 --> Security Class Initialized
DEBUG - 2024-06-20 11:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:22:36 --> Input Class Initialized
INFO - 2024-06-20 11:22:36 --> Language Class Initialized
INFO - 2024-06-20 11:22:36 --> Loader Class Initialized
INFO - 2024-06-20 11:22:36 --> Helper loaded: url_helper
INFO - 2024-06-20 11:22:36 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:22:36 --> Controller Class Initialized
INFO - 2024-06-20 11:22:36 --> Database Driver Class Initialized
INFO - 2024-06-20 11:22:36 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:22:36 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:22:36 --> Final output sent to browser
DEBUG - 2024-06-20 11:22:36 --> Total execution time: 0.0584
INFO - 2024-06-20 11:22:49 --> Config Class Initialized
INFO - 2024-06-20 11:22:49 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:22:49 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:22:49 --> Utf8 Class Initialized
INFO - 2024-06-20 11:22:49 --> URI Class Initialized
INFO - 2024-06-20 11:22:49 --> Router Class Initialized
INFO - 2024-06-20 11:22:49 --> Output Class Initialized
INFO - 2024-06-20 11:22:49 --> Security Class Initialized
DEBUG - 2024-06-20 11:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:22:49 --> Input Class Initialized
INFO - 2024-06-20 11:22:49 --> Language Class Initialized
INFO - 2024-06-20 11:22:49 --> Loader Class Initialized
INFO - 2024-06-20 11:22:49 --> Helper loaded: url_helper
INFO - 2024-06-20 11:22:49 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:22:49 --> Controller Class Initialized
INFO - 2024-06-20 11:22:49 --> Database Driver Class Initialized
INFO - 2024-06-20 11:22:49 --> Model "Auth_model" initialized
ERROR - 2024-06-20 11:22:49 --> Severity: Warning --> Undefined array key "usernames" D:\xampp\htdocs\Blog\application\controllers\Auth.php 73
ERROR - 2024-06-20 11:22:49 --> Severity: Warning --> Undefined array key "passwords" D:\xampp\htdocs\Blog\application\controllers\Auth.php 74
INFO - 2024-06-20 11:22:49 --> Config Class Initialized
INFO - 2024-06-20 11:22:49 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:22:49 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:22:49 --> Utf8 Class Initialized
INFO - 2024-06-20 11:22:49 --> URI Class Initialized
INFO - 2024-06-20 11:22:49 --> Router Class Initialized
INFO - 2024-06-20 11:22:49 --> Output Class Initialized
INFO - 2024-06-20 11:22:49 --> Security Class Initialized
DEBUG - 2024-06-20 11:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:22:49 --> Input Class Initialized
INFO - 2024-06-20 11:22:49 --> Language Class Initialized
INFO - 2024-06-20 11:22:49 --> Loader Class Initialized
INFO - 2024-06-20 11:22:49 --> Helper loaded: url_helper
INFO - 2024-06-20 11:22:49 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:22:49 --> Controller Class Initialized
INFO - 2024-06-20 11:22:49 --> Config Class Initialized
INFO - 2024-06-20 11:22:49 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:22:49 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:22:49 --> Utf8 Class Initialized
INFO - 2024-06-20 11:22:49 --> URI Class Initialized
INFO - 2024-06-20 11:22:49 --> Router Class Initialized
INFO - 2024-06-20 11:22:49 --> Output Class Initialized
INFO - 2024-06-20 11:22:49 --> Security Class Initialized
DEBUG - 2024-06-20 11:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:22:49 --> Input Class Initialized
INFO - 2024-06-20 11:22:49 --> Language Class Initialized
INFO - 2024-06-20 11:22:49 --> Loader Class Initialized
INFO - 2024-06-20 11:22:49 --> Helper loaded: url_helper
INFO - 2024-06-20 11:22:49 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:22:49 --> Controller Class Initialized
INFO - 2024-06-20 11:22:49 --> Database Driver Class Initialized
INFO - 2024-06-20 11:22:49 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:22:49 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:22:49 --> Final output sent to browser
DEBUG - 2024-06-20 11:22:49 --> Total execution time: 0.0537
INFO - 2024-06-20 11:23:07 --> Config Class Initialized
INFO - 2024-06-20 11:23:07 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:23:07 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:23:07 --> Utf8 Class Initialized
INFO - 2024-06-20 11:23:07 --> URI Class Initialized
INFO - 2024-06-20 11:23:07 --> Router Class Initialized
INFO - 2024-06-20 11:23:07 --> Output Class Initialized
INFO - 2024-06-20 11:23:07 --> Security Class Initialized
DEBUG - 2024-06-20 11:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:23:07 --> Input Class Initialized
INFO - 2024-06-20 11:23:07 --> Language Class Initialized
INFO - 2024-06-20 11:23:07 --> Loader Class Initialized
INFO - 2024-06-20 11:23:07 --> Helper loaded: url_helper
INFO - 2024-06-20 11:23:07 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:23:07 --> Controller Class Initialized
INFO - 2024-06-20 11:23:07 --> Database Driver Class Initialized
INFO - 2024-06-20 11:23:07 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:23:07 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:23:07 --> Final output sent to browser
DEBUG - 2024-06-20 11:23:07 --> Total execution time: 0.0517
INFO - 2024-06-20 11:23:08 --> Config Class Initialized
INFO - 2024-06-20 11:23:08 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:23:08 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:23:08 --> Utf8 Class Initialized
INFO - 2024-06-20 11:23:08 --> URI Class Initialized
INFO - 2024-06-20 11:23:08 --> Router Class Initialized
INFO - 2024-06-20 11:23:08 --> Output Class Initialized
INFO - 2024-06-20 11:23:08 --> Security Class Initialized
DEBUG - 2024-06-20 11:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:23:08 --> Input Class Initialized
INFO - 2024-06-20 11:23:08 --> Language Class Initialized
INFO - 2024-06-20 11:23:08 --> Loader Class Initialized
INFO - 2024-06-20 11:23:08 --> Helper loaded: url_helper
INFO - 2024-06-20 11:23:08 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:23:08 --> Controller Class Initialized
INFO - 2024-06-20 11:23:08 --> Database Driver Class Initialized
INFO - 2024-06-20 11:23:08 --> Model "Auth_model" initialized
ERROR - 2024-06-20 11:23:08 --> Severity: Warning --> Undefined array key "usernames" D:\xampp\htdocs\Blog\application\controllers\Auth.php 73
ERROR - 2024-06-20 11:23:08 --> Severity: Warning --> Undefined array key "passwords" D:\xampp\htdocs\Blog\application\controllers\Auth.php 74
INFO - 2024-06-20 11:23:08 --> Config Class Initialized
INFO - 2024-06-20 11:23:08 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:23:08 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:23:08 --> Utf8 Class Initialized
INFO - 2024-06-20 11:23:08 --> URI Class Initialized
INFO - 2024-06-20 11:23:08 --> Router Class Initialized
INFO - 2024-06-20 11:23:08 --> Output Class Initialized
INFO - 2024-06-20 11:23:08 --> Security Class Initialized
DEBUG - 2024-06-20 11:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:23:08 --> Input Class Initialized
INFO - 2024-06-20 11:23:08 --> Language Class Initialized
INFO - 2024-06-20 11:23:08 --> Loader Class Initialized
INFO - 2024-06-20 11:23:08 --> Helper loaded: url_helper
INFO - 2024-06-20 11:23:08 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:23:09 --> Controller Class Initialized
INFO - 2024-06-20 11:23:29 --> Config Class Initialized
INFO - 2024-06-20 11:23:29 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:23:29 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:23:29 --> Utf8 Class Initialized
INFO - 2024-06-20 11:23:29 --> URI Class Initialized
INFO - 2024-06-20 11:23:29 --> Router Class Initialized
INFO - 2024-06-20 11:23:29 --> Output Class Initialized
INFO - 2024-06-20 11:23:29 --> Security Class Initialized
DEBUG - 2024-06-20 11:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:23:29 --> Input Class Initialized
INFO - 2024-06-20 11:23:29 --> Language Class Initialized
INFO - 2024-06-20 11:23:29 --> Loader Class Initialized
INFO - 2024-06-20 11:23:29 --> Helper loaded: url_helper
INFO - 2024-06-20 11:23:29 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:23:29 --> Controller Class Initialized
INFO - 2024-06-20 11:23:35 --> Config Class Initialized
INFO - 2024-06-20 11:23:35 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:23:35 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:23:35 --> Utf8 Class Initialized
INFO - 2024-06-20 11:23:35 --> URI Class Initialized
INFO - 2024-06-20 11:23:35 --> Router Class Initialized
INFO - 2024-06-20 11:23:35 --> Output Class Initialized
INFO - 2024-06-20 11:23:35 --> Security Class Initialized
DEBUG - 2024-06-20 11:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:23:35 --> Input Class Initialized
INFO - 2024-06-20 11:23:35 --> Language Class Initialized
INFO - 2024-06-20 11:23:35 --> Loader Class Initialized
INFO - 2024-06-20 11:23:35 --> Helper loaded: url_helper
INFO - 2024-06-20 11:23:35 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:23:35 --> Controller Class Initialized
INFO - 2024-06-20 11:23:35 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/home.php
INFO - 2024-06-20 11:23:35 --> Final output sent to browser
DEBUG - 2024-06-20 11:23:35 --> Total execution time: 0.0529
INFO - 2024-06-20 11:23:37 --> Config Class Initialized
INFO - 2024-06-20 11:23:37 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:23:37 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:23:37 --> Utf8 Class Initialized
INFO - 2024-06-20 11:23:37 --> URI Class Initialized
INFO - 2024-06-20 11:23:37 --> Router Class Initialized
INFO - 2024-06-20 11:23:37 --> Output Class Initialized
INFO - 2024-06-20 11:23:37 --> Security Class Initialized
DEBUG - 2024-06-20 11:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:23:37 --> Input Class Initialized
INFO - 2024-06-20 11:23:37 --> Language Class Initialized
INFO - 2024-06-20 11:23:37 --> Loader Class Initialized
INFO - 2024-06-20 11:23:37 --> Helper loaded: url_helper
INFO - 2024-06-20 11:23:37 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:23:37 --> Controller Class Initialized
INFO - 2024-06-20 11:23:37 --> Database Driver Class Initialized
INFO - 2024-06-20 11:23:37 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:23:37 --> Config Class Initialized
INFO - 2024-06-20 11:23:37 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:23:37 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:23:37 --> Utf8 Class Initialized
INFO - 2024-06-20 11:23:37 --> URI Class Initialized
INFO - 2024-06-20 11:23:37 --> Router Class Initialized
INFO - 2024-06-20 11:23:37 --> Output Class Initialized
INFO - 2024-06-20 11:23:37 --> Security Class Initialized
DEBUG - 2024-06-20 11:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:23:37 --> Input Class Initialized
INFO - 2024-06-20 11:23:37 --> Language Class Initialized
INFO - 2024-06-20 11:23:37 --> Loader Class Initialized
INFO - 2024-06-20 11:23:37 --> Helper loaded: url_helper
INFO - 2024-06-20 11:23:37 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:23:37 --> Controller Class Initialized
INFO - 2024-06-20 11:23:37 --> Database Driver Class Initialized
INFO - 2024-06-20 11:23:37 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:23:37 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:23:37 --> Final output sent to browser
DEBUG - 2024-06-20 11:23:37 --> Total execution time: 0.0538
INFO - 2024-06-20 11:23:52 --> Config Class Initialized
INFO - 2024-06-20 11:23:52 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:23:52 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:23:52 --> Utf8 Class Initialized
INFO - 2024-06-20 11:23:52 --> URI Class Initialized
INFO - 2024-06-20 11:23:52 --> Router Class Initialized
INFO - 2024-06-20 11:23:52 --> Output Class Initialized
INFO - 2024-06-20 11:23:52 --> Security Class Initialized
DEBUG - 2024-06-20 11:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:23:52 --> Input Class Initialized
INFO - 2024-06-20 11:23:52 --> Language Class Initialized
INFO - 2024-06-20 11:23:52 --> Loader Class Initialized
INFO - 2024-06-20 11:23:52 --> Helper loaded: url_helper
INFO - 2024-06-20 11:23:52 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:23:52 --> Controller Class Initialized
INFO - 2024-06-20 11:23:52 --> Config Class Initialized
INFO - 2024-06-20 11:23:52 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:23:52 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:23:52 --> Utf8 Class Initialized
INFO - 2024-06-20 11:23:52 --> URI Class Initialized
INFO - 2024-06-20 11:23:52 --> Router Class Initialized
INFO - 2024-06-20 11:23:52 --> Output Class Initialized
INFO - 2024-06-20 11:23:52 --> Security Class Initialized
DEBUG - 2024-06-20 11:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:23:52 --> Input Class Initialized
INFO - 2024-06-20 11:23:52 --> Language Class Initialized
INFO - 2024-06-20 11:23:52 --> Loader Class Initialized
INFO - 2024-06-20 11:23:52 --> Helper loaded: url_helper
INFO - 2024-06-20 11:23:52 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:23:52 --> Controller Class Initialized
INFO - 2024-06-20 11:23:52 --> Database Driver Class Initialized
INFO - 2024-06-20 11:23:52 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:23:52 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:23:52 --> Final output sent to browser
DEBUG - 2024-06-20 11:23:52 --> Total execution time: 0.0475
INFO - 2024-06-20 11:23:54 --> Config Class Initialized
INFO - 2024-06-20 11:23:54 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:23:54 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:23:54 --> Utf8 Class Initialized
INFO - 2024-06-20 11:23:54 --> URI Class Initialized
INFO - 2024-06-20 11:23:54 --> Router Class Initialized
INFO - 2024-06-20 11:23:54 --> Output Class Initialized
INFO - 2024-06-20 11:23:55 --> Security Class Initialized
DEBUG - 2024-06-20 11:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:23:55 --> Input Class Initialized
INFO - 2024-06-20 11:23:55 --> Language Class Initialized
INFO - 2024-06-20 11:23:55 --> Loader Class Initialized
INFO - 2024-06-20 11:23:55 --> Helper loaded: url_helper
INFO - 2024-06-20 11:23:55 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:23:55 --> Controller Class Initialized
INFO - 2024-06-20 11:23:55 --> Database Driver Class Initialized
INFO - 2024-06-20 11:23:55 --> Model "Auth_model" initialized
ERROR - 2024-06-20 11:23:55 --> Severity: Warning --> Undefined array key "usernames" D:\xampp\htdocs\Blog\application\controllers\Auth.php 73
ERROR - 2024-06-20 11:23:55 --> Severity: Warning --> Undefined array key "passwords" D:\xampp\htdocs\Blog\application\controllers\Auth.php 74
INFO - 2024-06-20 11:23:55 --> Config Class Initialized
INFO - 2024-06-20 11:23:55 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:23:55 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:23:55 --> Utf8 Class Initialized
INFO - 2024-06-20 11:23:55 --> URI Class Initialized
INFO - 2024-06-20 11:23:55 --> Router Class Initialized
INFO - 2024-06-20 11:23:55 --> Output Class Initialized
INFO - 2024-06-20 11:23:55 --> Security Class Initialized
DEBUG - 2024-06-20 11:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:23:55 --> Input Class Initialized
INFO - 2024-06-20 11:23:55 --> Language Class Initialized
INFO - 2024-06-20 11:23:55 --> Loader Class Initialized
INFO - 2024-06-20 11:23:55 --> Helper loaded: url_helper
INFO - 2024-06-20 11:23:55 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:23:55 --> Controller Class Initialized
INFO - 2024-06-20 11:23:55 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/home.php
INFO - 2024-06-20 11:23:55 --> Final output sent to browser
DEBUG - 2024-06-20 11:23:55 --> Total execution time: 0.0342
INFO - 2024-06-20 11:24:11 --> Config Class Initialized
INFO - 2024-06-20 11:24:11 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:24:11 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:24:11 --> Utf8 Class Initialized
INFO - 2024-06-20 11:24:11 --> URI Class Initialized
INFO - 2024-06-20 11:24:11 --> Router Class Initialized
INFO - 2024-06-20 11:24:11 --> Output Class Initialized
INFO - 2024-06-20 11:24:11 --> Security Class Initialized
DEBUG - 2024-06-20 11:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:24:11 --> Input Class Initialized
INFO - 2024-06-20 11:24:11 --> Language Class Initialized
INFO - 2024-06-20 11:24:11 --> Loader Class Initialized
INFO - 2024-06-20 11:24:11 --> Helper loaded: url_helper
INFO - 2024-06-20 11:24:12 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:24:12 --> Controller Class Initialized
INFO - 2024-06-20 11:24:12 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/home.php
INFO - 2024-06-20 11:24:12 --> Final output sent to browser
DEBUG - 2024-06-20 11:24:12 --> Total execution time: 0.0353
INFO - 2024-06-20 11:24:13 --> Config Class Initialized
INFO - 2024-06-20 11:24:13 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:24:13 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:24:13 --> Utf8 Class Initialized
INFO - 2024-06-20 11:24:13 --> URI Class Initialized
INFO - 2024-06-20 11:24:13 --> Router Class Initialized
INFO - 2024-06-20 11:24:13 --> Output Class Initialized
INFO - 2024-06-20 11:24:13 --> Security Class Initialized
DEBUG - 2024-06-20 11:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:24:13 --> Input Class Initialized
INFO - 2024-06-20 11:24:13 --> Language Class Initialized
INFO - 2024-06-20 11:24:13 --> Loader Class Initialized
INFO - 2024-06-20 11:24:13 --> Helper loaded: url_helper
INFO - 2024-06-20 11:24:13 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:24:13 --> Controller Class Initialized
INFO - 2024-06-20 11:24:13 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/home.php
INFO - 2024-06-20 11:24:13 --> Final output sent to browser
DEBUG - 2024-06-20 11:24:13 --> Total execution time: 0.0491
INFO - 2024-06-20 11:27:51 --> Config Class Initialized
INFO - 2024-06-20 11:27:51 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:27:51 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:27:51 --> Utf8 Class Initialized
INFO - 2024-06-20 11:27:51 --> URI Class Initialized
INFO - 2024-06-20 11:27:51 --> Router Class Initialized
INFO - 2024-06-20 11:27:51 --> Output Class Initialized
INFO - 2024-06-20 11:27:51 --> Security Class Initialized
DEBUG - 2024-06-20 11:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:27:51 --> Input Class Initialized
INFO - 2024-06-20 11:27:51 --> Language Class Initialized
INFO - 2024-06-20 11:27:51 --> Loader Class Initialized
INFO - 2024-06-20 11:27:51 --> Helper loaded: url_helper
INFO - 2024-06-20 11:27:51 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:27:51 --> Controller Class Initialized
ERROR - 2024-06-20 11:27:51 --> Severity: error --> Exception: syntax error, unexpected identifier "t", expecting "," or ";" D:\xampp\htdocs\Blog\application\views\home\home.php 34
INFO - 2024-06-20 11:28:18 --> Config Class Initialized
INFO - 2024-06-20 11:28:18 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:28:18 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:28:18 --> Utf8 Class Initialized
INFO - 2024-06-20 11:28:18 --> URI Class Initialized
INFO - 2024-06-20 11:28:18 --> Router Class Initialized
INFO - 2024-06-20 11:28:18 --> Output Class Initialized
INFO - 2024-06-20 11:28:18 --> Security Class Initialized
DEBUG - 2024-06-20 11:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:28:18 --> Input Class Initialized
INFO - 2024-06-20 11:28:18 --> Language Class Initialized
INFO - 2024-06-20 11:28:18 --> Loader Class Initialized
INFO - 2024-06-20 11:28:18 --> Helper loaded: url_helper
INFO - 2024-06-20 11:28:18 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:28:18 --> Controller Class Initialized
ERROR - 2024-06-20 11:28:18 --> Severity: error --> Exception: syntax error, unexpected identifier "t", expecting "," or ";" D:\xampp\htdocs\Blog\application\views\home\home.php 34
INFO - 2024-06-20 11:28:33 --> Config Class Initialized
INFO - 2024-06-20 11:28:33 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:28:33 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:28:33 --> Utf8 Class Initialized
INFO - 2024-06-20 11:28:33 --> URI Class Initialized
INFO - 2024-06-20 11:28:33 --> Router Class Initialized
INFO - 2024-06-20 11:28:33 --> Output Class Initialized
INFO - 2024-06-20 11:28:33 --> Security Class Initialized
DEBUG - 2024-06-20 11:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:28:33 --> Input Class Initialized
INFO - 2024-06-20 11:28:33 --> Language Class Initialized
INFO - 2024-06-20 11:28:33 --> Loader Class Initialized
INFO - 2024-06-20 11:28:33 --> Helper loaded: url_helper
INFO - 2024-06-20 11:28:33 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:28:33 --> Controller Class Initialized
ERROR - 2024-06-20 11:28:33 --> Severity: error --> Exception: syntax error, unexpected identifier "t", expecting "," or ";" D:\xampp\htdocs\Blog\application\views\home\home.php 34
INFO - 2024-06-20 11:28:38 --> Config Class Initialized
INFO - 2024-06-20 11:28:38 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:28:38 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:28:38 --> Utf8 Class Initialized
INFO - 2024-06-20 11:28:38 --> URI Class Initialized
INFO - 2024-06-20 11:28:38 --> Router Class Initialized
INFO - 2024-06-20 11:28:38 --> Output Class Initialized
INFO - 2024-06-20 11:28:38 --> Security Class Initialized
DEBUG - 2024-06-20 11:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:28:38 --> Input Class Initialized
INFO - 2024-06-20 11:28:38 --> Language Class Initialized
INFO - 2024-06-20 11:28:38 --> Loader Class Initialized
INFO - 2024-06-20 11:28:38 --> Helper loaded: url_helper
INFO - 2024-06-20 11:28:38 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:28:38 --> Controller Class Initialized
ERROR - 2024-06-20 11:28:38 --> Severity: error --> Exception: syntax error, unexpected identifier "t", expecting "," or ";" D:\xampp\htdocs\Blog\application\views\home\home.php 34
INFO - 2024-06-20 11:28:40 --> Config Class Initialized
INFO - 2024-06-20 11:28:40 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:28:40 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:28:40 --> Utf8 Class Initialized
INFO - 2024-06-20 11:28:40 --> URI Class Initialized
INFO - 2024-06-20 11:28:40 --> Router Class Initialized
INFO - 2024-06-20 11:28:40 --> Output Class Initialized
INFO - 2024-06-20 11:28:40 --> Security Class Initialized
DEBUG - 2024-06-20 11:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:28:40 --> Input Class Initialized
INFO - 2024-06-20 11:28:40 --> Language Class Initialized
INFO - 2024-06-20 11:28:40 --> Loader Class Initialized
INFO - 2024-06-20 11:28:40 --> Helper loaded: url_helper
INFO - 2024-06-20 11:28:40 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:28:40 --> Controller Class Initialized
ERROR - 2024-06-20 11:28:40 --> Severity: error --> Exception: syntax error, unexpected identifier "t", expecting "," or ";" D:\xampp\htdocs\Blog\application\views\home\home.php 34
INFO - 2024-06-20 11:28:51 --> Config Class Initialized
INFO - 2024-06-20 11:28:51 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:28:51 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:28:51 --> Utf8 Class Initialized
INFO - 2024-06-20 11:28:51 --> URI Class Initialized
INFO - 2024-06-20 11:28:51 --> Router Class Initialized
INFO - 2024-06-20 11:28:51 --> Output Class Initialized
INFO - 2024-06-20 11:28:51 --> Security Class Initialized
DEBUG - 2024-06-20 11:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:28:51 --> Input Class Initialized
INFO - 2024-06-20 11:28:51 --> Language Class Initialized
INFO - 2024-06-20 11:28:51 --> Loader Class Initialized
INFO - 2024-06-20 11:28:51 --> Helper loaded: url_helper
INFO - 2024-06-20 11:28:51 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:28:51 --> Controller Class Initialized
ERROR - 2024-06-20 11:28:51 --> Severity: error --> Exception: syntax error, unexpected identifier "t", expecting "," or ";" D:\xampp\htdocs\Blog\application\views\home\home.php 34
INFO - 2024-06-20 11:29:42 --> Config Class Initialized
INFO - 2024-06-20 11:29:42 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:29:42 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:29:42 --> Utf8 Class Initialized
INFO - 2024-06-20 11:29:42 --> URI Class Initialized
INFO - 2024-06-20 11:29:42 --> Router Class Initialized
INFO - 2024-06-20 11:29:42 --> Output Class Initialized
INFO - 2024-06-20 11:29:42 --> Security Class Initialized
DEBUG - 2024-06-20 11:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:29:42 --> Input Class Initialized
INFO - 2024-06-20 11:29:42 --> Language Class Initialized
INFO - 2024-06-20 11:29:42 --> Loader Class Initialized
INFO - 2024-06-20 11:29:42 --> Helper loaded: url_helper
INFO - 2024-06-20 11:29:42 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:29:42 --> Controller Class Initialized
ERROR - 2024-06-20 11:29:42 --> Severity: error --> Exception: syntax error, unexpected identifier "t", expecting "," or ";" D:\xampp\htdocs\Blog\application\views\home\home.php 34
INFO - 2024-06-20 11:29:43 --> Config Class Initialized
INFO - 2024-06-20 11:29:43 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:29:43 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:29:43 --> Utf8 Class Initialized
INFO - 2024-06-20 11:29:43 --> URI Class Initialized
INFO - 2024-06-20 11:29:43 --> Router Class Initialized
INFO - 2024-06-20 11:29:43 --> Output Class Initialized
INFO - 2024-06-20 11:29:43 --> Security Class Initialized
DEBUG - 2024-06-20 11:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:29:43 --> Input Class Initialized
INFO - 2024-06-20 11:29:43 --> Language Class Initialized
INFO - 2024-06-20 11:29:43 --> Loader Class Initialized
INFO - 2024-06-20 11:29:43 --> Helper loaded: url_helper
INFO - 2024-06-20 11:29:43 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:29:43 --> Controller Class Initialized
ERROR - 2024-06-20 11:29:43 --> Severity: error --> Exception: syntax error, unexpected identifier "t", expecting "," or ";" D:\xampp\htdocs\Blog\application\views\home\home.php 34
INFO - 2024-06-20 11:29:49 --> Config Class Initialized
INFO - 2024-06-20 11:29:49 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:29:49 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:29:49 --> Utf8 Class Initialized
INFO - 2024-06-20 11:29:49 --> URI Class Initialized
INFO - 2024-06-20 11:29:49 --> Router Class Initialized
INFO - 2024-06-20 11:29:49 --> Output Class Initialized
INFO - 2024-06-20 11:29:49 --> Security Class Initialized
DEBUG - 2024-06-20 11:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:29:49 --> Input Class Initialized
INFO - 2024-06-20 11:29:49 --> Language Class Initialized
INFO - 2024-06-20 11:29:49 --> Loader Class Initialized
INFO - 2024-06-20 11:29:49 --> Helper loaded: url_helper
INFO - 2024-06-20 11:29:49 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:29:49 --> Controller Class Initialized
ERROR - 2024-06-20 11:29:49 --> Severity: error --> Exception: syntax error, unexpected identifier "Home", expecting "," or ";" D:\xampp\htdocs\Blog\application\views\home\home.php 63
INFO - 2024-06-20 11:30:00 --> Config Class Initialized
INFO - 2024-06-20 11:30:00 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:30:00 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:30:00 --> Utf8 Class Initialized
INFO - 2024-06-20 11:30:00 --> URI Class Initialized
INFO - 2024-06-20 11:30:00 --> Router Class Initialized
INFO - 2024-06-20 11:30:00 --> Output Class Initialized
INFO - 2024-06-20 11:30:00 --> Security Class Initialized
DEBUG - 2024-06-20 11:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:30:00 --> Input Class Initialized
INFO - 2024-06-20 11:30:00 --> Language Class Initialized
INFO - 2024-06-20 11:30:00 --> Loader Class Initialized
INFO - 2024-06-20 11:30:00 --> Helper loaded: url_helper
INFO - 2024-06-20 11:30:00 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:30:00 --> Controller Class Initialized
INFO - 2024-06-20 11:30:00 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/home.php
INFO - 2024-06-20 11:30:00 --> Final output sent to browser
DEBUG - 2024-06-20 11:30:00 --> Total execution time: 0.0383
INFO - 2024-06-20 11:30:15 --> Config Class Initialized
INFO - 2024-06-20 11:30:15 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:30:15 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:30:15 --> Utf8 Class Initialized
INFO - 2024-06-20 11:30:15 --> URI Class Initialized
INFO - 2024-06-20 11:30:15 --> Router Class Initialized
INFO - 2024-06-20 11:30:15 --> Output Class Initialized
INFO - 2024-06-20 11:30:15 --> Security Class Initialized
DEBUG - 2024-06-20 11:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:30:15 --> Input Class Initialized
INFO - 2024-06-20 11:30:15 --> Language Class Initialized
INFO - 2024-06-20 11:30:15 --> Loader Class Initialized
INFO - 2024-06-20 11:30:15 --> Helper loaded: url_helper
INFO - 2024-06-20 11:30:15 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:30:15 --> Controller Class Initialized
INFO - 2024-06-20 11:30:15 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/home.php
INFO - 2024-06-20 11:30:15 --> Final output sent to browser
DEBUG - 2024-06-20 11:30:15 --> Total execution time: 0.0386
INFO - 2024-06-20 11:30:18 --> Config Class Initialized
INFO - 2024-06-20 11:30:18 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:30:18 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:30:18 --> Utf8 Class Initialized
INFO - 2024-06-20 11:30:18 --> URI Class Initialized
INFO - 2024-06-20 11:30:18 --> Router Class Initialized
INFO - 2024-06-20 11:30:18 --> Output Class Initialized
INFO - 2024-06-20 11:30:18 --> Security Class Initialized
DEBUG - 2024-06-20 11:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:30:18 --> Input Class Initialized
INFO - 2024-06-20 11:30:18 --> Language Class Initialized
INFO - 2024-06-20 11:30:18 --> Loader Class Initialized
INFO - 2024-06-20 11:30:18 --> Helper loaded: url_helper
INFO - 2024-06-20 11:30:18 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:30:18 --> Controller Class Initialized
ERROR - 2024-06-20 11:30:18 --> Severity: error --> Exception: Too few arguments to function Home::article_read_more(), 0 passed in D:\xampp\htdocs\Blog\system\core\CodeIgniter.php on line 533 and exactly 1 expected D:\xampp\htdocs\Blog\application\controllers\Home.php 20
INFO - 2024-06-20 11:30:30 --> Config Class Initialized
INFO - 2024-06-20 11:30:30 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:30:30 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:30:30 --> Utf8 Class Initialized
INFO - 2024-06-20 11:30:30 --> URI Class Initialized
INFO - 2024-06-20 11:30:30 --> Router Class Initialized
INFO - 2024-06-20 11:30:30 --> Output Class Initialized
INFO - 2024-06-20 11:30:30 --> Security Class Initialized
DEBUG - 2024-06-20 11:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:30:30 --> Input Class Initialized
INFO - 2024-06-20 11:30:30 --> Language Class Initialized
INFO - 2024-06-20 11:30:30 --> Loader Class Initialized
INFO - 2024-06-20 11:30:30 --> Helper loaded: url_helper
INFO - 2024-06-20 11:30:30 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:30:30 --> Controller Class Initialized
INFO - 2024-06-20 11:30:30 --> Final output sent to browser
DEBUG - 2024-06-20 11:30:30 --> Total execution time: 0.0355
INFO - 2024-06-20 11:30:53 --> Config Class Initialized
INFO - 2024-06-20 11:30:53 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:30:53 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:30:53 --> Utf8 Class Initialized
INFO - 2024-06-20 11:30:53 --> URI Class Initialized
INFO - 2024-06-20 11:30:53 --> Router Class Initialized
INFO - 2024-06-20 11:30:53 --> Output Class Initialized
INFO - 2024-06-20 11:30:53 --> Security Class Initialized
DEBUG - 2024-06-20 11:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:30:53 --> Input Class Initialized
INFO - 2024-06-20 11:30:53 --> Language Class Initialized
INFO - 2024-06-20 11:30:53 --> Loader Class Initialized
INFO - 2024-06-20 11:30:53 --> Helper loaded: url_helper
INFO - 2024-06-20 11:30:53 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:30:53 --> Controller Class Initialized
INFO - 2024-06-20 11:30:53 --> Final output sent to browser
DEBUG - 2024-06-20 11:30:53 --> Total execution time: 0.0411
INFO - 2024-06-20 11:31:13 --> Config Class Initialized
INFO - 2024-06-20 11:31:13 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:31:13 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:31:13 --> Utf8 Class Initialized
INFO - 2024-06-20 11:31:13 --> URI Class Initialized
INFO - 2024-06-20 11:31:13 --> Router Class Initialized
INFO - 2024-06-20 11:31:13 --> Output Class Initialized
INFO - 2024-06-20 11:31:13 --> Security Class Initialized
DEBUG - 2024-06-20 11:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:31:13 --> Input Class Initialized
INFO - 2024-06-20 11:31:13 --> Language Class Initialized
INFO - 2024-06-20 11:31:13 --> Loader Class Initialized
INFO - 2024-06-20 11:31:13 --> Helper loaded: url_helper
INFO - 2024-06-20 11:31:13 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:31:13 --> Controller Class Initialized
INFO - 2024-06-20 11:31:13 --> Final output sent to browser
DEBUG - 2024-06-20 11:31:13 --> Total execution time: 0.0338
INFO - 2024-06-20 11:32:11 --> Config Class Initialized
INFO - 2024-06-20 11:32:11 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:32:11 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:32:11 --> Utf8 Class Initialized
INFO - 2024-06-20 11:32:11 --> URI Class Initialized
INFO - 2024-06-20 11:32:11 --> Router Class Initialized
INFO - 2024-06-20 11:32:11 --> Output Class Initialized
INFO - 2024-06-20 11:32:11 --> Security Class Initialized
DEBUG - 2024-06-20 11:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:32:11 --> Input Class Initialized
INFO - 2024-06-20 11:32:11 --> Language Class Initialized
INFO - 2024-06-20 11:32:11 --> Loader Class Initialized
INFO - 2024-06-20 11:32:11 --> Helper loaded: url_helper
INFO - 2024-06-20 11:32:11 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:32:11 --> Controller Class Initialized
INFO - 2024-06-20 11:32:11 --> Final output sent to browser
DEBUG - 2024-06-20 11:32:11 --> Total execution time: 0.0379
INFO - 2024-06-20 11:32:29 --> Config Class Initialized
INFO - 2024-06-20 11:32:29 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:32:29 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:32:29 --> Utf8 Class Initialized
INFO - 2024-06-20 11:32:29 --> URI Class Initialized
INFO - 2024-06-20 11:32:29 --> Router Class Initialized
INFO - 2024-06-20 11:32:29 --> Output Class Initialized
INFO - 2024-06-20 11:32:29 --> Security Class Initialized
DEBUG - 2024-06-20 11:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:32:29 --> Input Class Initialized
INFO - 2024-06-20 11:32:29 --> Language Class Initialized
INFO - 2024-06-20 11:32:29 --> Loader Class Initialized
INFO - 2024-06-20 11:32:29 --> Helper loaded: url_helper
INFO - 2024-06-20 11:32:29 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:32:29 --> Controller Class Initialized
INFO - 2024-06-20 11:32:38 --> Config Class Initialized
INFO - 2024-06-20 11:32:38 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:32:38 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:32:38 --> Utf8 Class Initialized
INFO - 2024-06-20 11:32:38 --> URI Class Initialized
INFO - 2024-06-20 11:32:38 --> Router Class Initialized
INFO - 2024-06-20 11:32:38 --> Output Class Initialized
INFO - 2024-06-20 11:32:38 --> Security Class Initialized
DEBUG - 2024-06-20 11:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:32:38 --> Input Class Initialized
INFO - 2024-06-20 11:32:38 --> Language Class Initialized
ERROR - 2024-06-20 11:32:38 --> Severity: error --> Exception: syntax error, unexpected variable "$article_to_show", expecting ")" D:\xampp\htdocs\Blog\application\controllers\Home.php 27
INFO - 2024-06-20 11:32:51 --> Config Class Initialized
INFO - 2024-06-20 11:32:51 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:32:51 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:32:51 --> Utf8 Class Initialized
INFO - 2024-06-20 11:32:51 --> URI Class Initialized
INFO - 2024-06-20 11:32:51 --> Router Class Initialized
INFO - 2024-06-20 11:32:51 --> Output Class Initialized
INFO - 2024-06-20 11:32:51 --> Security Class Initialized
DEBUG - 2024-06-20 11:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:32:51 --> Input Class Initialized
INFO - 2024-06-20 11:32:51 --> Language Class Initialized
INFO - 2024-06-20 11:32:51 --> Loader Class Initialized
INFO - 2024-06-20 11:32:51 --> Helper loaded: url_helper
INFO - 2024-06-20 11:32:51 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:32:51 --> Controller Class Initialized
INFO - 2024-06-20 11:32:51 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/article1.php
INFO - 2024-06-20 11:32:51 --> Final output sent to browser
DEBUG - 2024-06-20 11:32:51 --> Total execution time: 0.0725
INFO - 2024-06-20 11:32:51 --> Config Class Initialized
INFO - 2024-06-20 11:32:51 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:32:51 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:32:51 --> Utf8 Class Initialized
INFO - 2024-06-20 11:32:51 --> URI Class Initialized
INFO - 2024-06-20 11:32:51 --> Router Class Initialized
INFO - 2024-06-20 11:32:51 --> Output Class Initialized
INFO - 2024-06-20 11:32:51 --> Security Class Initialized
DEBUG - 2024-06-20 11:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:32:51 --> Input Class Initialized
INFO - 2024-06-20 11:32:51 --> Language Class Initialized
ERROR - 2024-06-20 11:32:51 --> 404 Page Not Found: Home/style2.css
INFO - 2024-06-20 11:33:08 --> Config Class Initialized
INFO - 2024-06-20 11:33:08 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:33:08 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:33:08 --> Utf8 Class Initialized
INFO - 2024-06-20 11:33:08 --> URI Class Initialized
INFO - 2024-06-20 11:33:08 --> Router Class Initialized
INFO - 2024-06-20 11:33:08 --> Output Class Initialized
INFO - 2024-06-20 11:33:08 --> Security Class Initialized
DEBUG - 2024-06-20 11:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:33:08 --> Input Class Initialized
INFO - 2024-06-20 11:33:08 --> Language Class Initialized
INFO - 2024-06-20 11:33:08 --> Loader Class Initialized
INFO - 2024-06-20 11:33:08 --> Helper loaded: url_helper
INFO - 2024-06-20 11:33:08 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:33:08 --> Controller Class Initialized
INFO - 2024-06-20 11:33:08 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/home.php
INFO - 2024-06-20 11:33:08 --> Final output sent to browser
DEBUG - 2024-06-20 11:33:08 --> Total execution time: 0.0375
INFO - 2024-06-20 11:33:10 --> Config Class Initialized
INFO - 2024-06-20 11:33:10 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:33:10 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:33:10 --> Utf8 Class Initialized
INFO - 2024-06-20 11:33:10 --> URI Class Initialized
INFO - 2024-06-20 11:33:10 --> Router Class Initialized
INFO - 2024-06-20 11:33:10 --> Output Class Initialized
INFO - 2024-06-20 11:33:10 --> Security Class Initialized
DEBUG - 2024-06-20 11:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:33:10 --> Input Class Initialized
INFO - 2024-06-20 11:33:10 --> Language Class Initialized
INFO - 2024-06-20 11:33:10 --> Loader Class Initialized
INFO - 2024-06-20 11:33:10 --> Helper loaded: url_helper
INFO - 2024-06-20 11:33:10 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:33:10 --> Controller Class Initialized
INFO - 2024-06-20 11:33:10 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/article4.php
INFO - 2024-06-20 11:33:10 --> Final output sent to browser
DEBUG - 2024-06-20 11:33:10 --> Total execution time: 0.0453
INFO - 2024-06-20 11:33:15 --> Config Class Initialized
INFO - 2024-06-20 11:33:15 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:33:15 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:33:15 --> Utf8 Class Initialized
INFO - 2024-06-20 11:33:15 --> URI Class Initialized
INFO - 2024-06-20 11:33:15 --> Router Class Initialized
INFO - 2024-06-20 11:33:15 --> Output Class Initialized
INFO - 2024-06-20 11:33:15 --> Security Class Initialized
DEBUG - 2024-06-20 11:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:33:15 --> Input Class Initialized
INFO - 2024-06-20 11:33:15 --> Language Class Initialized
INFO - 2024-06-20 11:33:15 --> Loader Class Initialized
INFO - 2024-06-20 11:33:15 --> Helper loaded: url_helper
INFO - 2024-06-20 11:33:15 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:33:15 --> Controller Class Initialized
INFO - 2024-06-20 11:33:15 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/home.php
INFO - 2024-06-20 11:33:15 --> Final output sent to browser
DEBUG - 2024-06-20 11:33:15 --> Total execution time: 0.0301
INFO - 2024-06-20 11:33:34 --> Config Class Initialized
INFO - 2024-06-20 11:33:34 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:33:34 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:33:34 --> Utf8 Class Initialized
INFO - 2024-06-20 11:33:34 --> URI Class Initialized
INFO - 2024-06-20 11:33:34 --> Router Class Initialized
INFO - 2024-06-20 11:33:34 --> Output Class Initialized
INFO - 2024-06-20 11:33:34 --> Security Class Initialized
DEBUG - 2024-06-20 11:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:33:34 --> Input Class Initialized
INFO - 2024-06-20 11:33:34 --> Language Class Initialized
INFO - 2024-06-20 11:33:34 --> Loader Class Initialized
INFO - 2024-06-20 11:33:35 --> Helper loaded: url_helper
INFO - 2024-06-20 11:33:35 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:33:35 --> Controller Class Initialized
INFO - 2024-06-20 11:33:35 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/home.php
INFO - 2024-06-20 11:33:35 --> Final output sent to browser
DEBUG - 2024-06-20 11:33:35 --> Total execution time: 0.0327
INFO - 2024-06-20 11:33:36 --> Config Class Initialized
INFO - 2024-06-20 11:33:36 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:33:36 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:33:36 --> Utf8 Class Initialized
INFO - 2024-06-20 11:33:36 --> URI Class Initialized
INFO - 2024-06-20 11:33:36 --> Router Class Initialized
INFO - 2024-06-20 11:33:36 --> Output Class Initialized
INFO - 2024-06-20 11:33:36 --> Security Class Initialized
DEBUG - 2024-06-20 11:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:33:36 --> Input Class Initialized
INFO - 2024-06-20 11:33:36 --> Language Class Initialized
INFO - 2024-06-20 11:33:36 --> Loader Class Initialized
INFO - 2024-06-20 11:33:36 --> Helper loaded: url_helper
INFO - 2024-06-20 11:33:36 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:33:36 --> Controller Class Initialized
INFO - 2024-06-20 11:33:36 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/article1.php
INFO - 2024-06-20 11:33:36 --> Final output sent to browser
DEBUG - 2024-06-20 11:33:36 --> Total execution time: 0.0431
INFO - 2024-06-20 11:33:39 --> Config Class Initialized
INFO - 2024-06-20 11:33:39 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:33:39 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:33:39 --> Utf8 Class Initialized
INFO - 2024-06-20 11:33:39 --> URI Class Initialized
INFO - 2024-06-20 11:33:39 --> Router Class Initialized
INFO - 2024-06-20 11:33:39 --> Output Class Initialized
INFO - 2024-06-20 11:33:39 --> Security Class Initialized
DEBUG - 2024-06-20 11:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:33:39 --> Input Class Initialized
INFO - 2024-06-20 11:33:39 --> Language Class Initialized
INFO - 2024-06-20 11:33:39 --> Loader Class Initialized
INFO - 2024-06-20 11:33:39 --> Helper loaded: url_helper
INFO - 2024-06-20 11:33:39 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:33:39 --> Controller Class Initialized
INFO - 2024-06-20 11:33:39 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/home.php
INFO - 2024-06-20 11:33:39 --> Final output sent to browser
DEBUG - 2024-06-20 11:33:39 --> Total execution time: 0.0348
INFO - 2024-06-20 11:33:54 --> Config Class Initialized
INFO - 2024-06-20 11:33:54 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:33:54 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:33:54 --> Utf8 Class Initialized
INFO - 2024-06-20 11:33:54 --> URI Class Initialized
INFO - 2024-06-20 11:33:54 --> Router Class Initialized
INFO - 2024-06-20 11:33:54 --> Output Class Initialized
INFO - 2024-06-20 11:33:54 --> Security Class Initialized
DEBUG - 2024-06-20 11:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:33:54 --> Input Class Initialized
INFO - 2024-06-20 11:33:54 --> Language Class Initialized
INFO - 2024-06-20 11:33:54 --> Loader Class Initialized
INFO - 2024-06-20 11:33:54 --> Helper loaded: url_helper
INFO - 2024-06-20 11:33:54 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:33:54 --> Controller Class Initialized
INFO - 2024-06-20 11:33:54 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/home.php
INFO - 2024-06-20 11:33:54 --> Final output sent to browser
DEBUG - 2024-06-20 11:33:54 --> Total execution time: 0.0473
INFO - 2024-06-20 11:33:55 --> Config Class Initialized
INFO - 2024-06-20 11:33:55 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:33:55 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:33:55 --> Utf8 Class Initialized
INFO - 2024-06-20 11:33:55 --> URI Class Initialized
INFO - 2024-06-20 11:33:55 --> Router Class Initialized
INFO - 2024-06-20 11:33:55 --> Output Class Initialized
INFO - 2024-06-20 11:33:55 --> Security Class Initialized
DEBUG - 2024-06-20 11:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:33:55 --> Input Class Initialized
INFO - 2024-06-20 11:33:55 --> Language Class Initialized
INFO - 2024-06-20 11:33:55 --> Loader Class Initialized
INFO - 2024-06-20 11:33:55 --> Helper loaded: url_helper
INFO - 2024-06-20 11:33:55 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:33:55 --> Controller Class Initialized
INFO - 2024-06-20 11:33:55 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/article2.php
INFO - 2024-06-20 11:33:55 --> Final output sent to browser
DEBUG - 2024-06-20 11:33:55 --> Total execution time: 0.0455
INFO - 2024-06-20 11:33:57 --> Config Class Initialized
INFO - 2024-06-20 11:33:57 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:33:57 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:33:57 --> Utf8 Class Initialized
INFO - 2024-06-20 11:33:57 --> URI Class Initialized
INFO - 2024-06-20 11:33:57 --> Router Class Initialized
INFO - 2024-06-20 11:33:57 --> Output Class Initialized
INFO - 2024-06-20 11:33:57 --> Security Class Initialized
DEBUG - 2024-06-20 11:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:33:57 --> Input Class Initialized
INFO - 2024-06-20 11:33:57 --> Language Class Initialized
INFO - 2024-06-20 11:33:57 --> Loader Class Initialized
INFO - 2024-06-20 11:33:57 --> Helper loaded: url_helper
INFO - 2024-06-20 11:33:57 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:33:57 --> Controller Class Initialized
INFO - 2024-06-20 11:33:57 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/home.php
INFO - 2024-06-20 11:33:57 --> Final output sent to browser
DEBUG - 2024-06-20 11:33:57 --> Total execution time: 0.0347
INFO - 2024-06-20 11:34:14 --> Config Class Initialized
INFO - 2024-06-20 11:34:14 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:34:14 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:34:14 --> Utf8 Class Initialized
INFO - 2024-06-20 11:34:14 --> URI Class Initialized
INFO - 2024-06-20 11:34:14 --> Router Class Initialized
INFO - 2024-06-20 11:34:14 --> Output Class Initialized
INFO - 2024-06-20 11:34:14 --> Security Class Initialized
DEBUG - 2024-06-20 11:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:34:14 --> Input Class Initialized
INFO - 2024-06-20 11:34:14 --> Language Class Initialized
INFO - 2024-06-20 11:34:14 --> Loader Class Initialized
INFO - 2024-06-20 11:34:14 --> Helper loaded: url_helper
INFO - 2024-06-20 11:34:14 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:34:14 --> Controller Class Initialized
INFO - 2024-06-20 11:34:14 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/home.php
INFO - 2024-06-20 11:34:14 --> Final output sent to browser
DEBUG - 2024-06-20 11:34:14 --> Total execution time: 0.0324
INFO - 2024-06-20 11:34:17 --> Config Class Initialized
INFO - 2024-06-20 11:34:17 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:34:17 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:34:17 --> Utf8 Class Initialized
INFO - 2024-06-20 11:34:17 --> URI Class Initialized
INFO - 2024-06-20 11:34:17 --> Router Class Initialized
INFO - 2024-06-20 11:34:17 --> Output Class Initialized
INFO - 2024-06-20 11:34:17 --> Security Class Initialized
DEBUG - 2024-06-20 11:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:34:17 --> Input Class Initialized
INFO - 2024-06-20 11:34:17 --> Language Class Initialized
INFO - 2024-06-20 11:34:17 --> Loader Class Initialized
INFO - 2024-06-20 11:34:17 --> Helper loaded: url_helper
INFO - 2024-06-20 11:34:17 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:34:17 --> Controller Class Initialized
INFO - 2024-06-20 11:34:17 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/article3.php
INFO - 2024-06-20 11:34:17 --> Final output sent to browser
DEBUG - 2024-06-20 11:34:17 --> Total execution time: 0.0470
INFO - 2024-06-20 11:34:19 --> Config Class Initialized
INFO - 2024-06-20 11:34:19 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:34:19 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:34:19 --> Utf8 Class Initialized
INFO - 2024-06-20 11:34:19 --> URI Class Initialized
INFO - 2024-06-20 11:34:19 --> Router Class Initialized
INFO - 2024-06-20 11:34:19 --> Output Class Initialized
INFO - 2024-06-20 11:34:19 --> Security Class Initialized
DEBUG - 2024-06-20 11:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:34:19 --> Input Class Initialized
INFO - 2024-06-20 11:34:19 --> Language Class Initialized
INFO - 2024-06-20 11:34:19 --> Loader Class Initialized
INFO - 2024-06-20 11:34:19 --> Helper loaded: url_helper
INFO - 2024-06-20 11:34:19 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:34:19 --> Controller Class Initialized
INFO - 2024-06-20 11:34:19 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/home.php
INFO - 2024-06-20 11:34:19 --> Final output sent to browser
DEBUG - 2024-06-20 11:34:19 --> Total execution time: 0.0288
INFO - 2024-06-20 11:34:20 --> Config Class Initialized
INFO - 2024-06-20 11:34:20 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:34:20 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:34:20 --> Utf8 Class Initialized
INFO - 2024-06-20 11:34:20 --> URI Class Initialized
INFO - 2024-06-20 11:34:20 --> Router Class Initialized
INFO - 2024-06-20 11:34:20 --> Output Class Initialized
INFO - 2024-06-20 11:34:20 --> Security Class Initialized
DEBUG - 2024-06-20 11:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:34:20 --> Input Class Initialized
INFO - 2024-06-20 11:34:20 --> Language Class Initialized
INFO - 2024-06-20 11:34:20 --> Loader Class Initialized
INFO - 2024-06-20 11:34:20 --> Helper loaded: url_helper
INFO - 2024-06-20 11:34:20 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:34:20 --> Controller Class Initialized
INFO - 2024-06-20 11:34:20 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/article4.php
INFO - 2024-06-20 11:34:20 --> Final output sent to browser
DEBUG - 2024-06-20 11:34:20 --> Total execution time: 0.0399
INFO - 2024-06-20 11:34:21 --> Config Class Initialized
INFO - 2024-06-20 11:34:21 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:34:21 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:34:21 --> Utf8 Class Initialized
INFO - 2024-06-20 11:34:21 --> URI Class Initialized
INFO - 2024-06-20 11:34:21 --> Router Class Initialized
INFO - 2024-06-20 11:34:21 --> Output Class Initialized
INFO - 2024-06-20 11:34:21 --> Security Class Initialized
DEBUG - 2024-06-20 11:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:34:21 --> Input Class Initialized
INFO - 2024-06-20 11:34:21 --> Language Class Initialized
INFO - 2024-06-20 11:34:21 --> Loader Class Initialized
INFO - 2024-06-20 11:34:21 --> Helper loaded: url_helper
INFO - 2024-06-20 11:34:21 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:34:21 --> Controller Class Initialized
INFO - 2024-06-20 11:34:21 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/home.php
INFO - 2024-06-20 11:34:21 --> Final output sent to browser
DEBUG - 2024-06-20 11:34:21 --> Total execution time: 0.0393
INFO - 2024-06-20 11:34:23 --> Config Class Initialized
INFO - 2024-06-20 11:34:23 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:34:23 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:34:23 --> Utf8 Class Initialized
INFO - 2024-06-20 11:34:23 --> URI Class Initialized
INFO - 2024-06-20 11:34:23 --> Router Class Initialized
INFO - 2024-06-20 11:34:23 --> Output Class Initialized
INFO - 2024-06-20 11:34:23 --> Security Class Initialized
DEBUG - 2024-06-20 11:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:34:23 --> Input Class Initialized
INFO - 2024-06-20 11:34:23 --> Language Class Initialized
INFO - 2024-06-20 11:34:23 --> Loader Class Initialized
INFO - 2024-06-20 11:34:23 --> Helper loaded: url_helper
INFO - 2024-06-20 11:34:23 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:34:23 --> Controller Class Initialized
INFO - 2024-06-20 11:34:23 --> Database Driver Class Initialized
INFO - 2024-06-20 11:34:23 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:34:23 --> Config Class Initialized
INFO - 2024-06-20 11:34:23 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:34:23 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:34:23 --> Utf8 Class Initialized
INFO - 2024-06-20 11:34:23 --> URI Class Initialized
INFO - 2024-06-20 11:34:23 --> Router Class Initialized
INFO - 2024-06-20 11:34:23 --> Output Class Initialized
INFO - 2024-06-20 11:34:23 --> Security Class Initialized
DEBUG - 2024-06-20 11:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:34:23 --> Input Class Initialized
INFO - 2024-06-20 11:34:23 --> Language Class Initialized
INFO - 2024-06-20 11:34:23 --> Loader Class Initialized
INFO - 2024-06-20 11:34:23 --> Helper loaded: url_helper
INFO - 2024-06-20 11:34:23 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:34:23 --> Controller Class Initialized
INFO - 2024-06-20 11:34:23 --> Database Driver Class Initialized
INFO - 2024-06-20 11:34:23 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:34:23 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:34:23 --> Final output sent to browser
DEBUG - 2024-06-20 11:34:23 --> Total execution time: 0.0360
INFO - 2024-06-20 11:34:24 --> Config Class Initialized
INFO - 2024-06-20 11:34:24 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:34:24 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:34:24 --> Utf8 Class Initialized
INFO - 2024-06-20 11:34:24 --> URI Class Initialized
INFO - 2024-06-20 11:34:24 --> Router Class Initialized
INFO - 2024-06-20 11:34:24 --> Output Class Initialized
INFO - 2024-06-20 11:34:24 --> Security Class Initialized
DEBUG - 2024-06-20 11:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:34:24 --> Input Class Initialized
INFO - 2024-06-20 11:34:24 --> Language Class Initialized
INFO - 2024-06-20 11:34:24 --> Loader Class Initialized
INFO - 2024-06-20 11:34:24 --> Helper loaded: url_helper
INFO - 2024-06-20 11:34:24 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:34:24 --> Controller Class Initialized
INFO - 2024-06-20 11:34:24 --> Database Driver Class Initialized
INFO - 2024-06-20 11:34:24 --> Model "Auth_model" initialized
ERROR - 2024-06-20 11:34:24 --> Severity: Warning --> Undefined array key "usernames" D:\xampp\htdocs\Blog\application\controllers\Auth.php 73
ERROR - 2024-06-20 11:34:24 --> Severity: Warning --> Undefined array key "passwords" D:\xampp\htdocs\Blog\application\controllers\Auth.php 74
INFO - 2024-06-20 11:34:24 --> Config Class Initialized
INFO - 2024-06-20 11:34:24 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:34:24 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:34:24 --> Utf8 Class Initialized
INFO - 2024-06-20 11:34:24 --> URI Class Initialized
INFO - 2024-06-20 11:34:24 --> Router Class Initialized
INFO - 2024-06-20 11:34:24 --> Output Class Initialized
INFO - 2024-06-20 11:34:24 --> Security Class Initialized
DEBUG - 2024-06-20 11:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:34:24 --> Input Class Initialized
INFO - 2024-06-20 11:34:24 --> Language Class Initialized
INFO - 2024-06-20 11:34:24 --> Loader Class Initialized
INFO - 2024-06-20 11:34:24 --> Helper loaded: url_helper
INFO - 2024-06-20 11:34:24 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:34:24 --> Controller Class Initialized
INFO - 2024-06-20 11:34:24 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/home.php
INFO - 2024-06-20 11:34:24 --> Final output sent to browser
DEBUG - 2024-06-20 11:34:24 --> Total execution time: 0.0366
INFO - 2024-06-20 11:34:26 --> Config Class Initialized
INFO - 2024-06-20 11:34:26 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:34:26 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:34:26 --> Utf8 Class Initialized
INFO - 2024-06-20 11:34:26 --> URI Class Initialized
INFO - 2024-06-20 11:34:26 --> Router Class Initialized
INFO - 2024-06-20 11:34:26 --> Output Class Initialized
INFO - 2024-06-20 11:34:26 --> Security Class Initialized
DEBUG - 2024-06-20 11:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:34:26 --> Input Class Initialized
INFO - 2024-06-20 11:34:26 --> Language Class Initialized
INFO - 2024-06-20 11:34:26 --> Loader Class Initialized
INFO - 2024-06-20 11:34:26 --> Helper loaded: url_helper
INFO - 2024-06-20 11:34:26 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:34:26 --> Controller Class Initialized
INFO - 2024-06-20 11:34:26 --> File loaded: D:\xampp\htdocs\Blog\application\views\home/home.php
INFO - 2024-06-20 11:34:26 --> Final output sent to browser
DEBUG - 2024-06-20 11:34:26 --> Total execution time: 0.0383
INFO - 2024-06-20 11:34:26 --> Config Class Initialized
INFO - 2024-06-20 11:34:26 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:34:26 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:34:26 --> Utf8 Class Initialized
INFO - 2024-06-20 11:34:26 --> URI Class Initialized
INFO - 2024-06-20 11:34:26 --> Router Class Initialized
INFO - 2024-06-20 11:34:26 --> Output Class Initialized
INFO - 2024-06-20 11:34:26 --> Security Class Initialized
DEBUG - 2024-06-20 11:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:34:26 --> Input Class Initialized
INFO - 2024-06-20 11:34:26 --> Language Class Initialized
INFO - 2024-06-20 11:34:26 --> Loader Class Initialized
INFO - 2024-06-20 11:34:26 --> Helper loaded: url_helper
INFO - 2024-06-20 11:34:26 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:34:26 --> Controller Class Initialized
INFO - 2024-06-20 11:34:26 --> Database Driver Class Initialized
INFO - 2024-06-20 11:34:26 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:34:26 --> Config Class Initialized
INFO - 2024-06-20 11:34:26 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:34:26 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:34:26 --> Utf8 Class Initialized
INFO - 2024-06-20 11:34:26 --> URI Class Initialized
INFO - 2024-06-20 11:34:26 --> Router Class Initialized
INFO - 2024-06-20 11:34:26 --> Output Class Initialized
INFO - 2024-06-20 11:34:26 --> Security Class Initialized
DEBUG - 2024-06-20 11:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:34:26 --> Input Class Initialized
INFO - 2024-06-20 11:34:26 --> Language Class Initialized
INFO - 2024-06-20 11:34:26 --> Loader Class Initialized
INFO - 2024-06-20 11:34:26 --> Helper loaded: url_helper
INFO - 2024-06-20 11:34:26 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:34:26 --> Controller Class Initialized
INFO - 2024-06-20 11:34:27 --> Database Driver Class Initialized
INFO - 2024-06-20 11:34:27 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:34:27 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/index.php
INFO - 2024-06-20 11:34:27 --> Final output sent to browser
DEBUG - 2024-06-20 11:34:27 --> Total execution time: 0.0377
INFO - 2024-06-20 11:34:27 --> Config Class Initialized
INFO - 2024-06-20 11:34:27 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:34:27 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:34:27 --> Utf8 Class Initialized
INFO - 2024-06-20 11:34:27 --> URI Class Initialized
INFO - 2024-06-20 11:34:27 --> Router Class Initialized
INFO - 2024-06-20 11:34:27 --> Output Class Initialized
INFO - 2024-06-20 11:34:27 --> Security Class Initialized
DEBUG - 2024-06-20 11:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:34:27 --> Input Class Initialized
INFO - 2024-06-20 11:34:27 --> Language Class Initialized
INFO - 2024-06-20 11:34:27 --> Loader Class Initialized
INFO - 2024-06-20 11:34:27 --> Helper loaded: url_helper
INFO - 2024-06-20 11:34:27 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:34:27 --> Controller Class Initialized
INFO - 2024-06-20 11:34:27 --> Database Driver Class Initialized
INFO - 2024-06-20 11:34:27 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:34:27 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 11:34:27 --> Final output sent to browser
DEBUG - 2024-06-20 11:34:27 --> Total execution time: 0.0472
INFO - 2024-06-20 11:34:30 --> Config Class Initialized
INFO - 2024-06-20 11:34:30 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:34:30 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:34:30 --> Utf8 Class Initialized
INFO - 2024-06-20 11:34:30 --> URI Class Initialized
INFO - 2024-06-20 11:34:30 --> Router Class Initialized
INFO - 2024-06-20 11:34:30 --> Output Class Initialized
INFO - 2024-06-20 11:34:30 --> Security Class Initialized
DEBUG - 2024-06-20 11:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:34:30 --> Input Class Initialized
INFO - 2024-06-20 11:34:30 --> Language Class Initialized
INFO - 2024-06-20 11:34:30 --> Loader Class Initialized
INFO - 2024-06-20 11:34:31 --> Helper loaded: url_helper
INFO - 2024-06-20 11:34:31 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:34:31 --> Controller Class Initialized
INFO - 2024-06-20 11:34:31 --> Database Driver Class Initialized
INFO - 2024-06-20 11:34:31 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:34:31 --> Form Validation Class Initialized
INFO - 2024-06-20 11:34:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-20 11:34:31 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 11:34:31 --> Final output sent to browser
DEBUG - 2024-06-20 11:34:31 --> Total execution time: 0.0639
INFO - 2024-06-20 11:34:36 --> Config Class Initialized
INFO - 2024-06-20 11:34:36 --> Hooks Class Initialized
DEBUG - 2024-06-20 11:34:36 --> UTF-8 Support Enabled
INFO - 2024-06-20 11:34:36 --> Utf8 Class Initialized
INFO - 2024-06-20 11:34:36 --> URI Class Initialized
INFO - 2024-06-20 11:34:36 --> Router Class Initialized
INFO - 2024-06-20 11:34:36 --> Output Class Initialized
INFO - 2024-06-20 11:34:36 --> Security Class Initialized
DEBUG - 2024-06-20 11:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 11:34:36 --> Input Class Initialized
INFO - 2024-06-20 11:34:36 --> Language Class Initialized
INFO - 2024-06-20 11:34:36 --> Loader Class Initialized
INFO - 2024-06-20 11:34:36 --> Helper loaded: url_helper
INFO - 2024-06-20 11:34:36 --> Helper loaded: form_helper
DEBUG - 2024-06-20 11:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-20 11:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 11:34:36 --> Controller Class Initialized
INFO - 2024-06-20 11:34:36 --> Database Driver Class Initialized
INFO - 2024-06-20 11:34:36 --> Model "Auth_model" initialized
INFO - 2024-06-20 11:34:36 --> Form Validation Class Initialized
INFO - 2024-06-20 11:34:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-06-20 11:34:36 --> File loaded: D:\xampp\htdocs\Blog\application\views\auth/registration.php
INFO - 2024-06-20 11:34:36 --> Final output sent to browser
DEBUG - 2024-06-20 11:34:36 --> Total execution time: 0.0502
