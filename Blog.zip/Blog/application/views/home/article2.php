 <?php include 'header.php'; ?>
    <!--blog-section============================================================================-->
    <div class="blog single">
      <span>5 January 2022</span>
      <h1 class="post-title">Throwback to December</h1>
      <img src="https://as1.ftcdn.net/v2/jpg/02/05/57/92/1000_F_205579298_ZjRE5sn1k0Zkzm6VNCNtk6FUfRxbY1ex.jpg" alt="Blog">
      <div class="post-content">
        <p> It didn't snow much in my area, but I was lucky enough to visit my family's house up in the mountains. The last time I visited them was at least 2 years ago so it was nice to see them again. </p>
        <BR>
        <p> Lorem ipsum dolor, sit amet consectetur adipisicing elit. Consequuntur voluptatum impedit officiis dicta sint temporibus cupiditate autem illum doloremque iste beatae molestiae laborum quos esse, veritatis assumenda earum doloribus veniam!</p>
        <BR>
        <p> Lorem ipsum dolor, sit amet consectetur adipisicing elit. Consequuntur voluptatum impedit officiis dicta sint temporibus cupiditate autem illum doloremque iste beatae molestiae laborum quos esse, veritatis assumenda earum doloribus veniam! </p>
        <BR>
      </div>
    </div>
  <?php include 'footer.php'; ?>