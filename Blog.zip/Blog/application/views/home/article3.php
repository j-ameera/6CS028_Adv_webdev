 <?php include 'header.php'; ?>
    <!--blog-section============================================================================-->
    <div class="blog single">
      <span>17 August 2021</span>
      <h1 class="post-title">Purple isn't my favourite colour!</h1>
      <img src="https://as1.ftcdn.net/v2/jpg/05/05/94/46/1000_F_505944656_bDxox5xmlMWq2S5x8Q9lutGw7BBKmzKK.jpg" alt="Blog">
      <div class="post-content">
        <p> It's really not. But it's definitely one of the ones I like the most. I bought this after an outing - it was the first thing I saw when I entered H&M Home. I really like it there, I just wish furniture there was cheaper. </p>
        <BR>
        <p> Lorem ipsum dolor, sit amet consectetur adipisicing elit. Consequuntur voluptatum impedit officiis dicta sint temporibus cupiditate autem illum doloremque iste beatae molestiae laborum quos esse, veritatis assumenda earum doloribus veniam!</p>
        <BR>
        <p> Lorem ipsum dolor, sit amet consectetur adipisicing elit. Consequuntur voluptatum impedit officiis dicta sint temporibus cupiditate autem illum doloremque iste beatae molestiae laborum quos esse, veritatis assumenda earum doloribus veniam! </p>
        <BR>
      </div>
    </div>
    <?php include 'footer.php'; ?>