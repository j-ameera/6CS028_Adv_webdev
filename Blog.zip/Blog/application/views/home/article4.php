  <?php include 'header.php'; ?>
    <!--blog-section============================================================================-->
    <div class="blog single">
      <span>20 April 2021</span>
      <h1 class="post-title">My Birthday!</h1>
      <img src="https://as2.ftcdn.net/v2/jpg/02/11/64/83/1000_F_211648365_3HfacqvMClKTSYyItzgUHsVy2oO4kNye.jpg" alt="Blog">
      <div class="post-content">
        <p> Nothing too exciting, just went out to a restaurant later in the evening. I got a couple of gifts, it was nice to recieve any at all. Some things I got include makeup, some stationary and other stuff. </p>
        <BR>
        <p> Lorem ipsum dolor, sit amet consectetur adipisicing elit. Consequuntur voluptatum impedit officiis dicta sint temporibus cupiditate autem illum doloremque iste beatae molestiae laborum quos esse, veritatis assumenda earum doloribus veniam!</p>
        <BR>
        <p> Lorem ipsum dolor, sit amet consectetur adipisicing elit. Consequuntur voluptatum impedit officiis dicta sint temporibus cupiditate autem illum doloremque iste beatae molestiae laborum quos esse, veritatis assumenda earum doloribus veniam! </p>
        <BR>
      </div>
    </div>

    <?php include 'footer.php'; ?>