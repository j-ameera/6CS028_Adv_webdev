 <?php include 'header.php'; ?>
    <!--blog-section============================================================================-->
    <div class="blog single">
      <span>11 January 2022</span>
      <h1 class="post-title">A trip to Italy</h1>
      <img src="https://as1.ftcdn.net/v2/jpg/02/00/07/14/1000_F_200071450_ONuxtbxORzD289pYFPOIbc3GupmMsa67.jpg" alt="Blog">
      <div class="post-content">
        <p> I don't know much about Italy, not even much about the landmarks. Only that it has a city called Venice that's apparently meant to be the city of love. Or is that Paris? I don't know. </p>
        <BR>
        <p> Lorem ipsum dolor, sit amet consectetur adipisicing elit. Consequuntur voluptatum impedit officiis dicta sint temporibus cupiditate autem illum doloremque iste beatae molestiae laborum quos esse, veritatis assumenda earum doloribus veniam!</p>
        <BR>
        <p> Lorem ipsum dolor, sit amet consectetur adipisicing elit. Consequuntur voluptatum impedit officiis dicta sint temporibus cupiditate autem illum doloremque iste beatae molestiae laborum quos esse, veritatis assumenda earum doloribus veniam! </p>
        <BR>
      </div>
    </div>
  <?php include 'footer.php'; ?>